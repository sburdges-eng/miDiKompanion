"""
Kelly Vocal Expression Engine
Pitch-phoneme alignment, expression modulation, and vocal synthesis control
"""
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass, field
import math
import random

from kelly_lyric_structures import (
    Phoneme, Syllable, VocalExpression, VocalNote, VocalPhrase, VocalTrack,
    LyricLine, VocalStyleType, emotion_to_vocal_expression
)


# =============================================================================
# PITCH CONTOUR GENERATION
# =============================================================================

@dataclass
class PitchTarget:
    """Target pitch with timing."""
    pitch_midi: float
    time_offset: float  # seconds from note start
    bend_cents: float = 0.0


class PitchContourGenerator:
    """Generate expressive pitch contours."""
    
    def generate_note_contour(
        self,
        base_pitch: int,
        duration: float,
        expression: VocalExpression,
        phoneme: Optional[Phoneme] = None
    ) -> List[PitchTarget]:
        """Generate pitch contour for a single note."""
        targets = []
        
        # Attack scoop (slight pitch rise)
        if phoneme and phoneme.is_vowel:
            scoop_cents = -20 + 40 * expression.breathiness
            targets.append(PitchTarget(
                pitch_midi=base_pitch,
                time_offset=0.0,
                bend_cents=scoop_cents
            ))
            targets.append(PitchTarget(
                pitch_midi=base_pitch,
                time_offset=expression.attack_time,
                bend_cents=0.0
            ))
        else:
            targets.append(PitchTarget(
                pitch_midi=base_pitch,
                time_offset=0.0,
                bend_cents=0.0
            ))
        
        # Vibrato section
        if duration > expression.vibrato_delay:
            vibrato_start = expression.vibrato_delay
            vibrato_end = duration - expression.release_time
            
            if vibrato_end > vibrato_start:
                # Sample vibrato curve
                samples = max(4, int((vibrato_end - vibrato_start) * expression.vibrato_rate * 2))
                for i in range(samples):
                    t = vibrato_start + (vibrato_end - vibrato_start) * i / samples
                    phase = 2 * math.pi * expression.vibrato_rate * (t - vibrato_start)
                    bend = expression.vibrato_depth * math.sin(phase)
                    
                    # Add drift
                    bend += expression.pitch_drift
                    
                    targets.append(PitchTarget(
                        pitch_midi=base_pitch,
                        time_offset=t,
                        bend_cents=bend
                    ))
        
        # Release (slight fall)
        if duration > 0.1:
            targets.append(PitchTarget(
                pitch_midi=base_pitch,
                time_offset=duration - 0.02,
                bend_cents=-10 - 10 * (1 - expression.dynamics)
            ))
        
        return targets
    
    def generate_phrase_contour(
        self,
        notes: List[VocalNote],
        expression: VocalExpression
    ) -> List[List[PitchTarget]]:
        """Generate pitch contours for an entire phrase."""
        contours = []
        
        for i, note in enumerate(notes):
            # Adjust expression per note position
            local_expr = VocalExpression(
                breathiness=expression.breathiness,
                vibrato_rate=expression.vibrato_rate,
                vibrato_depth=expression.vibrato_depth * (0.5 + 0.5 * (i / max(1, len(notes) - 1))),
                vibrato_delay=expression.vibrato_delay,
                pitch_drift=expression.pitch_drift,
                dynamics=expression.dynamics,
                attack_time=expression.attack_time,
                release_time=expression.release_time,
            )
            
            phoneme = note.syllable.phonemes[0] if note.syllable and note.syllable.phonemes else None
            contour = self.generate_note_contour(
                note.pitch_midi,
                note.duration,
                local_expr,
                phoneme
            )
            contours.append(contour)
        
        return contours


# =============================================================================
# EXPRESSION ENGINE
# =============================================================================

class ExpressionEngine:
    """Modulate vocal expression based on emotion and context."""
    
    def __init__(self):
        self.contour_gen = PitchContourGenerator()
    
    def apply_phrase_dynamics(
        self,
        notes: List[VocalNote],
        phrase_shape: str = "arc"  # arc, rise, fall, flat
    ) -> List[VocalNote]:
        """Apply dynamic curve to phrase."""
        if not notes:
            return notes
        
        n = len(notes)
        
        for i, note in enumerate(notes):
            pos = i / max(1, n - 1)
            
            if phrase_shape == "arc":
                # Peak in middle
                mod = 1.0 + 0.2 * math.sin(pos * math.pi)
            elif phrase_shape == "rise":
                mod = 0.8 + 0.3 * pos
            elif phrase_shape == "fall":
                mod = 1.1 - 0.3 * pos
            else:
                mod = 1.0
            
            note.expression.dynamics = min(1.0, note.expression.dynamics * mod)
        
        return notes
    
    def add_breath_noise(
        self,
        phrase: VocalPhrase,
        intensity: float = 0.3
    ) -> Dict[str, float]:
        """Calculate breath noise parameters."""
        return {
            "pre_breath_duration": phrase.breath_duration if phrase.breath_before else 0,
            "breath_intensity": intensity,
            "breath_pitch_variance": 0.1,  # Random pitch variation
        }
    
    def apply_emotional_modulation(
        self,
        notes: List[VocalNote],
        valence: float,
        arousal: float,
        dominance: float
    ) -> List[VocalNote]:
        """Modulate all notes based on emotion vector."""
        base_expr = emotion_to_vocal_expression(valence, arousal, dominance)
        
        for note in notes:
            # Blend existing expression with emotional base
            expr = note.expression
            expr.breathiness = 0.5 * expr.breathiness + 0.5 * base_expr.breathiness
            expr.vibrato_depth = 0.5 * expr.vibrato_depth + 0.5 * base_expr.vibrato_depth
            expr.dynamics = 0.5 * expr.dynamics + 0.5 * base_expr.dynamics
            expr.pitch_drift = base_expr.pitch_drift
        
        return notes
    
    def add_vocal_fry(
        self,
        note: VocalNote,
        intensity: float = 0.3
    ) -> Dict:
        """Add vocal fry parameters to note."""
        return {
            "fry_start": max(0, note.duration - 0.1),
            "fry_intensity": intensity,
            "fry_frequency": 30 + random.uniform(-5, 5),  # Hz
        }
    
    def add_voice_crack(
        self,
        note: VocalNote,
        probability: float = 0.1
    ) -> Optional[Dict]:
        """Potentially add voice crack for authenticity."""
        if random.random() > probability:
            return None
        
        crack_time = random.uniform(0.1, note.duration - 0.1)
        return {
            "crack_time": crack_time,
            "crack_pitch_jump": random.choice([7, 12, -5]),  # semitones
            "crack_duration": 0.02,
        }


# =============================================================================
# LYRIC-TO-VOCAL ALIGNMENT (LyriSync)
# =============================================================================

class LyriSync:
    """Synchronize lyrics with vocal notes."""
    
    def __init__(self, tempo: int = 120, ppq: int = 480):
        self.tempo = tempo
        self.ppq = ppq
        self.expression_engine = ExpressionEngine()
    
    def beats_to_seconds(self, beats: float) -> float:
        """Convert beats to seconds."""
        return beats * 60.0 / self.tempo
    
    def ticks_to_seconds(self, ticks: int) -> float:
        """Convert MIDI ticks to seconds."""
        return ticks / self.ppq * 60.0 / self.tempo
    
    def align_syllables_to_notes(
        self,
        line: LyricLine,
        pitches: List[int],
        start_beat: float = 0.0,
        note_duration: float = 0.5  # beats per note
    ) -> List[VocalNote]:
        """Align lyric syllables to note pitches."""
        syllables = line.syllables
        notes = []
        
        # Match syllables to pitches (one-to-one or with melisma)
        pitch_idx = 0
        current_beat = start_beat
        
        for syllable in syllables:
            if pitch_idx >= len(pitches):
                pitch_idx = 0  # Wrap around
            
            pitch = pitches[pitch_idx]
            duration = self.beats_to_seconds(note_duration * syllable.duration_beats)
            
            note = VocalNote(
                pitch_midi=pitch,
                start_time=self.beats_to_seconds(current_beat),
                duration=duration,
                syllable=syllable,
                expression=VocalExpression()
            )
            
            notes.append(note)
            current_beat += note_duration * syllable.duration_beats
            pitch_idx += 1
        
        return notes
    
    def create_phrase_from_line(
        self,
        line: LyricLine,
        pitches: List[int],
        expression: VocalExpression,
        start_beat: float = 0.0
    ) -> VocalPhrase:
        """Create vocal phrase from lyric line."""
        notes = self.align_syllables_to_notes(
            line, pitches, start_beat
        )
        
        # Apply expression to all notes
        for note in notes:
            note.expression = VocalExpression(
                breathiness=expression.breathiness,
                vibrato_rate=expression.vibrato_rate,
                vibrato_depth=expression.vibrato_depth,
                vibrato_delay=expression.vibrato_delay,
                pitch_drift=expression.pitch_drift,
                dynamics=expression.dynamics,
                attack_time=expression.attack_time,
                release_time=expression.release_time,
            )
        
        # Apply phrase dynamics
        notes = self.expression_engine.apply_phrase_dynamics(notes, "arc")
        
        return VocalPhrase(
            notes=notes,
            breath_before=True,
            breath_duration=0.3
        )
    
    def add_portamento(
        self,
        notes: List[VocalNote],
        threshold_semitones: int = 3,
        portamento_time: float = 0.05
    ) -> List[VocalNote]:
        """Add portamento between notes with large intervals."""
        for i in range(len(notes) - 1):
            interval = abs(notes[i + 1].pitch_midi - notes[i].pitch_midi)
            if interval >= threshold_semitones:
                notes[i].portamento_time = portamento_time
        
        return notes


# =============================================================================
# VOCAL STYLE PRESETS
# =============================================================================

VOCAL_STYLE_PRESETS = {
    VocalStyleType.NATURAL: VocalExpression(
        breathiness=0.2,
        vibrato_rate=5.5,
        vibrato_depth=20,
        vibrato_delay=0.15,
        dynamics=0.7,
    ),
    VocalStyleType.BREATHY: VocalExpression(
        breathiness=0.7,
        vibrato_rate=4.5,
        vibrato_depth=15,
        vibrato_delay=0.2,
        dynamics=0.5,
    ),
    VocalStyleType.BELT: VocalExpression(
        breathiness=0.05,
        vibrato_rate=6.0,
        vibrato_depth=25,
        vibrato_delay=0.1,
        dynamics=0.95,
    ),
    VocalStyleType.WHISPER: VocalExpression(
        breathiness=0.9,
        vibrato_rate=0,
        vibrato_depth=0,
        dynamics=0.3,
    ),
    VocalStyleType.FALSETTO: VocalExpression(
        breathiness=0.5,
        vibrato_rate=6.5,
        vibrato_depth=30,
        vibrato_delay=0.1,
        dynamics=0.6,
    ),
    VocalStyleType.CRY: VocalExpression(
        breathiness=0.6,
        vibrato_rate=7.0,
        vibrato_depth=40,
        vibrato_delay=0.05,
        pitch_drift=-10,
        dynamics=0.8,
    ),
    VocalStyleType.FRY: VocalExpression(
        breathiness=0.1,
        vibrato_rate=0,
        vibrato_depth=0,
        dynamics=0.4,
    ),
}


def get_style_preset(style: VocalStyleType) -> VocalExpression:
    """Get vocal expression preset for style."""
    return VOCAL_STYLE_PRESETS.get(style, VOCAL_STYLE_PRESETS[VocalStyleType.NATURAL])


# =============================================================================
# MIDI LYRIC EXPORT
# =============================================================================

def export_lyrics_to_midi(
    track: VocalTrack,
    output_path: str
) -> None:
    """Export vocal track with lyrics to MIDI file."""
    from mido import MidiFile, MidiTrack, Message, MetaMessage
    
    mid = MidiFile(ticks_per_beat=480)
    melody_track = MidiTrack()
    lyric_track = MidiTrack()
    mid.tracks.append(melody_track)
    mid.tracks.append(lyric_track)
    
    tempo_us = int(60_000_000 / 120)  # Default 120 BPM
    melody_track.append(MetaMessage('set_tempo', tempo=tempo_us, time=0))
    
    ppq = 480
    current_time = 0
    lyric_time = 0
    
    for phrase in track.phrases:
        for note in phrase.notes:
            # Note events
            note_start = int(note.start_time * 2 * ppq)  # seconds to ticks at 120 BPM
            note_end = int((note.start_time + note.duration) * 2 * ppq)
            
            delta = note_start - current_time
            velocity = int(note.expression.dynamics * 127)
            
            melody_track.append(Message(
                'note_on',
                note=note.pitch_midi,
                velocity=velocity,
                time=max(0, delta)
            ))
            melody_track.append(Message(
                'note_off',
                note=note.pitch_midi,
                velocity=0,
                time=note_end - note_start
            ))
            
            current_time = note_end
            
            # Lyric events
            if note.syllable:
                lyric_delta = note_start - lyric_time
                lyric_track.append(MetaMessage(
                    'lyrics',
                    text=note.syllable.text,
                    time=max(0, lyric_delta)
                ))
                lyric_time = note_start
    
    mid.save(output_path)


# =============================================================================
# MAIN API
# =============================================================================

def create_vocal_track(
    lines: List[LyricLine],
    melody_pitches: List[List[int]],
    emotion_valence: float = 0.0,
    emotion_arousal: float = 0.5,
    emotion_dominance: float = 0.5,
    tempo: int = 120
) -> VocalTrack:
    """Create complete vocal track from lyrics and melody."""
    lyrisync = LyriSync(tempo=tempo)
    expression_engine = ExpressionEngine()
    
    base_expression = emotion_to_vocal_expression(
        emotion_valence, emotion_arousal, emotion_dominance
    )
    
    phrases = []
    current_beat = 0.0
    
    for i, line in enumerate(lines):
        pitches = melody_pitches[i % len(melody_pitches)]
        
        phrase = lyrisync.create_phrase_from_line(
            line, pitches, base_expression, current_beat
        )
        
        # Apply emotional modulation
        phrase.notes = expression_engine.apply_emotional_modulation(
            phrase.notes,
            emotion_valence,
            emotion_arousal,
            emotion_dominance
        )
        
        # Add portamento
        phrase.notes = lyrisync.add_portamento(phrase.notes)
        
        phrases.append(phrase)
        current_beat += line.duration_beats + 1  # Add gap between phrases
    
    return VocalTrack(
        phrases=phrases,
        base_expression=base_expression
    )


if __name__ == "__main__":
    from kelly_lyric_generator import generate_lyrics
    
    print("=== Vocal Expression Test ===\n")
    
    # Generate lyrics
    lyrics = generate_lyrics(emotion="grief", structure="VC")
    
    # Simple melody for test
    melody = [
        [60, 62, 64, 65, 67, 65, 64, 62],  # C D E F G F E D
        [65, 64, 62, 60, 62, 64, 65, 67],  # F E D C D E F G
    ]
    
    # Create vocal track
    track = create_vocal_track(
        lines=lyrics.all_lines[:2],
        melody_pitches=melody,
        emotion_valence=-0.6,
        emotion_arousal=0.3,
        emotion_dominance=0.4,
        tempo=82  # "When I Found You Sleeping" tempo
    )
    
    print(f"Created vocal track with {len(track.phrases)} phrases")
    print(f"Total duration: {track.duration:.2f} seconds")
    
    for i, phrase in enumerate(track.phrases):
        print(f"\nPhrase {i+1}: {len(phrase.notes)} notes")
        for note in phrase.notes[:3]:
            syl_text = note.syllable.text if note.syllable else "?"
            print(f"  {syl_text}: pitch={note.pitch_midi}, dur={note.duration:.2f}s")
