"""
Kelly Phoneme Processing
Grapheme-to-phoneme conversion, formant mapping, syllable processing
"""
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
import re

from kelly_lyric_structures import Phoneme, Syllable, LyricWord, StressLevel


# =============================================================================
# ARPABET TO IPA MAPPING
# =============================================================================

ARPABET_TO_IPA = {
    # Vowels
    "AA": "ɑ", "AE": "æ", "AH": "ʌ", "AO": "ɔ", "AW": "aʊ",
    "AY": "aɪ", "EH": "ɛ", "ER": "ɝ", "EY": "eɪ", "IH": "ɪ",
    "IY": "i", "OW": "oʊ", "OY": "ɔɪ", "UH": "ʊ", "UW": "u",
    # Consonants
    "B": "b", "CH": "tʃ", "D": "d", "DH": "ð", "F": "f",
    "G": "g", "HH": "h", "JH": "dʒ", "K": "k", "L": "l",
    "M": "m", "N": "n", "NG": "ŋ", "P": "p", "R": "r",
    "S": "s", "SH": "ʃ", "T": "t", "TH": "θ", "V": "v",
    "W": "w", "Y": "j", "Z": "z", "ZH": "ʒ",
}

VOWEL_PHONEMES = {
    "AA", "AE", "AH", "AO", "AW", "AY", "EH", "ER", "EY",
    "IH", "IY", "OW", "OY", "UH", "UW"
}

# =============================================================================
# FORMANT DATA (Hz) - F1, F2, F3
# =============================================================================

VOWEL_FORMANTS = {
    "IY": (270, 2290, 3010),   # beat
    "IH": (390, 1990, 2550),   # bit
    "EY": (476, 2089, 2691),   # bait
    "EH": (530, 1840, 2480),   # bet
    "AE": (660, 1720, 2410),   # bat
    "AA": (730, 1090, 2440),   # bot
    "AO": (570, 840, 2410),    # bought
    "OW": (497, 910, 2459),    # boat
    "UH": (440, 1020, 2240),   # book
    "UW": (300, 870, 2240),    # boot
    "AH": (640, 1190, 2390),   # but
    "ER": (490, 1350, 1690),   # bird
    "AY": (500, 1500, 2500),   # bite (diphthong avg)
    "AW": (600, 1200, 2500),   # bout (diphthong avg)
    "OY": (550, 1100, 2500),   # boy (diphthong avg)
}

CONSONANT_DEFAULTS = {
    "voiced": (300, 1200, 2500),
    "unvoiced": (0, 1500, 2800),
}

# =============================================================================
# DURATION ESTIMATES (ms)
# =============================================================================

PHONEME_DURATIONS = {
    # Vowels - longer
    "IY": 120, "IH": 80, "EY": 140, "EH": 90, "AE": 120,
    "AA": 120, "AO": 120, "OW": 140, "UH": 80, "UW": 120,
    "AH": 80, "ER": 150, "AY": 180, "AW": 180, "OY": 180,
    # Plosives - short
    "P": 50, "B": 50, "T": 50, "D": 50, "K": 60, "G": 60,
    # Fricatives - medium
    "F": 80, "V": 70, "TH": 80, "DH": 70, "S": 100, "Z": 90,
    "SH": 100, "ZH": 90, "HH": 60,
    # Affricates
    "CH": 100, "JH": 100,
    # Nasals
    "M": 70, "N": 70, "NG": 80,
    # Liquids/Glides
    "L": 70, "R": 70, "W": 60, "Y": 60,
}

# =============================================================================
# CMU DICTIONARY FALLBACK (Common words)
# =============================================================================

CMU_FALLBACK = {
    "the": ["DH", "AH0"],
    "a": ["AH0"],
    "and": ["AE1", "N", "D"],
    "i": ["AY1"],
    "you": ["Y", "UW1"],
    "is": ["IH1", "Z"],
    "it": ["IH1", "T"],
    "to": ["T", "UW1"],
    "in": ["IH1", "N"],
    "that": ["DH", "AE1", "T"],
    "was": ["W", "AH1", "Z"],
    "for": ["F", "AO1", "R"],
    "on": ["AA1", "N"],
    "are": ["AA1", "R"],
    "with": ["W", "IH1", "DH"],
    "they": ["DH", "EY1"],
    "be": ["B", "IY1"],
    "at": ["AE1", "T"],
    "one": ["W", "AH1", "N"],
    "have": ["HH", "AE1", "V"],
    "this": ["DH", "IH1", "S"],
    "from": ["F", "R", "AH1", "M"],
    "or": ["AO1", "R"],
    "had": ["HH", "AE1", "D"],
    "by": ["B", "AY1"],
    "not": ["N", "AA1", "T"],
    "but": ["B", "AH1", "T"],
    "what": ["W", "AH1", "T"],
    "all": ["AO1", "L"],
    "were": ["W", "ER1"],
    "we": ["W", "IY1"],
    "when": ["W", "EH1", "N"],
    "your": ["Y", "AO1", "R"],
    "can": ["K", "AE1", "N"],
    "there": ["DH", "EH1", "R"],
    "love": ["L", "AH1", "V"],
    "heart": ["HH", "AA1", "R", "T"],
    "soul": ["S", "OW1", "L"],
    "feel": ["F", "IY1", "L"],
    "time": ["T", "AY1", "M"],
    "night": ["N", "AY1", "T"],
    "day": ["D", "EY1"],
    "away": ["AH0", "W", "EY1"],
    "life": ["L", "AY1", "F"],
    "pain": ["P", "EY1", "N"],
    "rain": ["R", "EY1", "N"],
    "eyes": ["AY1", "Z"],
    "cry": ["K", "R", "AY1"],
    "die": ["D", "AY1"],
    "sky": ["S", "K", "AY1"],
    "fly": ["F", "L", "AY1"],
    "free": ["F", "R", "IY1"],
    "dream": ["D", "R", "IY1", "M"],
    "sleep": ["S", "L", "IY1", "P"],
    "sleeping": ["S", "L", "IY1", "P", "IH0", "NG"],
    "found": ["F", "AW1", "N", "D"],
    "lost": ["L", "AO1", "S", "T"],
    "gone": ["G", "AO1", "N"],
    "home": ["HH", "OW1", "M"],
    "alone": ["AH0", "L", "OW1", "N"],
    "broken": ["B", "R", "OW1", "K", "AH0", "N"],
    "falling": ["F", "AO1", "L", "IH0", "NG"],
    "holding": ["HH", "OW1", "L", "D", "IH0", "NG"],
    "never": ["N", "EH1", "V", "ER0"],
    "forever": ["F", "ER0", "EH1", "V", "ER0"],
    "remember": ["R", "IH0", "M", "EH1", "M", "B", "ER0"],
}


# =============================================================================
# PHONEME CLASS FACTORY
# =============================================================================

def create_phoneme(arpabet: str) -> Phoneme:
    """Create Phoneme object from ARPAbet symbol."""
    # Strip stress marker
    base = re.sub(r'[0-2]$', '', arpabet)
    
    ipa = ARPABET_TO_IPA.get(base, arpabet.lower())
    is_vowel = base in VOWEL_PHONEMES
    
    if is_vowel:
        formants = VOWEL_FORMANTS.get(base, (500, 1500, 2500))
        is_voiced = True
    else:
        is_voiced = base in {"B", "D", "G", "V", "DH", "Z", "ZH", "JH", "M", "N", "NG", "L", "R", "W", "Y"}
        formants = CONSONANT_DEFAULTS["voiced" if is_voiced else "unvoiced"]
    
    duration = PHONEME_DURATIONS.get(base, 70)
    
    return Phoneme(
        ipa=ipa,
        arpabet=arpabet,
        duration_ms=duration,
        is_voiced=is_voiced,
        is_vowel=is_vowel,
        formants=formants
    )


# =============================================================================
# GRAPHEME TO PHONEME
# =============================================================================

class G2PConverter:
    """Grapheme-to-phoneme converter using CMU dictionary."""
    
    def __init__(self):
        self.dictionary: Dict[str, List[str]] = CMU_FALLBACK.copy()
        self._load_cmu_if_available()
    
    def _load_cmu_if_available(self):
        """Try to load full CMU dictionary."""
        try:
            import pronouncing
            # Load all entries
            for word in pronouncing.cmudict_list():
                phones = pronouncing.phones_for_word(word)
                if phones:
                    self.dictionary[word.lower()] = phones[0].split()
        except ImportError:
            pass  # Use fallback
    
    def word_to_phonemes(self, word: str) -> List[Phoneme]:
        """Convert word to list of Phoneme objects."""
        word_lower = word.lower().strip()
        
        if word_lower in self.dictionary:
            arpabet_list = self.dictionary[word_lower]
        else:
            # Fallback: simple rule-based conversion
            arpabet_list = self._rule_based_g2p(word_lower)
        
        return [create_phoneme(arpa) for arpa in arpabet_list]
    
    def _rule_based_g2p(self, word: str) -> List[str]:
        """Simple rule-based fallback G2P."""
        result = []
        i = 0
        while i < len(word):
            # Two-letter combinations
            if i < len(word) - 1:
                pair = word[i:i+2]
                if pair == "th":
                    result.append("TH")
                    i += 2
                    continue
                elif pair == "sh":
                    result.append("SH")
                    i += 2
                    continue
                elif pair == "ch":
                    result.append("CH")
                    i += 2
                    continue
                elif pair == "ng":
                    result.append("NG")
                    i += 2
                    continue
                elif pair == "ee":
                    result.append("IY1")
                    i += 2
                    continue
                elif pair == "oo":
                    result.append("UW1")
                    i += 2
                    continue
                elif pair == "ou":
                    result.append("AW1")
                    i += 2
                    continue
                elif pair == "ow":
                    result.append("OW1")
                    i += 2
                    continue
                elif pair == "ai" or pair == "ay":
                    result.append("EY1")
                    i += 2
                    continue
            
            # Single letters
            c = word[i]
            mapping = {
                'a': 'AE1', 'e': 'EH1', 'i': 'IH1', 'o': 'AA1', 'u': 'AH1',
                'b': 'B', 'c': 'K', 'd': 'D', 'f': 'F', 'g': 'G',
                'h': 'HH', 'j': 'JH', 'k': 'K', 'l': 'L', 'm': 'M',
                'n': 'N', 'p': 'P', 'q': 'K', 'r': 'R', 's': 'S',
                't': 'T', 'v': 'V', 'w': 'W', 'x': 'K', 'y': 'Y', 'z': 'Z'
            }
            if c in mapping:
                result.append(mapping[c])
            i += 1
        
        return result
    
    def get_stress_pattern(self, word: str) -> List[int]:
        """Get stress pattern for word (0=none, 1=secondary, 2=primary)."""
        word_lower = word.lower().strip()
        
        if word_lower in self.dictionary:
            arpabet_list = self.dictionary[word_lower]
            pattern = []
            for arpa in arpabet_list:
                match = re.search(r'[0-2]$', arpa)
                if match:
                    stress = int(match.group())
                    # CMU uses 1=primary, 2=secondary, 0=none
                    if stress == 1:
                        pattern.append(2)  # Primary
                    elif stress == 2:
                        pattern.append(1)  # Secondary
                    else:
                        pattern.append(0)
            return pattern if pattern else [1]  # Default to secondary
        
        # Fallback: stress first syllable
        return [2] + [0] * (self._count_syllables_rule(word_lower) - 1)
    
    def _count_syllables_rule(self, word: str) -> int:
        """Count syllables using simple rules."""
        vowels = "aeiouy"
        count = 0
        prev_vowel = False
        for c in word.lower():
            is_vowel = c in vowels
            if is_vowel and not prev_vowel:
                count += 1
            prev_vowel = is_vowel
        # Handle silent e
        if word.endswith('e') and count > 1:
            count -= 1
        return max(1, count)


# =============================================================================
# SYLLABLE SEGMENTATION
# =============================================================================

class SyllableSegmenter:
    """Segment words into syllables."""
    
    def __init__(self, g2p: G2PConverter = None):
        self.g2p = g2p or G2PConverter()
    
    def segment_word(self, word: str) -> LyricWord:
        """Segment word into syllables with phonemes."""
        phonemes = self.g2p.word_to_phonemes(word)
        stress_pattern = self.g2p.get_stress_pattern(word)
        
        syllables = []
        current_syllable_phonemes = []
        stress_idx = 0
        
        for phoneme in phonemes:
            current_syllable_phonemes.append(phoneme)
            
            # Syllable boundary after vowel (simplified rule)
            if phoneme.is_vowel:
                stress = StressLevel.NONE
                if stress_idx < len(stress_pattern):
                    stress_val = stress_pattern[stress_idx]
                    stress = StressLevel(min(2, stress_val))
                    stress_idx += 1
                
                syllables.append(Syllable(
                    text=self._phonemes_to_text(current_syllable_phonemes),
                    phonemes=current_syllable_phonemes.copy(),
                    stress=stress
                ))
                current_syllable_phonemes = []
        
        # Handle trailing consonants
        if current_syllable_phonemes and syllables:
            syllables[-1].phonemes.extend(current_syllable_phonemes)
        elif current_syllable_phonemes:
            syllables.append(Syllable(
                text=word,
                phonemes=current_syllable_phonemes,
                stress=StressLevel.PRIMARY
            ))
        
        # Fallback: single syllable
        if not syllables:
            syllables.append(Syllable(
                text=word,
                phonemes=phonemes,
                stress=StressLevel.PRIMARY
            ))
        
        return LyricWord(
            text=word,
            syllables=syllables
        )
    
    def _phonemes_to_text(self, phonemes: List[Phoneme]) -> str:
        """Approximate text representation of phonemes."""
        return "".join(p.ipa for p in phonemes)
    
    def segment_line(self, line: str) -> List[LyricWord]:
        """Segment entire line into words with syllables."""
        words = re.findall(r"[a-zA-Z']+", line)
        return [self.segment_word(w) for w in words]


# =============================================================================
# FORMANT INTERPOLATION
# =============================================================================

def interpolate_formants(
    from_formants: Tuple[float, float, float],
    to_formants: Tuple[float, float, float],
    position: float  # 0-1
) -> Tuple[float, float, float]:
    """Interpolate between two formant sets."""
    return (
        from_formants[0] + (to_formants[0] - from_formants[0]) * position,
        from_formants[1] + (to_formants[1] - from_formants[1]) * position,
        from_formants[2] + (to_formants[2] - from_formants[2]) * position,
    )


def apply_coarticulation(phonemes: List[Phoneme], blend: float = 0.3) -> List[Phoneme]:
    """Apply coarticulation effects between adjacent phonemes."""
    if len(phonemes) < 2:
        return phonemes
    
    result = []
    for i, phoneme in enumerate(phonemes):
        new_formants = phoneme.formants
        
        if i > 0 and phonemes[i-1].is_vowel and phoneme.is_vowel:
            new_formants = interpolate_formants(
                phonemes[i-1].formants,
                phoneme.formants,
                1 - blend
            )
        elif i < len(phonemes) - 1 and phoneme.is_vowel and phonemes[i+1].is_vowel:
            new_formants = interpolate_formants(
                phoneme.formants,
                phonemes[i+1].formants,
                blend
            )
        
        result.append(Phoneme(
            ipa=phoneme.ipa,
            arpabet=phoneme.arpabet,
            duration_ms=phoneme.duration_ms,
            is_voiced=phoneme.is_voiced,
            is_vowel=phoneme.is_vowel,
            formants=new_formants
        ))
    
    return result


# =============================================================================
# MAIN API
# =============================================================================

_g2p = None
_segmenter = None

def get_g2p() -> G2PConverter:
    global _g2p
    if _g2p is None:
        _g2p = G2PConverter()
    return _g2p

def get_segmenter() -> SyllableSegmenter:
    global _segmenter
    if _segmenter is None:
        _segmenter = SyllableSegmenter(get_g2p())
    return _segmenter

def text_to_phonemes(text: str) -> List[Phoneme]:
    """Convert text to flat list of phonemes."""
    g2p = get_g2p()
    words = re.findall(r"[a-zA-Z']+", text)
    result = []
    for word in words:
        result.extend(g2p.word_to_phonemes(word))
    return result

def text_to_syllables(text: str) -> List[Syllable]:
    """Convert text to list of syllables."""
    segmenter = get_segmenter()
    words = segmenter.segment_line(text)
    result = []
    for word in words:
        result.extend(word.syllables)
    return result

def text_to_words(text: str) -> List[LyricWord]:
    """Convert text to list of annotated words."""
    return get_segmenter().segment_line(text)


if __name__ == "__main__":
    # Test
    test_line = "When I found you sleeping"
    
    print("=== Phoneme Test ===")
    phonemes = text_to_phonemes(test_line)
    print(f"Text: {test_line}")
    print(f"Phonemes: {[p.ipa for p in phonemes]}")
    
    print("\n=== Syllable Test ===")
    syllables = text_to_syllables(test_line)
    for syl in syllables:
        print(f"  {syl.text}: stress={syl.stress.name}, phonemes={[p.ipa for p in syl.phonemes]}")
    
    print("\n=== Word Test ===")
    words = text_to_words(test_line)
    for word in words:
        print(f"  {word.text}: {word.syllable_count} syllables, stress={word.stress_pattern}")
