"""
Kelly Lyric & Vocal Data Structures
Core dataclasses for lyric generation and vocal synthesis
"""
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
from enum import Enum


class SectionType(Enum):
    VERSE = "verse"
    CHORUS = "chorus"
    BRIDGE = "bridge"
    PRE_CHORUS = "pre_chorus"
    OUTRO = "outro"
    INTRO = "intro"
    HOOK = "hook"


class VocalStyleType(Enum):
    NATURAL = "natural"
    BREATHY = "breathy"
    BELT = "belt"
    WHISPER = "whisper"
    FALSETTO = "falsetto"
    SPOKEN = "spoken"
    CRY = "cry"
    FRY = "fry"


class StressLevel(Enum):
    NONE = 0
    SECONDARY = 1
    PRIMARY = 2


@dataclass
class Phoneme:
    """Single phoneme with acoustic properties."""
    ipa: str
    arpabet: str = ""
    duration_ms: float = 80.0
    is_voiced: bool = True
    is_vowel: bool = False
    formants: Tuple[float, float, float] = (500.0, 1500.0, 2500.0)  # F1, F2, F3
    
    @property
    def is_consonant(self) -> bool:
        return not self.is_vowel


@dataclass
class Syllable:
    """Single syllable with phoneme breakdown."""
    text: str
    phonemes: List[Phoneme] = field(default_factory=list)
    stress: StressLevel = StressLevel.NONE
    duration_beats: float = 0.5
    start_beat: float = 0.0
    
    @property
    def duration_ms(self) -> float:
        return sum(p.duration_ms for p in self.phonemes)
    
    @property
    def nucleus(self) -> Optional[Phoneme]:
        """Return the vowel nucleus."""
        for p in self.phonemes:
            if p.is_vowel:
                return p
        return None


@dataclass
class LyricWord:
    """Single word with syllable breakdown."""
    text: str
    syllables: List[Syllable] = field(default_factory=list)
    emphasis: bool = False
    start_beat: float = 0.0
    
    @property
    def syllable_count(self) -> int:
        return len(self.syllables)
    
    @property
    def stress_pattern(self) -> List[int]:
        return [s.stress.value for s in self.syllables]


@dataclass
class LyricLine:
    """Single line of lyrics with full annotation."""
    text: str
    words: List[LyricWord] = field(default_factory=list)
    section_type: SectionType = SectionType.VERSE
    line_number: int = 0
    start_beat: float = 0.0
    duration_beats: float = 4.0
    emotion_valence: float = 0.0
    emotion_arousal: float = 0.5
    emotion_dominance: float = 0.5
    
    @property
    def syllables(self) -> List[Syllable]:
        result = []
        for w in self.words:
            result.extend(w.syllables)
        return result
    
    @property
    def phonemes(self) -> List[Phoneme]:
        result = []
        for s in self.syllables:
            result.extend(s.phonemes)
        return result
    
    @property
    def syllable_count(self) -> int:
        return sum(w.syllable_count for w in self.words)
    
    @property
    def stress_pattern(self) -> List[int]:
        pattern = []
        for w in self.words:
            pattern.extend(w.stress_pattern)
        return pattern


@dataclass
class LyricSection:
    """Section of lyrics (verse, chorus, etc.)."""
    section_type: SectionType
    lines: List[LyricLine] = field(default_factory=list)
    repeat_count: int = 1
    start_bar: int = 0
    duration_bars: int = 8
    
    @property
    def total_lines(self) -> int:
        return len(self.lines) * self.repeat_count


@dataclass
class SongLyrics:
    """Complete song lyrics structure."""
    title: str = ""
    sections: List[LyricSection] = field(default_factory=list)
    key: str = "C"
    tempo: int = 120
    time_signature: Tuple[int, int] = (4, 4)
    
    @property
    def all_lines(self) -> List[LyricLine]:
        result = []
        for section in self.sections:
            result.extend(section.lines)
        return result
    
    @property
    def full_text(self) -> str:
        lines = []
        for section in self.sections:
            lines.append(f"[{section.section_type.value}]")
            for line in section.lines:
                lines.append(line.text)
            lines.append("")
        return "\n".join(lines)


@dataclass
class VocalExpression:
    """Expressive parameters for vocal synthesis."""
    breathiness: float = 0.3  # 0-1
    vibrato_rate: float = 5.5  # Hz
    vibrato_depth: float = 20.0  # cents
    vibrato_delay: float = 0.15  # seconds before vibrato starts
    pitch_drift: float = 0.0  # cents
    dynamics: float = 0.7  # 0-1
    attack_time: float = 0.02  # seconds
    release_time: float = 0.1  # seconds
    voice_type: VocalStyleType = VocalStyleType.NATURAL


@dataclass
class VocalNote:
    """Single vocal note with all parameters."""
    pitch_midi: int
    start_time: float  # seconds
    duration: float  # seconds
    syllable: Optional[Syllable] = None
    expression: VocalExpression = field(default_factory=VocalExpression)
    pitch_bend_cents: float = 0.0
    portamento_time: float = 0.0
    
    @property
    def end_time(self) -> float:
        return self.start_time + self.duration


@dataclass
class VocalPhrase:
    """Phrase of vocal notes."""
    notes: List[VocalNote] = field(default_factory=list)
    phrase_id: int = 0
    breath_before: bool = True
    breath_duration: float = 0.3
    
    @property
    def duration(self) -> float:
        if not self.notes:
            return 0.0
        return self.notes[-1].end_time - self.notes[0].start_time


@dataclass
class VocalTrack:
    """Complete vocal track."""
    phrases: List[VocalPhrase] = field(default_factory=list)
    lyrics: Optional[SongLyrics] = None
    base_expression: VocalExpression = field(default_factory=VocalExpression)
    
    @property
    def all_notes(self) -> List[VocalNote]:
        result = []
        for phrase in self.phrases:
            result.extend(phrase.notes)
        return result
    
    @property
    def duration(self) -> float:
        if not self.phrases:
            return 0.0
        all_notes = self.all_notes
        if not all_notes:
            return 0.0
        return max(n.end_time for n in all_notes)


# Emotion-to-Vocal mapping helpers
EMOTION_VOCAL_MAP = {
    "grief": VocalExpression(breathiness=0.6, vibrato_depth=30, dynamics=0.4),
    "joy": VocalExpression(breathiness=0.2, vibrato_depth=15, dynamics=0.8),
    "anger": VocalExpression(breathiness=0.1, vibrato_depth=10, dynamics=0.95),
    "fear": VocalExpression(breathiness=0.7, vibrato_depth=40, dynamics=0.5),
    "longing": VocalExpression(breathiness=0.5, vibrato_depth=25, dynamics=0.55),
    "defiance": VocalExpression(breathiness=0.15, vibrato_depth=12, dynamics=0.85),
}


def emotion_to_vocal_expression(
    valence: float,
    arousal: float,
    dominance: float
) -> VocalExpression:
    """Convert VAD vector to vocal expression parameters."""
    return VocalExpression(
        breathiness=0.3 + 0.4 * (1 - dominance) + 0.2 * (1 - arousal),
        vibrato_rate=4.5 + 2.0 * arousal,
        vibrato_depth=15 + 25 * (1 - valence) * (1 - dominance),
        vibrato_delay=0.1 + 0.15 * (1 - arousal),
        pitch_drift=5 * (1 - valence) - 5 * valence,  # flat when sad
        dynamics=0.4 + 0.5 * arousal + 0.1 * dominance,
        attack_time=0.01 + 0.03 * (1 - arousal),
        release_time=0.05 + 0.15 * (1 - arousal),
    )
