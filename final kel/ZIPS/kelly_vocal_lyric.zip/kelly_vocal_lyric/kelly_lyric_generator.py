"""
Kelly Lyric Generator
Emotion-driven lyric generation with prosody and semantic expansion
"""
from typing import List, Dict, Tuple, Optional, Set
from dataclasses import dataclass
import random
import re

from kelly_lyric_structures import (
    LyricLine, LyricWord, LyricSection, SongLyrics,
    SectionType, StressLevel, Syllable
)
from kelly_phoneme_processor import get_segmenter, text_to_words


# =============================================================================
# EMOTION → THEME VOCABULARY
# =============================================================================

EMOTION_VOCABULARY = {
    "grief": {
        "nouns": ["ghost", "shadow", "ashes", "silence", "echo", "grave", "tears", "void", "hollow", "weight"],
        "verbs": ["fade", "drown", "haunt", "crumble", "shatter", "wither", "collapse", "surrender"],
        "adjectives": ["empty", "cold", "broken", "silent", "heavy", "dark", "lost", "numb"],
        "imagery": ["rain on glass", "empty chair", "cold sheets", "fading photograph", "hollow chest"],
    },
    "longing": {
        "nouns": ["distance", "memory", "horizon", "ghost", "dream", "bridge", "shore", "tide"],
        "verbs": ["reach", "wait", "ache", "yearn", "drift", "search", "remember", "trace"],
        "adjectives": ["far", "distant", "faint", "endless", "bittersweet", "soft", "tender"],
        "imagery": ["open road", "setting sun", "empty arms", "photograph", "old song", "distant light"],
    },
    "anger": {
        "nouns": ["fire", "storm", "blade", "chains", "wall", "war", "poison", "wound"],
        "verbs": ["burn", "break", "strike", "scream", "rage", "tear", "destroy", "fight"],
        "adjectives": ["fierce", "sharp", "hot", "bitter", "relentless", "raw", "violent"],
        "imagery": ["clenched fists", "red vision", "breaking glass", "burning bridge", "thunder"],
    },
    "joy": {
        "nouns": ["light", "sun", "wings", "dance", "laughter", "bloom", "spark", "sky"],
        "verbs": ["soar", "shine", "bloom", "dance", "glow", "rise", "embrace", "celebrate"],
        "adjectives": ["bright", "warm", "golden", "free", "alive", "radiant", "boundless"],
        "imagery": ["sunrise", "open sky", "dancing flames", "golden hour", "first breath"],
    },
    "fear": {
        "nouns": ["shadow", "dark", "edge", "abyss", "whisper", "fog", "void", "unknown"],
        "verbs": ["flee", "hide", "tremble", "freeze", "sink", "spiral", "suffocate"],
        "adjectives": ["cold", "dark", "sharp", "suffocating", "endless", "paralyzing"],
        "imagery": ["closing walls", "cold sweat", "racing heart", "dark corridor", "falling"],
    },
    "hope": {
        "nouns": ["dawn", "seed", "spark", "bridge", "anchor", "horizon", "breath", "light"],
        "verbs": ["rise", "grow", "reach", "climb", "believe", "build", "heal", "emerge"],
        "adjectives": ["new", "small", "steady", "patient", "quiet", "gentle", "stubborn"],
        "imagery": ["first light", "green shoot", "clearing sky", "steady flame", "open door"],
    },
    "defiance": {
        "nouns": ["fire", "storm", "crown", "throne", "banner", "fortress", "armor", "sword"],
        "verbs": ["stand", "rise", "roar", "refuse", "resist", "claim", "conquer", "burn"],
        "adjectives": ["unbroken", "fierce", "proud", "relentless", "untamed", "bold"],
        "imagery": ["standing tall", "raised fist", "unblinking eye", "against the wind"],
    },
}

RHYME_FAMILIES = {
    "ay": ["day", "way", "say", "stay", "away", "play", "gray", "fade", "made", "shade"],
    "ight": ["night", "light", "fight", "right", "sight", "bright", "flight", "tight"],
    "ow": ["know", "go", "show", "flow", "grow", "glow", "below", "shadow", "follow"],
    "ain": ["pain", "rain", "chain", "vain", "remain", "again", "contain", "stain"],
    "all": ["fall", "call", "wall", "small", "tall", "hall", "crawl"],
    "eart": ["heart", "start", "part", "apart", "art", "dart"],
    "ove": ["love", "above", "dove", "shove"],
    "ire": ["fire", "higher", "desire", "wire", "tired", "inspire"],
    "ound": ["found", "sound", "ground", "around", "bound", "drown"],
    "eep": ["deep", "sleep", "keep", "weep", "creep", "steep"],
    "ee": ["free", "see", "be", "me", "we", "tree", "flee"],
    "ime": ["time", "climb", "rhyme", "crime", "sublime"],
}


# =============================================================================
# METER TEMPLATES
# =============================================================================

@dataclass
class MeterTemplate:
    name: str
    pattern: List[int]  # 0=unstressed, 1=stressed
    syllables_per_line: int
    description: str

METER_TEMPLATES = {
    "iambic_tetrameter": MeterTemplate(
        "iambic_tetrameter",
        [0, 1, 0, 1, 0, 1, 0, 1],
        8,
        "da-DUM da-DUM da-DUM da-DUM"
    ),
    "iambic_pentameter": MeterTemplate(
        "iambic_pentameter",
        [0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
        10,
        "da-DUM da-DUM da-DUM da-DUM da-DUM"
    ),
    "trochaic_tetrameter": MeterTemplate(
        "trochaic_tetrameter",
        [1, 0, 1, 0, 1, 0, 1, 0],
        8,
        "DUM-da DUM-da DUM-da DUM-da"
    ),
    "free_verse": MeterTemplate(
        "free_verse",
        [],  # No fixed pattern
        0,
        "Variable rhythm"
    ),
    "ballad": MeterTemplate(
        "ballad",
        [0, 1, 0, 1, 0, 1, 0],
        7,
        "Common meter (4-3-4-3)"
    ),
}


# =============================================================================
# LYRIC LINE GENERATOR
# =============================================================================

class LyricLineGenerator:
    """Generate individual lyric lines with emotion-driven vocabulary."""
    
    def __init__(self):
        self.segmenter = get_segmenter()
        self.used_words: Set[str] = set()
    
    def generate_line(
        self,
        emotion: str,
        target_syllables: int = 8,
        rhyme_with: Optional[str] = None,
        meter: Optional[MeterTemplate] = None
    ) -> str:
        """Generate a single lyric line."""
        vocab = EMOTION_VOCABULARY.get(emotion, EMOTION_VOCABULARY["longing"])
        
        # Build word pool
        pool = (
            vocab["nouns"] + vocab["verbs"] + vocab["adjectives"]
        )
        pool = [w for w in pool if w not in self.used_words]
        
        if not pool:
            self.used_words.clear()
            pool = vocab["nouns"] + vocab["verbs"] + vocab["adjectives"]
        
        # Simple template-based generation
        templates = [
            "{adj} {noun} {verb}s",
            "I {verb} the {adj} {noun}",
            "{adj} and {adj2}",
            "like a {noun} in the {noun2}",
            "the {noun} {verb}s {adv}",
            "{verb}ing through the {noun}",
            "when {noun}s {verb}",
            "{adj} {noun}s {verb}",
        ]
        
        template = random.choice(templates)
        
        # Fill template
        result = template
        
        def pick(category: str) -> str:
            words = vocab.get(category, vocab["nouns"])
            available = [w for w in words if w not in self.used_words]
            if not available:
                available = words
            word = random.choice(available)
            self.used_words.add(word)
            return word
        
        result = result.replace("{noun}", pick("nouns"))
        result = result.replace("{noun2}", pick("nouns"))
        result = result.replace("{verb}", pick("verbs"))
        result = result.replace("{adj}", pick("adjectives"))
        result = result.replace("{adj2}", pick("adjectives"))
        result = result.replace("{adv}", random.choice(["slowly", "softly", "quietly", "away"]))
        
        # Handle rhyme constraint
        if rhyme_with:
            rhyme_word = self._find_rhyme(rhyme_with, vocab)
            if rhyme_word:
                result = result.rstrip(".") + " " + rhyme_word
        
        return result.strip()
    
    def _find_rhyme(self, word: str, vocab: dict) -> Optional[str]:
        """Find a word that rhymes with the given word."""
        word_lower = word.lower()
        
        # Check rhyme families
        for family, words in RHYME_FAMILIES.items():
            if word_lower in words:
                candidates = [w for w in words if w != word_lower]
                if candidates:
                    return random.choice(candidates)
        
        # Fallback: ending match
        ending = word_lower[-2:] if len(word_lower) > 2 else word_lower
        all_words = vocab["nouns"] + vocab["verbs"] + vocab["adjectives"]
        matches = [w for w in all_words if w.endswith(ending) and w != word_lower]
        
        return random.choice(matches) if matches else None
    
    def generate_imagery_line(self, emotion: str) -> str:
        """Generate a line using imagery."""
        vocab = EMOTION_VOCABULARY.get(emotion, EMOTION_VOCABULARY["longing"])
        imagery = vocab.get("imagery", ["the night", "the rain"])
        return random.choice(imagery)


# =============================================================================
# SECTION GENERATOR
# =============================================================================

class SectionGenerator:
    """Generate complete sections (verse, chorus, etc.)."""
    
    def __init__(self):
        self.line_generator = LyricLineGenerator()
    
    def generate_verse(
        self,
        emotion: str,
        lines: int = 4,
        rhyme_scheme: str = "ABAB"
    ) -> LyricSection:
        """Generate a verse section."""
        generated_lines = []
        rhyme_targets: Dict[str, str] = {}
        
        for i in range(lines):
            rhyme_key = rhyme_scheme[i % len(rhyme_scheme)]
            rhyme_with = rhyme_targets.get(rhyme_key)
            
            text = self.line_generator.generate_line(
                emotion=emotion,
                rhyme_with=rhyme_with
            )
            
            # Get last word for rhyme tracking
            words = text.split()
            if words:
                rhyme_targets[rhyme_key] = words[-1]
            
            generated_lines.append(LyricLine(
                text=text,
                words=text_to_words(text),
                section_type=SectionType.VERSE,
                line_number=i
            ))
        
        return LyricSection(
            section_type=SectionType.VERSE,
            lines=generated_lines
        )
    
    def generate_chorus(
        self,
        emotion: str,
        lines: int = 4,
        hook_line: Optional[str] = None
    ) -> LyricSection:
        """Generate a chorus section."""
        generated_lines = []
        
        # First line is the hook
        if hook_line:
            hook = hook_line
        else:
            hook = self.line_generator.generate_line(emotion, target_syllables=6)
        
        generated_lines.append(LyricLine(
            text=hook,
            words=text_to_words(hook),
            section_type=SectionType.CHORUS,
            line_number=0
        ))
        
        for i in range(1, lines):
            # Every other line might repeat the hook
            if i % 2 == 0 and lines > 2:
                text = hook
            else:
                text = self.line_generator.generate_line(emotion)
            
            generated_lines.append(LyricLine(
                text=text,
                words=text_to_words(text),
                section_type=SectionType.CHORUS,
                line_number=i
            ))
        
        return LyricSection(
            section_type=SectionType.CHORUS,
            lines=generated_lines
        )
    
    def generate_bridge(self, emotion: str, lines: int = 2) -> LyricSection:
        """Generate a bridge section with contrasting imagery."""
        # Slightly shift emotion for bridge
        contrast_map = {
            "grief": "hope",
            "anger": "defiance",
            "fear": "hope",
            "joy": "longing",
            "longing": "grief",
            "hope": "defiance",
            "defiance": "anger",
        }
        contrast_emotion = contrast_map.get(emotion, emotion)
        
        generated_lines = []
        for i in range(lines):
            text = self.line_generator.generate_imagery_line(contrast_emotion)
            generated_lines.append(LyricLine(
                text=text,
                words=text_to_words(text),
                section_type=SectionType.BRIDGE,
                line_number=i
            ))
        
        return LyricSection(
            section_type=SectionType.BRIDGE,
            lines=generated_lines
        )


# =============================================================================
# SONG GENERATOR
# =============================================================================

class LyricGenerator:
    """Generate complete song lyrics."""
    
    def __init__(self):
        self.section_generator = SectionGenerator()
    
    def generate(
        self,
        title: str,
        emotion: str,
        structure: str = "VCVC",  # V=verse, C=chorus, B=bridge
        tempo: int = 120,
        key: str = "C"
    ) -> SongLyrics:
        """Generate complete song lyrics."""
        sections = []
        chorus = None
        
        for char in structure.upper():
            if char == "V":
                sections.append(self.section_generator.generate_verse(emotion))
            elif char == "C":
                if chorus is None:
                    chorus = self.section_generator.generate_chorus(emotion)
                sections.append(chorus)
            elif char == "B":
                sections.append(self.section_generator.generate_bridge(emotion))
        
        return SongLyrics(
            title=title,
            sections=sections,
            tempo=tempo,
            key=key
        )
    
    def generate_from_intent(
        self,
        wound_description: str,
        valence: float,
        arousal: float,
        dominance: float
    ) -> SongLyrics:
        """Generate lyrics from Kelly intent schema."""
        # Map VAD to emotion
        if valence < -0.3:
            if arousal > 0.6:
                emotion = "anger"
            elif dominance < 0.4:
                emotion = "grief"
            else:
                emotion = "longing"
        elif valence > 0.3:
            if arousal > 0.6:
                emotion = "joy"
            else:
                emotion = "hope"
        else:
            if arousal > 0.7:
                emotion = "defiance"
            elif dominance < 0.4:
                emotion = "fear"
            else:
                emotion = "longing"
        
        # Determine structure from arousal
        if arousal > 0.7:
            structure = "VCVCBC"  # More dynamic
        else:
            structure = "VCVC"  # Standard
        
        # Extract title words from wound
        title_words = wound_description.split()[:3]
        title = " ".join(title_words).title() if title_words else "Untitled"
        
        return self.generate(
            title=title,
            emotion=emotion,
            structure=structure
        )


# =============================================================================
# PROSODY ANALYZER
# =============================================================================

class ProsodyAnalyzer:
    """Analyze and score prosodic quality of lyrics."""
    
    def __init__(self):
        self.segmenter = get_segmenter()
    
    def analyze_line(self, line: LyricLine) -> Dict:
        """Analyze prosodic properties of a line."""
        syllables = line.syllables
        
        return {
            "syllable_count": len(syllables),
            "stress_pattern": line.stress_pattern,
            "has_natural_rhythm": self._check_natural_rhythm(syllables),
            "breath_positions": self._find_breath_positions(line.words),
        }
    
    def _check_natural_rhythm(self, syllables: List[Syllable]) -> bool:
        """Check if stress pattern is natural."""
        if len(syllables) < 2:
            return True
        
        # Avoid consecutive primary stresses
        for i in range(len(syllables) - 1):
            if (syllables[i].stress == StressLevel.PRIMARY and
                syllables[i+1].stress == StressLevel.PRIMARY):
                return False
        return True
    
    def _find_breath_positions(self, words: List[LyricWord]) -> List[int]:
        """Find natural breath/pause positions."""
        positions = []
        syllable_idx = 0
        
        for i, word in enumerate(words):
            syllable_idx += word.syllable_count
            
            # Natural pause after 3-4 words or punctuation
            if (i + 1) % 4 == 0 or word.text.endswith((",", ".", "!", "?")):
                positions.append(syllable_idx)
        
        return positions
    
    def score_meter_fit(
        self,
        line: LyricLine,
        target_meter: MeterTemplate
    ) -> float:
        """Score how well line fits target meter (0-1)."""
        if not target_meter.pattern:
            return 1.0  # Free verse always fits
        
        stress = line.stress_pattern
        pattern = target_meter.pattern
        
        if len(stress) != len(pattern):
            # Penalize length mismatch
            return 0.5 * (1 - abs(len(stress) - len(pattern)) / max(len(stress), len(pattern), 1))
        
        matches = sum(1 for s, p in zip(stress, pattern) if s > 0 and p > 0 or s == 0 and p == 0)
        return matches / len(pattern)


# =============================================================================
# MAIN API
# =============================================================================

def generate_lyrics(
    emotion: str = "longing",
    structure: str = "VCVC",
    title: str = "Untitled"
) -> SongLyrics:
    """Quick API for lyric generation."""
    generator = LyricGenerator()
    return generator.generate(title=title, emotion=emotion, structure=structure)


def analyze_lyrics(lyrics: SongLyrics) -> Dict:
    """Analyze prosodic properties of lyrics."""
    analyzer = ProsodyAnalyzer()
    analysis = {
        "total_lines": len(lyrics.all_lines),
        "sections": len(lyrics.sections),
        "lines_analysis": []
    }
    
    for line in lyrics.all_lines:
        analysis["lines_analysis"].append(analyzer.analyze_line(line))
    
    return analysis


if __name__ == "__main__":
    # Test
    print("=== Generating Grief Song ===\n")
    lyrics = generate_lyrics(
        emotion="grief",
        structure="VCVC",
        title="When I Found You Sleeping"
    )
    
    print(lyrics.full_text)
    
    print("\n=== Prosody Analysis ===")
    analysis = analyze_lyrics(lyrics)
    print(f"Total lines: {analysis['total_lines']}")
    print(f"Sections: {analysis['sections']}")
    
    for i, la in enumerate(analysis["lines_analysis"][:4]):
        print(f"Line {i+1}: {la['syllable_count']} syllables, natural={la['has_natural_rhythm']}")
