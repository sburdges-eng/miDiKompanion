# Kelly Brain + ML Integration

## Files

| File | Purpose |
|------|---------|
| `KellyTypes.h` | **Unified types** - resolves all conflicts |
| `KellyBrain.h/cpp` | **Intent Pipeline** - Wound → IntentResult |
| `MLBridge.h/cpp` | **ML Connection** - Audio → Emotion → Intent |
| `MultiModelProcessor.h` | **5-Model ML** - neural network inference |

## Type Conflicts Fixed

**Before (conflicting):**
```cpp
// midi_pipeline.h
struct MidiNote { uint8_t note; uint32_t time; ... };

// Types.h  
struct MidiNote { int pitch; int startTick; ... };

// emotion_engine.h
struct EmotionNode { int id; ... };

// Types.h
struct EmotionNode { std::string name; ... };
```

**After (unified in KellyTypes.h):**
```cpp
struct MidiNote {
    int pitch, startTick, durationTicks, velocity, channel;
    // Compatibility aliases
    uint8_t note() const;
    uint32_t time() const;
};

struct EmotionNode {
    int id;
    std::string name, category;
    EmotionCategory categoryEnum;
    float valence, arousal, dominance, intensity;
    MusicalAttributes musicalAttributes;
    // ... complete definition
};
```

## Integration

### 1. Replace old headers

```cpp
// Old
#include "Types.h"
#include "midi_pipeline.h"
#include "emotion_engine.h"

// New
#include "KellyTypes.h"
```

### 2. Use KellyBrain directly

```cpp
#include "KellyBrain.h"

kelly::KellyBrain brain;
brain.initialize("./data");

// From wound
kelly::Wound wound;
wound.description = "Finding Kelly sleeping forever";
wound.expression = "Misdirection - sounds like love";
auto intent = brain.fromWound(wound);

// From text
auto intent = brain.fromText("feeling lost and hopeless");

// From emotion
auto intent = brain.fromEmotion("grief", 0.8f);

// Generate MIDI
auto midi = brain.generateMidi(intent, 8);  // 8 bars
```

### 3. Use IntentPipeline + EmotionThesaurus

```cpp
kelly::IntentPipeline pipeline;

// Access thesaurus
auto& thesaurus = pipeline.thesaurus();
auto* grief = thesaurus.findByName("grief");
auto* similar = thesaurus.findNearby(*grief, 0.3f);

// Process
auto intent = pipeline.processEmotion(*grief, 0.9f);
```

### 4. Connect ML Models

```cpp
#include "MLBridge.h"

kelly::MLIntentPipeline mlPipeline;
mlPipeline.initialize("./models", "./data");

// Audio → Intent → MIDI
auto midi = mlPipeline.generateFromAudio(audioBuffer, numSamples, 8);

// Async (real-time safe)
mlPipeline.submitAudio(audioBuffer, numSamples);
// ... in timer callback:
if (mlPipeline.hasResult()) {
    auto intent = mlPipeline.getResult();
}

// Hybrid: audio + text
auto intent = mlPipeline.processHybrid(
    audioBuffer, numSamples,
    "feeling heartbroken");
```

## Data Flow

```
Audio Buffer
    ↓
FeatureExtractor (128-dim mel spectrogram)
    ↓
EmotionRecognizer (ML: 128→64 emotion embedding)
    ↓
EmotionEmbeddingMapper → EmotionNode
    ↓
IntentPipeline.processWound()
    ↓
IntentResult (key, mode, tempo, chords, rule-breaks)
    ↓
┌─────────────────────────────────────────┐
│ MelodyTransformer  → melody notes       │
│ HarmonyPredictor   → chord progression  │
│ DynamicsEngine     → velocity/timing    │
│ GroovePredictor    → swing/humanization │
└─────────────────────────────────────────┘
    ↓
GeneratedMidi
```

## CMake Integration

```cmake
# Add source files
set(KELLY_BRAIN_SOURCES
    KellyTypes.h
    KellyBrain.h
    KellyBrain.cpp
    MLBridge.h
    MLBridge.cpp
    MultiModelProcessor.h
)

# Link with existing engine
target_sources(KellyMidiCompanion PRIVATE ${KELLY_BRAIN_SOURCES})
```

## Python Bridge (unchanged)

```python
from kelly import IntentPipeline, EmotionThesaurus

pipeline = IntentPipeline()
result = pipeline.process_wound({
    "description": "Finding Kelly sleeping forever",
    "expression": "Misdirection piece",
    "urgency": 0.9
})

print(result.key, result.mode, result.tempo_bpm)
print(result.chord_progression)
print(result.rule_breaks)
```
