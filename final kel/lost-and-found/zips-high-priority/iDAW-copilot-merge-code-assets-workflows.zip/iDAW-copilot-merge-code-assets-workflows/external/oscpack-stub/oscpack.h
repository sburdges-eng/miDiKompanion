#pragma once
// Stub header for oscpack - actual implementation in Week 6
// This allows the build to proceed without the external dependency
