from setuptools import setup, find_packages

setup(
    name="penta_core",
    version="0.1.0",
    description="Penta Core Python API for C++ engine integration",
    author="sburdges-eng",
    packages=find_packages(),
    install_requires=[],
    include_package_data=True,
)