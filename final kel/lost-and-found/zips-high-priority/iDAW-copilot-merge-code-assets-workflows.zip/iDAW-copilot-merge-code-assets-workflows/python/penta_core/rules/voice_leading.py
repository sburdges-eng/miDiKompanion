class VoiceLeadingRules:
    @staticmethod
    def get_rules_by_context(context):
        return {}
    @staticmethod
    def get_rules_by_severity(severity):
        return {}
