class CounterpointRules:
    @staticmethod
    def get_species_rules(species):
        return {}
