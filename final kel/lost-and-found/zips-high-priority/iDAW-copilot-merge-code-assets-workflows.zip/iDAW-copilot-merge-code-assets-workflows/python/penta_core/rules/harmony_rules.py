class HarmonyRules:
    @staticmethod
    def get_all_rules():
        return {}
    @staticmethod
    def get_chord_intervals(chord_type):
        return []
