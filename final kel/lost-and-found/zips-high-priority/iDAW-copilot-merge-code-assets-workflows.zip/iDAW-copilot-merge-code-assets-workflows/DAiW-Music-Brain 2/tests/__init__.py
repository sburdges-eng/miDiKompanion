"""Tests for music_brain package."""
