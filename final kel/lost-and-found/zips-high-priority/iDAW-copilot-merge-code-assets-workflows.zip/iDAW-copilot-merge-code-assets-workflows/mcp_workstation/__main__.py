"""
MCP Workstation - Module Entry Point

Allows running as: python -m mcp_workstation
"""

from .cli import main

if __name__ == "__main__":
    main()
