#pragma once

#include "Types.h"
#include <string>
#include <vector>
#include <map>
#include <functional>

namespace kelly {

//=============================================================================
// ENUMS
//=============================================================================

enum class RuleCategory {
    Harmony,
    Rhythm,
    Dynamics,
    Arrangement,
    Production,
    Melody
};

enum class RuleSeverity {
    Subtle,      // Barely noticeable
    Moderate,    // Clearly intentional
    Dramatic,    // Bold statement
    Extreme      // Breaks convention completely
};

//=============================================================================
// DATA STRUCTURES
//=============================================================================

struct RuleBreak {
    std::string id;
    std::string name;
    RuleCategory category;
    RuleSeverity severity;
    std::string description;
    std::string emotionalJustification;
    std::map<std::string, float> musicalImpact;
    std::vector<std::string> compatibleEmotions;
};

struct RuleBreakResult {
    RuleBreak rule;
    std::string appliedEffect;
    std::map<std::string, float> parameters;
    bool wasApplied;
};

struct RuleBreakConfig {
    float intensity = 0.5f;
    std::vector<std::string> allowedCategories;
    RuleSeverity maxSeverity = RuleSeverity::Dramatic;
    bool requireJustification = true;
};

//=============================================================================
// RULE BREAK ENGINE
//=============================================================================

class RuleBreakEngine {
public:
    RuleBreakEngine();
    
    std::vector<RuleBreak> getRuleBreaksForEmotion(const std::string& emotion) const;
    std::vector<RuleBreak> getRuleBreaksByCategory(RuleCategory category) const;
    
    RuleBreakResult apply(const std::string& ruleId, const std::string& emotion, float intensity);
    std::vector<RuleBreakResult> applyMultiple(
        const std::vector<std::string>& ruleIds,
        const std::string& emotion,
        float intensity
    );
    
    const RuleBreak* getRule(const std::string& id) const;
    std::vector<RuleBreak> suggestRuleBreaks(
        const std::string& emotion,
        float intensity,
        int maxSuggestions = 3
    ) const;
    
    void registerRule(const RuleBreak& rule);
    size_t getRuleCount() const { return rules_.size(); }

private:
    std::map<std::string, RuleBreak> rules_;
    std::map<std::string, std::vector<std::string>> emotionToRules_;
    
    void initializeRules();
    void registerEmotionMapping(const std::string& emotion, const std::string& ruleId);
    bool isCompatible(const RuleBreak& rule, const std::string& emotion) const;
    float calculateEffectiveness(const RuleBreak& rule, const std::string& emotion, float intensity) const;
};

} // namespace kelly
