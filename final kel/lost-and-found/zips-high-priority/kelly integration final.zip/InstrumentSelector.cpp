#include "InstrumentSelector.h"
#include <algorithm>
#include <random>

namespace kelly {

InstrumentSelector::InstrumentSelector() {
    initializeMappings();
}

void InstrumentSelector::initializeMappings() {
    // GM Program names
    gmProgramNames_[0] = "Acoustic Grand Piano";
    gmProgramNames_[4] = "Electric Piano 1";
    gmProgramNames_[24] = "Acoustic Guitar (nylon)";
    gmProgramNames_[25] = "Acoustic Guitar (steel)";
    gmProgramNames_[32] = "Acoustic Bass";
    gmProgramNames_[33] = "Electric Bass (finger)";
    gmProgramNames_[38] = "Synth Bass 1";
    gmProgramNames_[40] = "Violin";
    gmProgramNames_[42] = "Cello";
    gmProgramNames_[48] = "String Ensemble 1";
    gmProgramNames_[56] = "Trumpet";
    gmProgramNames_[65] = "Alto Sax";
    gmProgramNames_[71] = "Clarinet";
    gmProgramNames_[73] = "Flute";
    gmProgramNames_[80] = "Lead 1 (square)";
    gmProgramNames_[81] = "Lead 2 (sawtooth)";
    gmProgramNames_[88] = "Pad 1 (new age)";
    gmProgramNames_[89] = "Pad 2 (warm)";
    gmProgramNames_[91] = "Pad 4 (choir)";
    gmProgramNames_[95] = "Pad 8 (sweep)";
    
    // Categories
    for (int i = 0; i <= 7; ++i) gmProgramCategories_[i] = InstrumentCategory::Piano;
    for (int i = 24; i <= 31; ++i) gmProgramCategories_[i] = InstrumentCategory::Strings;
    for (int i = 32; i <= 39; ++i) gmProgramCategories_[i] = InstrumentCategory::Bass;
    for (int i = 40; i <= 47; ++i) gmProgramCategories_[i] = InstrumentCategory::Strings;
    for (int i = 48; i <= 55; ++i) gmProgramCategories_[i] = InstrumentCategory::Strings;
    for (int i = 56; i <= 63; ++i) gmProgramCategories_[i] = InstrumentCategory::Brass;
    for (int i = 64; i <= 79; ++i) gmProgramCategories_[i] = InstrumentCategory::Woodwind;
    for (int i = 80; i <= 87; ++i) gmProgramCategories_[i] = InstrumentCategory::Lead;
    for (int i = 88; i <= 95; ++i) gmProgramCategories_[i] = InstrumentCategory::Pad;
    for (int i = 96; i <= 103; ++i) gmProgramCategories_[i] = InstrumentCategory::SoundFX;
    for (int i = 104; i <= 111; ++i) gmProgramCategories_[i] = InstrumentCategory::Ethnic;
    for (int i = 112; i <= 119; ++i) gmProgramCategories_[i] = InstrumentCategory::Percussion;
    
    // Emotion to instruments
    emotionToInstruments_["grief"] = {0, 42, 48, 89, 91};
    emotionToInstruments_["sadness"] = {0, 42, 91, 73};
    emotionToInstruments_["hope"] = {0, 48, 73, 88};
    emotionToInstruments_["anger"] = {29, 30, 38, 56, 80};
    emotionToInstruments_["fear"] = {44, 48, 95, 97};
    emotionToInstruments_["joy"] = {0, 4, 48, 56, 73};
    emotionToInstruments_["anxiety"] = {4, 44, 95, 81};
    emotionToInstruments_["tension"] = {44, 48, 95, 80};
    emotionToInstruments_["peace"] = {0, 46, 88, 91};
    
    // Genre to instruments
    genreToInstruments_["classical"] = {0, 40, 42, 48, 73};
    genreToInstruments_["jazz"] = {0, 4, 33, 65, 56};
    genreToInstruments_["rock"] = {29, 30, 34, 38};
    genreToInstruments_["pop"] = {0, 4, 33, 48, 89};
    genreToInstruments_["electronic"] = {38, 80, 81, 88, 95};
    genreToInstruments_["ambient"] = {88, 89, 91, 95, 97};
    genreToInstruments_["lo-fi"] = {0, 4, 33, 89};
    
    // Role to instruments
    roleToInstruments_[InstrumentRole::Melody] = {0, 73, 40, 65, 80};
    roleToInstruments_[InstrumentRole::Harmony] = {0, 4, 48, 88, 89};
    roleToInstruments_[InstrumentRole::Bass] = {32, 33, 34, 38, 39};
    roleToInstruments_[InstrumentRole::Rhythm] = {0, 4, 24, 25};
    roleToInstruments_[InstrumentRole::Pad] = {88, 89, 90, 91, 95};
    roleToInstruments_[InstrumentRole::Lead] = {80, 81, 82, 84};
    roleToInstruments_[InstrumentRole::Fill] = {9, 11, 14, 46};
    roleToInstruments_[InstrumentRole::Accent] = {14, 55, 112, 114};
}

InstrumentChoice InstrumentSelector::selectForRole(
    InstrumentRole role,
    const std::string& emotion,
    const std::string& genre
) {
    InstrumentChoice choice;
    
    // Get candidates for role
    auto roleIt = roleToInstruments_.find(role);
    if (roleIt == roleToInstruments_.end()) {
        choice.gmProgram = 0;
        choice.name = "Acoustic Grand Piano";
        choice.category = InstrumentCategory::Piano;
        choice.emotionalFit = 0.5f;
        choice.channel = 0;
        return choice;
    }
    
    std::vector<int> candidates = roleIt->second;
    
    // Filter by emotion preference
    auto emotionIt = emotionToInstruments_.find(emotion);
    if (emotionIt != emotionToInstruments_.end()) {
        std::vector<int> filtered;
        for (int prog : candidates) {
            if (std::find(emotionIt->second.begin(), emotionIt->second.end(), prog) 
                != emotionIt->second.end()) {
                filtered.push_back(prog);
            }
        }
        if (!filtered.empty()) candidates = filtered;
    }
    
    // Score and select best
    float bestFit = 0;
    int bestProg = candidates[0];
    
    for (int prog : candidates) {
        float fit = calculateFit(prog, emotion, role);
        if (fit > bestFit) {
            bestFit = fit;
            bestProg = prog;
        }
    }
    
    choice.gmProgram = bestProg;
    choice.name = getInstrumentName(bestProg);
    auto catIt = gmProgramCategories_.find(bestProg);
    choice.category = catIt != gmProgramCategories_.end() ? catIt->second : InstrumentCategory::Piano;
    choice.emotionalFit = bestFit;
    choice.channel = (role == InstrumentRole::Rhythm) ? 9 : 0;
    
    return choice;
}

InstrumentPalette InstrumentSelector::selectPalette(
    const std::string& emotion,
    const std::string& genre,
    int maxInstruments
) {
    InstrumentPalette palette;
    palette.emotion = emotion;
    palette.genre = genre;
    
    std::vector<InstrumentRole> roles = {
        InstrumentRole::Melody,
        InstrumentRole::Harmony,
        InstrumentRole::Bass,
        InstrumentRole::Pad,
        InstrumentRole::Rhythm
    };
    
    int channel = 0;
    for (size_t i = 0; i < roles.size() && static_cast<int>(i) < maxInstruments; ++i) {
        auto choice = selectForRole(roles[i], emotion, genre);
        choice.channel = (roles[i] == InstrumentRole::Rhythm) ? 9 : channel++;
        palette.instruments.push_back(choice);
    }
    
    return palette;
}

std::vector<InstrumentChoice> InstrumentSelector::getByCategory(InstrumentCategory category) const {
    std::vector<InstrumentChoice> result;
    
    for (const auto& [prog, cat] : gmProgramCategories_) {
        if (cat == category) {
            InstrumentChoice choice;
            choice.gmProgram = prog;
            auto nameIt = gmProgramNames_.find(prog);
            choice.name = nameIt != gmProgramNames_.end() ? nameIt->second : "Unknown";
            choice.category = category;
            choice.emotionalFit = 0.5f;
            result.push_back(choice);
        }
    }
    
    return result;
}

std::vector<InstrumentChoice> InstrumentSelector::getByEmotion(const std::string& emotion) const {
    std::vector<InstrumentChoice> result;
    
    auto it = emotionToInstruments_.find(emotion);
    if (it != emotionToInstruments_.end()) {
        for (int prog : it->second) {
            InstrumentChoice choice;
            choice.gmProgram = prog;
            auto nameIt = gmProgramNames_.find(prog);
            choice.name = nameIt != gmProgramNames_.end() ? nameIt->second : "Unknown";
            auto catIt = gmProgramCategories_.find(prog);
            choice.category = catIt != gmProgramCategories_.end() ? catIt->second : InstrumentCategory::Piano;
            choice.emotionalFit = 0.8f;
            result.push_back(choice);
        }
    }
    
    return result;
}

int InstrumentSelector::getGmProgram(const std::string& name) const {
    for (const auto& [prog, n] : gmProgramNames_) {
        if (n == name) return prog;
    }
    return 0;
}

std::string InstrumentSelector::getInstrumentName(int gmProgram) const {
    auto it = gmProgramNames_.find(gmProgram);
    return it != gmProgramNames_.end() ? it->second : "Program " + std::to_string(gmProgram);
}

float InstrumentSelector::calculateFit(int gmProgram, const std::string& emotion, InstrumentRole role) {
    float fit = 0.5f;
    
    // Check emotion preference
    auto emotionIt = emotionToInstruments_.find(emotion);
    if (emotionIt != emotionToInstruments_.end()) {
        if (std::find(emotionIt->second.begin(), emotionIt->second.end(), gmProgram) 
            != emotionIt->second.end()) {
            fit += 0.3f;
        }
    }
    
    // Check role match
    auto roleIt = roleToInstruments_.find(role);
    if (roleIt != roleToInstruments_.end()) {
        if (std::find(roleIt->second.begin(), roleIt->second.end(), gmProgram) 
            != roleIt->second.end()) {
            fit += 0.2f;
        }
    }
    
    return std::min(1.0f, fit);
}

} // namespace kelly
