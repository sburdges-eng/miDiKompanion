#pragma once

/**
 * Kelly.h - Master header for Kelly MIDI Companion
 * 
 * Therapeutic Music Generation System
 * "Interrogate Before Generate"
 */

//=============================================================================
// CORE TYPES
//=============================================================================
#include "Types.h"

//=============================================================================
// ENGINE CORE - Intent Pipeline
//=============================================================================
#include "EmotionThesaurus.h"
#include "WoundProcessor.h"
#include "RuleBreakEngine.h"
// IntentPipeline.cpp contains inline class

//=============================================================================
// MIDI ENGINES - Melodic
//=============================================================================
#include "MelodyEngine.h"
#include "BassEngine.h"
#include "CounterMelodyEngine.h"
#include "VoiceLeading.h"

//=============================================================================
// MIDI ENGINES - Harmonic
//=============================================================================
#include "PadEngine.h"
#include "StringEngine.h"
// ChordGenerator.cpp contains inline class

//=============================================================================
// MIDI ENGINES - Rhythmic
//=============================================================================
#include "RhythmEngine.h"
#include "GrooveEngine.h"
#include "FillEngine.h"

//=============================================================================
// MIDI ENGINES - Dynamics & Expression
//=============================================================================
#include "DynamicsEngine.h"
#include "VariationEngine.h"
#include "TensionEngine.h"
#include "TransitionEngine.h"
#include "ArrangementEngine.h"

//=============================================================================
// MIDI GENERATION
//=============================================================================
#include "MidiBuilder.h"
#include "InstrumentSelector.h"
// MidiGenerator.cpp contains inline class

//=============================================================================
// DATA LOADING
//=============================================================================
#include "DataLoader.h"

//=============================================================================
// LEGACY COMPATIBILITY
//=============================================================================
#include "emotion_engine.h"
#include "groove_templates.h"
#include "chord_diagnostics.h"

namespace kelly {

/**
 * Kelly System Version
 */
constexpr const char* KELLY_VERSION = "0.1.0";
constexpr int KELLY_VERSION_MAJOR = 0;
constexpr int KELLY_VERSION_MINOR = 1;
constexpr int KELLY_VERSION_PATCH = 0;

/**
 * System constants
 */
constexpr int DEFAULT_TEMPO = 120;
constexpr int DEFAULT_BARS = 8;
constexpr const char* DEFAULT_KEY = "C";
constexpr const char* DEFAULT_MODE = "major";

/**
 * Quick generation helper
 */
inline GenerationConfig createConfig(
    const std::string& emotion,
    const std::string& key = DEFAULT_KEY,
    int bars = DEFAULT_BARS,
    int tempo = DEFAULT_TEMPO
) {
    GenerationConfig config;
    config.emotion = emotion;
    config.key = key;
    config.bars = bars;
    config.tempoBpm = tempo;
    return config;
}

} // namespace kelly
