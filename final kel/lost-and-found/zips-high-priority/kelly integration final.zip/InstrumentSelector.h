#pragma once

#include "Types.h"
#include <string>
#include <vector>
#include <map>

namespace kelly {

enum class InstrumentCategory {
    Piano,
    Strings,
    Brass,
    Woodwind,
    Synth,
    Bass,
    Drums,
    Pad,
    Lead,
    Percussion,
    Ethnic,
    SoundFX
};

enum class InstrumentRole {
    Melody,
    Harmony,
    Bass,
    Rhythm,
    Pad,
    Lead,
    Fill,
    Accent
};

struct InstrumentChoice {
    int gmProgram;
    std::string name;
    InstrumentCategory category;
    float emotionalFit;     // 0-1 how well it fits the emotion
    int channel;
};

struct InstrumentPalette {
    std::vector<InstrumentChoice> instruments;
    std::string emotion;
    std::string genre;
};

class InstrumentSelector {
public:
    InstrumentSelector();
    
    InstrumentChoice selectForRole(
        InstrumentRole role,
        const std::string& emotion,
        const std::string& genre = ""
    );
    
    InstrumentPalette selectPalette(
        const std::string& emotion,
        const std::string& genre = "",
        int maxInstruments = 5
    );
    
    std::vector<InstrumentChoice> getByCategory(InstrumentCategory category) const;
    std::vector<InstrumentChoice> getByEmotion(const std::string& emotion) const;
    
    int getGmProgram(const std::string& name) const;
    std::string getInstrumentName(int gmProgram) const;

private:
    std::map<std::string, std::vector<int>> emotionToInstruments_;
    std::map<std::string, std::vector<int>> genreToInstruments_;
    std::map<InstrumentRole, std::vector<int>> roleToInstruments_;
    std::map<int, std::string> gmProgramNames_;
    std::map<int, InstrumentCategory> gmProgramCategories_;
    
    void initializeMappings();
    float calculateFit(int gmProgram, const std::string& emotion, InstrumentRole role);
};

} // namespace kelly
