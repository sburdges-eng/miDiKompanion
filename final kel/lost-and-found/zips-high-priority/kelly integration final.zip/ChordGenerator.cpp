#include "Types.h"
#include <string>
#include <vector>
#include <map>
#include <random>

namespace kelly {

//=============================================================================
// CHORD GENERATOR STRUCTURES
//=============================================================================

enum class ChordQuality {
    Major,
    Minor,
    Diminished,
    Augmented,
    Dominant7,
    Major7,
    Minor7,
    Diminished7,
    HalfDiminished7,
    Sus2,
    Sus4,
    Add9,
    Add11
};

struct ChordVoicing {
    std::string symbol;
    std::vector<int> pitches;
    std::string root;
    ChordQuality quality;
    int inversion = 0;
};

struct ProgressionConfig {
    std::string emotion = "neutral";
    std::string key = "C";
    std::string mode = "major";
    int numChords = 4;
    bool allowBorrowed = true;
    bool allowExtensions = false;
    int seed = -1;
};

struct ProgressionOutput {
    std::vector<std::string> chordSymbols;
    std::vector<std::string> romanNumerals;
    std::vector<ChordVoicing> voicings;
    std::string key;
    std::string mode;
    std::string emotionalEffect;
};

//=============================================================================
// CHORD GENERATOR
//=============================================================================

class ChordGenerator {
public:
    ChordGenerator();
    
    ProgressionOutput generate(const ProgressionConfig& config);
    
    ProgressionOutput generate(
        const std::string& emotion,
        const std::string& key = "C",
        const std::string& mode = "major",
        int numChords = 4
    );
    
    ChordVoicing parseChord(const std::string& symbol, int octave = 4);
    std::string transpose(const std::string& chord, int semitones);
    std::vector<int> getChordPitches(const std::string& root, ChordQuality quality, int octave);

private:
    std::map<std::string, std::vector<std::vector<std::string>>> emotionProgressions_;
    std::map<std::string, int> noteToSemitone_;
    std::map<ChordQuality, std::vector<int>> qualityIntervals_;
    
    void initializeProgressions();
    void initializeIntervals();
    std::string romanToChord(const std::string& roman, const std::string& key, const std::string& mode);
    int getRootSemitone(const std::string& note) const;
};

//=============================================================================
// IMPLEMENTATION
//=============================================================================

ChordGenerator::ChordGenerator() {
    initializeProgressions();
    initializeIntervals();
}

void ChordGenerator::initializeProgressions() {
    // Grief - unresolved, yearning
    emotionProgressions_["grief"] = {
        {"I", "V", "vi", "IV"},      // Axis ending on IV
        {"i", "VI", "III", "VII"},   // Minor floating
        {"I", "IV", "vi", "IV"},     // Never resolves
        {"vi", "IV", "I", "V"},      // Start minor, never settle
        {"I", "iii", "IV", "iv"}     // Borrowed iv brings tears
    };
    
    // Sadness - descending, minor
    emotionProgressions_["sadness"] = {
        {"i", "iv", "VII", "III"},
        {"vi", "IV", "I", "V"},
        {"i", "VI", "iv", "V"},
        {"ii", "V", "I", "vi"}
    };
    
    // Hope - ascending, brightness
    emotionProgressions_["hope"] = {
        {"I", "V", "vi", "IV"},
        {"I", "IV", "V", "I"},
        {"vi", "IV", "I", "V"},
        {"I", "V", "IV", "I"}
    };
    
    // Anger - dissonant, driving
    emotionProgressions_["anger"] = {
        {"i", "bVI", "bVII", "i"},
        {"i", "iv", "bVI", "V"},
        {"i", "bII", "bVII", "i"},
        {"i", "V", "bVI", "bVII"}
    };
    
    // Fear - unstable, chromatic
    emotionProgressions_["fear"] = {
        {"i", "bII", "V", "i"},
        {"i", "iv", "bVI", "V"},
        {"viio", "i", "iv", "V"},
        {"i", "bVI", "iv", "V"}
    };
    
    // Joy - bright, resolved
    emotionProgressions_["joy"] = {
        {"I", "IV", "V", "I"},
        {"I", "V", "vi", "IV"},
        {"I", "ii", "V", "I"},
        {"I", "IV", "I", "V"}
    };
    
    // Tension - unresolved dominant
    emotionProgressions_["tension"] = {
        {"I", "IV", "V", "V"},
        {"i", "iv", "V", "V"},
        {"viio", "V", "viio", "V"},
        {"i", "bII", "V", "bII"}
    };
    
    // Neutral - standard progressions
    emotionProgressions_["neutral"] = {
        {"I", "IV", "V", "I"},
        {"I", "V", "vi", "IV"},
        {"I", "vi", "IV", "V"},
        {"ii", "V", "I", "I"}
    };
    
    noteToSemitone_ = {
        {"C", 0}, {"C#", 1}, {"Db", 1}, {"D", 2}, {"D#", 3}, {"Eb", 3},
        {"E", 4}, {"F", 5}, {"F#", 6}, {"Gb", 6}, {"G", 7}, {"G#", 8},
        {"Ab", 8}, {"A", 9}, {"A#", 10}, {"Bb", 10}, {"B", 11}
    };
}

void ChordGenerator::initializeIntervals() {
    qualityIntervals_[ChordQuality::Major] = {0, 4, 7};
    qualityIntervals_[ChordQuality::Minor] = {0, 3, 7};
    qualityIntervals_[ChordQuality::Diminished] = {0, 3, 6};
    qualityIntervals_[ChordQuality::Augmented] = {0, 4, 8};
    qualityIntervals_[ChordQuality::Dominant7] = {0, 4, 7, 10};
    qualityIntervals_[ChordQuality::Major7] = {0, 4, 7, 11};
    qualityIntervals_[ChordQuality::Minor7] = {0, 3, 7, 10};
    qualityIntervals_[ChordQuality::Diminished7] = {0, 3, 6, 9};
    qualityIntervals_[ChordQuality::HalfDiminished7] = {0, 3, 6, 10};
    qualityIntervals_[ChordQuality::Sus2] = {0, 2, 7};
    qualityIntervals_[ChordQuality::Sus4] = {0, 5, 7};
    qualityIntervals_[ChordQuality::Add9] = {0, 4, 7, 14};
}

ProgressionOutput ChordGenerator::generate(const ProgressionConfig& config) {
    ProgressionOutput output;
    output.key = config.key;
    output.mode = config.mode;
    
    std::mt19937 rng(config.seed >= 0 ? config.seed : std::random_device{}());
    
    // Get progressions for emotion
    auto it = emotionProgressions_.find(config.emotion);
    const auto& progressions = it != emotionProgressions_.end() ? 
        it->second : emotionProgressions_["neutral"];
    
    // Select random progression
    const auto& roman = progressions[rng() % progressions.size()];
    
    // Convert to actual chords
    for (const auto& numeral : roman) {
        output.romanNumerals.push_back(numeral);
        std::string chord = romanToChord(numeral, config.key, config.mode);
        output.chordSymbols.push_back(chord);
        output.voicings.push_back(parseChord(chord));
    }
    
    // Set emotional effect description
    if (config.emotion == "grief") {
        output.emotionalEffect = "Unresolved yearning, the feeling of reaching but never arriving";
    } else if (config.emotion == "sadness") {
        output.emotionalEffect = "Descending into shadow, weight of melancholy";
    } else if (config.emotion == "hope") {
        output.emotionalEffect = "Rising toward light, anticipation of resolution";
    } else if (config.emotion == "anger") {
        output.emotionalEffect = "Driving force, tension seeking release";
    } else if (config.emotion == "fear") {
        output.emotionalEffect = "Unstable ground, chromatic unease";
    } else if (config.emotion == "joy") {
        output.emotionalEffect = "Bright resolution, satisfying closure";
    } else {
        output.emotionalEffect = "Balanced emotional content";
    }
    
    return output;
}

ProgressionOutput ChordGenerator::generate(
    const std::string& emotion,
    const std::string& key,
    const std::string& mode,
    int numChords
) {
    ProgressionConfig config;
    config.emotion = emotion;
    config.key = key;
    config.mode = mode;
    config.numChords = numChords;
    return generate(config);
}

ChordVoicing ChordGenerator::parseChord(const std::string& symbol, int octave) {
    ChordVoicing voicing;
    voicing.symbol = symbol;
    
    // Parse root
    std::string root = symbol.substr(0, 1);
    size_t qualityStart = 1;
    if (symbol.size() > 1 && (symbol[1] == '#' || symbol[1] == 'b')) {
        root = symbol.substr(0, 2);
        qualityStart = 2;
    }
    voicing.root = root;
    
    // Parse quality
    std::string qualityStr = symbol.substr(qualityStart);
    ChordQuality quality = ChordQuality::Major;
    
    if (qualityStr.empty() || qualityStr[0] == ' ') {
        quality = ChordQuality::Major;
    } else if (qualityStr[0] == 'm' && qualityStr.find("maj") == std::string::npos) {
        quality = qualityStr.find("7") != std::string::npos ? 
            ChordQuality::Minor7 : ChordQuality::Minor;
    } else if (qualityStr.find("dim") != std::string::npos) {
        quality = qualityStr.find("7") != std::string::npos ? 
            ChordQuality::Diminished7 : ChordQuality::Diminished;
    } else if (qualityStr.find("aug") != std::string::npos) {
        quality = ChordQuality::Augmented;
    } else if (qualityStr.find("maj7") != std::string::npos) {
        quality = ChordQuality::Major7;
    } else if (qualityStr.find("7") != std::string::npos) {
        quality = ChordQuality::Dominant7;
    } else if (qualityStr.find("sus2") != std::string::npos) {
        quality = ChordQuality::Sus2;
    } else if (qualityStr.find("sus4") != std::string::npos) {
        quality = ChordQuality::Sus4;
    }
    
    voicing.quality = quality;
    voicing.pitches = getChordPitches(root, quality, octave);
    
    return voicing;
}

std::string ChordGenerator::transpose(const std::string& chord, int semitones) {
    if (chord.empty()) return chord;
    
    std::string root = chord.substr(0, 1);
    size_t qualityStart = 1;
    if (chord.size() > 1 && (chord[1] == '#' || chord[1] == 'b')) {
        root = chord.substr(0, 2);
        qualityStart = 2;
    }
    
    int rootSemi = getRootSemitone(root);
    int newSemi = (rootSemi + semitones + 12) % 12;
    
    static const std::vector<std::string> notes = {
        "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"
    };
    
    return notes[newSemi] + chord.substr(qualityStart);
}

std::vector<int> ChordGenerator::getChordPitches(
    const std::string& root, 
    ChordQuality quality, 
    int octave
) {
    std::vector<int> pitches;
    int rootPitch = getRootSemitone(root) + (octave + 1) * 12;
    
    auto it = qualityIntervals_.find(quality);
    const auto& intervals = it != qualityIntervals_.end() ? 
        it->second : qualityIntervals_[ChordQuality::Major];
    
    for (int interval : intervals) {
        pitches.push_back(rootPitch + interval);
    }
    
    return pitches;
}

std::string ChordGenerator::romanToChord(
    const std::string& roman, 
    const std::string& key, 
    const std::string& mode
) {
    // Scale degrees for major
    static const std::vector<int> majorDegrees = {0, 2, 4, 5, 7, 9, 11};
    static const std::vector<int> minorDegrees = {0, 2, 3, 5, 7, 8, 10};
    
    const auto& degrees = (mode == "minor") ? minorDegrees : majorDegrees;
    
    int keySemi = getRootSemitone(key);
    
    // Parse roman numeral
    std::string cleanRoman = roman;
    bool isMinor = false;
    bool isDim = false;
    bool isFlat = false;
    
    if (cleanRoman[0] == 'b') {
        isFlat = true;
        cleanRoman = cleanRoman.substr(1);
    }
    
    // Check for lowercase (minor)
    if (!cleanRoman.empty() && cleanRoman[0] >= 'a' && cleanRoman[0] <= 'z') {
        isMinor = true;
    }
    
    // Check for diminished
    if (cleanRoman.find("o") != std::string::npos || 
        cleanRoman.find("dim") != std::string::npos) {
        isDim = true;
    }
    
    // Convert to uppercase for degree lookup
    std::string upperRoman = cleanRoman;
    for (auto& c : upperRoman) c = std::toupper(c);
    
    // Remove quality markers
    size_t qualityPos = upperRoman.find_first_of("oO");
    if (qualityPos != std::string::npos) {
        upperRoman = upperRoman.substr(0, qualityPos);
    }
    
    // Map roman to degree
    static const std::map<std::string, int> romanToDegree = {
        {"I", 0}, {"II", 1}, {"III", 2}, {"IV", 3}, {"V", 4}, {"VI", 5}, {"VII", 6}
    };
    
    auto degreeIt = romanToDegree.find(upperRoman);
    int degree = degreeIt != romanToDegree.end() ? degreeIt->second : 0;
    
    int rootSemi = (keySemi + degrees[degree] + (isFlat ? -1 : 0) + 12) % 12;
    
    static const std::vector<std::string> notes = {
        "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"
    };
    
    std::string chordRoot = notes[rootSemi];
    std::string quality = "";
    
    if (isDim) quality = "dim";
    else if (isMinor) quality = "m";
    
    return chordRoot + quality;
}

int ChordGenerator::getRootSemitone(const std::string& note) const {
    auto it = noteToSemitone_.find(note);
    return it != noteToSemitone_.end() ? it->second : 0;
}

} // namespace kelly
