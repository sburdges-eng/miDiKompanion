#include "emotion_thesaurus.h"
#include <cmath>
#include <algorithm>

namespace kelly {

//=============================================================================
// EMOTION THESAURUS IMPLEMENTATION
//=============================================================================

EmotionThesaurus::EmotionThesaurus() {
    initializeEmotions();
    buildRelationships();
}

void EmotionThesaurus::initializeEmotions() {
    // JOY FAMILY (36 nodes)
    addEmotion({"joy", "joy", 0.9f, 0.7f, 0.8f, {"happiness", "delight"}, {}});
    addEmotion({"happiness", "joy", 0.85f, 0.6f, 0.7f, {"contentment", "pleasure"}, {}});
    addEmotion({"ecstasy", "joy", 1.0f, 1.0f, 0.9f, {"bliss", "rapture"}, {}});
    addEmotion({"serenity", "joy", 0.7f, 0.2f, 0.6f, {"peace", "calm"}, {}});
    addEmotion({"optimism", "joy", 0.6f, 0.5f, 0.7f, {"hope", "confidence"}, {}});
    addEmotion({"love", "joy", 0.95f, 0.6f, 0.8f, {"affection", "adoration"}, {}});
    addEmotion({"tenderness", "joy", 0.7f, 0.3f, 0.5f, {"gentleness", "warmth"}, {}});
    addEmotion({"gratitude", "joy", 0.8f, 0.4f, 0.6f, {"thankfulness", "appreciation"}, {}});
    addEmotion({"pride", "joy", 0.7f, 0.6f, 0.8f, {"accomplishment", "satisfaction"}, {}});
    addEmotion({"amusement", "joy", 0.6f, 0.7f, 0.5f, {"humor", "playfulness"}, {}});
    addEmotion({"inspiration", "joy", 0.75f, 0.8f, 0.7f, {"motivation", "uplift"}, {}});
    addEmotion({"awe", "joy", 0.8f, 0.5f, 0.4f, {"wonder", "amazement"}, {}});
    addEmotion({"contentment", "joy", 0.65f, 0.2f, 0.6f, {"satisfaction", "ease"}, {}});
    addEmotion({"relief", "joy", 0.6f, 0.3f, 0.5f, {"release", "comfort"}, {}});
    addEmotion({"elation", "joy", 0.9f, 0.9f, 0.8f, {"exhilaration", "triumph"}, {}});
    addEmotion({"bliss", "joy", 0.95f, 0.4f, 0.7f, {"euphoria", "peace"}, {}});
    addEmotion({"excitement", "joy", 0.7f, 0.9f, 0.7f, {"enthusiasm", "thrill"}, {}});
    addEmotion({"enthusiasm", "joy", 0.65f, 0.8f, 0.7f, {"eagerness", "zeal"}, {}});
    addEmotion({"hope", "joy", 0.55f, 0.5f, 0.6f, {"optimism", "faith"}, {}});
    addEmotion({"affection", "joy", 0.75f, 0.4f, 0.6f, {"fondness", "warmth"}, {}});
    addEmotion({"adoration", "joy", 0.9f, 0.5f, 0.7f, {"worship", "devotion"}, {}});
    addEmotion({"playfulness", "joy", 0.6f, 0.8f, 0.6f, {"mischief", "fun"}, {}});
    addEmotion({"triumph", "joy", 0.85f, 0.8f, 0.9f, {"victory", "conquest"}, {}});
    addEmotion({"wonder", "joy", 0.7f, 0.6f, 0.4f, {"marvel", "curiosity"}, {}});
    addEmotion({"delight", "joy", 0.8f, 0.7f, 0.6f, {"pleasure", "enjoyment"}, {}});
    addEmotion({"cheerfulness", "joy", 0.7f, 0.6f, 0.6f, {"brightness", "gaiety"}, {}});
    addEmotion({"euphoria", "joy", 0.95f, 0.85f, 0.8f, {"ecstasy", "rapture"}, {}});
    addEmotion({"satisfaction", "joy", 0.6f, 0.3f, 0.7f, {"fulfillment", "completion"}, {}});
    addEmotion({"peaceful", "joy", 0.6f, 0.1f, 0.5f, {"tranquil", "serene"}, {}});
    addEmotion({"warmth", "joy", 0.65f, 0.3f, 0.5f, {"coziness", "comfort"}, {}});
    addEmotion({"radiance", "joy", 0.8f, 0.6f, 0.7f, {"glow", "brightness"}, {}});
    addEmotion({"glee", "joy", 0.75f, 0.85f, 0.6f, {"merriment", "joy"}, {}});
    addEmotion({"rapture", "joy", 0.95f, 0.7f, 0.6f, {"ecstasy", "bliss"}, {}});
    addEmotion({"celebration", "joy", 0.8f, 0.8f, 0.7f, {"festivity", "jubilation"}, {}});
    addEmotion({"exuberance", "joy", 0.85f, 0.9f, 0.8f, {"vitality", "energy"}, {}});
    addEmotion({"zest", "joy", 0.7f, 0.85f, 0.7f, {"vigor", "enthusiasm"}, {}});

    // SADNESS FAMILY (36 nodes)
    addEmotion({"sadness", "sadness", -0.7f, 0.3f, 0.3f, {"sorrow", "unhappiness"}, {}});
    addEmotion({"grief", "sadness", -0.9f, 0.4f, 0.2f, {"mourning", "bereavement"}, {}});
    addEmotion({"melancholy", "sadness", -0.5f, 0.2f, 0.3f, {"wistfulness", "pensiveness"}, {}});
    addEmotion({"despair", "sadness", -0.95f, 0.3f, 0.1f, {"hopelessness", "anguish"}, {}});
    addEmotion({"loneliness", "sadness", -0.6f, 0.2f, 0.2f, {"isolation", "solitude"}, {}});
    addEmotion({"sorrow", "sadness", -0.8f, 0.3f, 0.25f, {"grief", "heartache"}, {}});
    addEmotion({"disappointment", "sadness", -0.5f, 0.4f, 0.4f, {"letdown", "dismay"}, {}});
    addEmotion({"regret", "sadness", -0.6f, 0.3f, 0.3f, {"remorse", "contrition"}, {}});
    addEmotion({"longing", "sadness", -0.4f, 0.4f, 0.3f, {"yearning", "pining"}, {}});
    addEmotion({"nostalgia", "sadness", -0.3f, 0.3f, 0.4f, {"wistfulness", "reminiscence"}, {}});
    addEmotion({"emptiness", "sadness", -0.7f, 0.1f, 0.2f, {"void", "hollowness"}, {}});
    addEmotion({"hurt", "sadness", -0.7f, 0.5f, 0.3f, {"pain", "wound"}, {}});
    addEmotion({"heartbreak", "sadness", -0.9f, 0.5f, 0.2f, {"devastation", "anguish"}, {}});
    addEmotion({"dejection", "sadness", -0.65f, 0.2f, 0.2f, {"discouragement", "gloom"}, {}});
    addEmotion({"gloom", "sadness", -0.55f, 0.2f, 0.3f, {"darkness", "dreariness"}, {}});
    addEmotion({"misery", "sadness", -0.85f, 0.3f, 0.15f, {"wretchedness", "suffering"}, {}});
    addEmotion({"anguish", "sadness", -0.9f, 0.6f, 0.2f, {"torment", "agony"}, {}});
    addEmotion({"yearning", "sadness", -0.35f, 0.5f, 0.35f, {"longing", "craving"}, {}});
    addEmotion({"wistfulness", "sadness", -0.3f, 0.25f, 0.4f, {"pensiveness", "nostalgia"}, {}});
    addEmotion({"pining", "sadness", -0.45f, 0.4f, 0.3f, {"longing", "yearning"}, {}});
    addEmotion({"hopelessness", "sadness", -0.9f, 0.2f, 0.1f, {"despair", "defeat"}, {}});
    addEmotion({"loss", "sadness", -0.75f, 0.35f, 0.25f, {"bereavement", "deprivation"}, {}});
    addEmotion({"abandonment", "sadness", -0.8f, 0.4f, 0.15f, {"desertion", "rejection"}, {}});
    addEmotion({"isolation", "sadness", -0.6f, 0.15f, 0.2f, {"solitude", "detachment"}, {}});
    addEmotion({"resignation", "sadness", -0.5f, 0.1f, 0.25f, {"acceptance", "surrender"}, {}});
    addEmotion({"defeat", "sadness", -0.7f, 0.2f, 0.15f, {"failure", "loss"}, {}});
    addEmotion({"numbness", "sadness", -0.4f, 0.05f, 0.2f, {"apathy", "detachment"}, {}});
    addEmotion({"bittersweetness", "sadness", -0.2f, 0.35f, 0.4f, {"poignancy", "tenderness"}, {}});
    addEmotion({"homesickness", "sadness", -0.5f, 0.4f, 0.3f, {"longing", "nostalgia"}, {}});
    addEmotion({"mourning", "sadness", -0.85f, 0.35f, 0.2f, {"grieving", "lamentation"}, {}});
    addEmotion({"suffering", "sadness", -0.8f, 0.4f, 0.2f, {"pain", "anguish"}, {}});
    addEmotion({"heaviness", "sadness", -0.55f, 0.15f, 0.25f, {"burden", "weight"}, {}});
    addEmotion({"brokenness", "sadness", -0.85f, 0.3f, 0.15f, {"shattered", "damaged"}, {}});
    addEmotion({"vulnerability", "sadness", -0.4f, 0.35f, 0.2f, {"exposure", "fragility"}, {}});
    addEmotion({"tender_sadness", "sadness", -0.45f, 0.25f, 0.35f, {"gentle_sorrow", "softness"}, {}});
    addEmotion({"quiet_grief", "sadness", -0.7f, 0.15f, 0.25f, {"silent_mourning", "stillness"}, {}});

    // ANGER FAMILY (36 nodes)
    addEmotion({"anger", "anger", -0.7f, 0.85f, 0.8f, {"rage", "fury"}, {}});
    addEmotion({"rage", "anger", -0.9f, 1.0f, 0.9f, {"fury", "wrath"}, {}});
    addEmotion({"frustration", "anger", -0.5f, 0.7f, 0.6f, {"annoyance", "exasperation"}, {}});
    addEmotion({"irritation", "anger", -0.3f, 0.5f, 0.5f, {"annoyance", "vexation"}, {}});
    addEmotion({"resentment", "anger", -0.6f, 0.5f, 0.4f, {"bitterness", "grudge"}, {}});
    addEmotion({"bitterness", "anger", -0.65f, 0.4f, 0.35f, {"resentment", "acrimony"}, {}});
    addEmotion({"fury", "anger", -0.95f, 0.95f, 0.85f, {"rage", "wrath"}, {}});
    addEmotion({"hostility", "anger", -0.7f, 0.7f, 0.7f, {"antagonism", "aggression"}, {}});
    addEmotion({"contempt", "anger", -0.6f, 0.4f, 0.8f, {"disdain", "scorn"}, {}});
    addEmotion({"hatred", "anger", -0.9f, 0.6f, 0.7f, {"loathing", "abhorrence"}, {}});
    addEmotion({"indignation", "anger", -0.5f, 0.7f, 0.7f, {"outrage", "offense"}, {}});
    addEmotion({"outrage", "anger", -0.75f, 0.85f, 0.75f, {"fury", "indignation"}, {}});
    addEmotion({"annoyance", "anger", -0.25f, 0.45f, 0.5f, {"irritation", "vexation"}, {}});
    addEmotion({"defiance", "anger", -0.3f, 0.75f, 0.85f, {"rebellion", "resistance"}, {}});
    addEmotion({"rebellion", "anger", -0.4f, 0.8f, 0.8f, {"defiance", "revolt"}, {}});
    addEmotion({"aggression", "anger", -0.7f, 0.9f, 0.85f, {"hostility", "violence"}, {}});
    addEmotion({"vengeance", "anger", -0.8f, 0.75f, 0.75f, {"revenge", "retribution"}, {}});
    addEmotion({"jealousy", "anger", -0.55f, 0.6f, 0.4f, {"envy", "possessiveness"}, {}});
    addEmotion({"envy", "anger", -0.5f, 0.55f, 0.35f, {"jealousy", "covetousness"}, {}});
    addEmotion({"scorn", "anger", -0.6f, 0.5f, 0.75f, {"contempt", "derision"}, {}});
    addEmotion({"disgust", "anger", -0.65f, 0.5f, 0.6f, {"revulsion", "loathing"}, {}});
    addEmotion({"wrath", "anger", -0.95f, 0.9f, 0.85f, {"fury", "rage"}, {}});
    addEmotion({"exasperation", "anger", -0.45f, 0.65f, 0.55f, {"frustration", "annoyance"}, {}});
    addEmotion({"impatience", "anger", -0.35f, 0.6f, 0.6f, {"restlessness", "irritation"}, {}});
    addEmotion({"cynicism", "anger", -0.4f, 0.3f, 0.6f, {"skepticism", "distrust"}, {}});
    addEmotion({"spite", "anger", -0.7f, 0.55f, 0.6f, {"malice", "vindictiveness"}, {}});
    addEmotion({"malice", "anger", -0.8f, 0.5f, 0.65f, {"spite", "ill_will"}, {}});
    addEmotion({"betrayal_anger", "anger", -0.85f, 0.8f, 0.6f, {"hurt_rage", "wounded_fury"}, {}});
    addEmotion({"righteous_anger", "anger", -0.4f, 0.75f, 0.8f, {"justified_fury", "moral_outrage"}, {}});
    addEmotion({"cold_fury", "anger", -0.75f, 0.3f, 0.85f, {"controlled_rage", "icy_wrath"}, {}});
    addEmotion({"explosive_rage", "anger", -0.9f, 1.0f, 0.7f, {"eruption", "outburst"}, {}});
    addEmotion({"simmering", "anger", -0.5f, 0.4f, 0.5f, {"brewing", "building"}, {}});
    addEmotion({"seething", "anger", -0.7f, 0.6f, 0.6f, {"boiling", "fuming"}, {}});
    addEmotion({"wounded_pride", "anger", -0.55f, 0.6f, 0.5f, {"injured_ego", "offense"}, {}});
    addEmotion({"territorial", "anger", -0.4f, 0.65f, 0.7f, {"protective", "possessive"}, {}});
    addEmotion({"provoked", "anger", -0.5f, 0.7f, 0.6f, {"triggered", "incited"}, {}});

    // FEAR FAMILY (36 nodes)
    addEmotion({"fear", "fear", -0.8f, 0.8f, 0.2f, {"terror", "dread"}, {}});
    addEmotion({"anxiety", "fear", -0.6f, 0.7f, 0.3f, {"worry", "nervousness"}, {}});
    addEmotion({"terror", "fear", -0.95f, 0.95f, 0.1f, {"horror", "panic"}, {}});
    addEmotion({"dread", "fear", -0.75f, 0.6f, 0.2f, {"apprehension", "foreboding"}, {}});
    addEmotion({"panic", "fear", -0.85f, 1.0f, 0.15f, {"hysteria", "terror"}, {}});
    addEmotion({"worry", "fear", -0.45f, 0.55f, 0.35f, {"concern", "unease"}, {}});
    addEmotion({"nervousness", "fear", -0.4f, 0.6f, 0.35f, {"jitters", "anxiety"}, {}});
    addEmotion({"apprehension", "fear", -0.5f, 0.5f, 0.3f, {"unease", "concern"}, {}});
    addEmotion({"horror", "fear", -0.9f, 0.85f, 0.15f, {"terror", "revulsion"}, {}});
    addEmotion({"paranoia", "fear", -0.7f, 0.75f, 0.25f, {"suspicion", "distrust"}, {}});
    addEmotion({"insecurity", "fear", -0.5f, 0.5f, 0.25f, {"self_doubt", "uncertainty"}, {}});
    addEmotion({"vulnerability", "fear", -0.55f, 0.45f, 0.2f, {"exposure", "weakness"}, {}});
    addEmotion({"unease", "fear", -0.4f, 0.45f, 0.35f, {"discomfort", "restlessness"}, {}});
    addEmotion({"foreboding", "fear", -0.6f, 0.5f, 0.25f, {"premonition", "omen"}, {}});
    addEmotion({"phobia", "fear", -0.8f, 0.85f, 0.15f, {"terror", "irrational_fear"}, {}});
    addEmotion({"trepidation", "fear", -0.55f, 0.55f, 0.3f, {"apprehension", "hesitation"}, {}});
    addEmotion({"alarm", "fear", -0.65f, 0.8f, 0.3f, {"fright", "startle"}, {}});
    addEmotion({"fright", "fear", -0.7f, 0.85f, 0.25f, {"scare", "shock"}, {}});
    addEmotion({"intimidation", "fear", -0.6f, 0.6f, 0.2f, {"coercion", "threat"}, {}});
    addEmotion({"overwhelm", "fear", -0.65f, 0.75f, 0.15f, {"flooding", "swamped"}, {}});
    addEmotion({"hypervigilance", "fear", -0.55f, 0.8f, 0.35f, {"alertness", "watchfulness"}, {}});
    addEmotion({"startle", "fear", -0.5f, 0.9f, 0.3f, {"jump", "shock"}, {}});
    addEmotion({"creeping_dread", "fear", -0.6f, 0.4f, 0.25f, {"slow_fear", "building_terror"}, {}});
    addEmotion({"existential_fear", "fear", -0.7f, 0.5f, 0.2f, {"void", "meaninglessness"}, {}});
    addEmotion({"anticipatory_anxiety", "fear", -0.5f, 0.65f, 0.3f, {"pre_worry", "dreading"}, {}});
    addEmotion({"performance_anxiety", "fear", -0.55f, 0.7f, 0.3f, {"stage_fright", "pressure"}, {}});
    addEmotion({"social_anxiety", "fear", -0.5f, 0.6f, 0.25f, {"self_consciousness", "awkwardness"}, {}});
    addEmotion({"separation_anxiety", "fear", -0.6f, 0.65f, 0.2f, {"abandonment_fear", "clinging"}, {}});
    addEmotion({"frozen_fear", "fear", -0.75f, 0.2f, 0.1f, {"paralysis", "immobilization"}, {}});
    addEmotion({"flight_response", "fear", -0.7f, 0.95f, 0.25f, {"escape", "flee"}, {}});
    addEmotion({"night_terror", "fear", -0.85f, 0.9f, 0.15f, {"nightmare", "dark_fear"}, {}});
    addEmotion({"claustrophobia", "fear", -0.7f, 0.8f, 0.2f, {"trapped", "confined"}, {}});
    addEmotion({"vertigo", "fear", -0.6f, 0.7f, 0.2f, {"dizziness", "falling"}, {}});
    addEmotion({"impending_doom", "fear", -0.8f, 0.7f, 0.15f, {"catastrophe", "end"}, {}});
    addEmotion({"visceral_fear", "fear", -0.75f, 0.85f, 0.2f, {"gut_terror", "primal"}, {}});
    addEmotion({"quiet_terror", "fear", -0.7f, 0.3f, 0.2f, {"silent_dread", "held_breath"}, {}});

    // SURPRISE FAMILY (36 nodes)
    addEmotion({"surprise", "surprise", 0.1f, 0.8f, 0.4f, {"astonishment", "amazement"}, {}});
    addEmotion({"amazement", "surprise", 0.4f, 0.85f, 0.35f, {"wonder", "awe"}, {}});
    addEmotion({"astonishment", "surprise", 0.3f, 0.9f, 0.35f, {"shock", "disbelief"}, {}});
    addEmotion({"shock", "surprise", -0.2f, 0.95f, 0.25f, {"stun", "jolt"}, {}});
    addEmotion({"disbelief", "surprise", 0.0f, 0.7f, 0.4f, {"incredulity", "skepticism"}, {}});
    addEmotion({"confusion", "surprise", -0.2f, 0.6f, 0.3f, {"bewilderment", "perplexity"}, {}});
    addEmotion({"bewilderment", "surprise", -0.15f, 0.65f, 0.3f, {"confusion", "disorientation"}, {}});
    addEmotion({"wonder", "surprise", 0.5f, 0.7f, 0.4f, {"awe", "marvel"}, {}});
    addEmotion({"startle", "surprise", -0.1f, 0.95f, 0.3f, {"jump", "flinch"}, {}});
    addEmotion({"realization", "surprise", 0.2f, 0.75f, 0.5f, {"epiphany", "understanding"}, {}});
    addEmotion({"epiphany", "surprise", 0.6f, 0.8f, 0.6f, {"revelation", "insight"}, {}});
    addEmotion({"revelation", "surprise", 0.4f, 0.85f, 0.55f, {"discovery", "unveiling"}, {}});
    addEmotion({"discovery", "surprise", 0.5f, 0.75f, 0.6f, {"finding", "uncovering"}, {}});
    addEmotion({"curiosity", "surprise", 0.3f, 0.6f, 0.5f, {"interest", "inquisitiveness"}, {}});
    addEmotion({"intrigue", "surprise", 0.25f, 0.65f, 0.5f, {"fascination", "interest"}, {}});
    addEmotion({"fascination", "surprise", 0.4f, 0.7f, 0.5f, {"captivation", "absorption"}, {}});
    addEmotion({"awe", "surprise", 0.5f, 0.65f, 0.35f, {"reverence", "wonder"}, {}});
    addEmotion({"breathless", "surprise", 0.3f, 0.8f, 0.3f, {"stunned", "speechless"}, {}});
    addEmotion({"speechless", "surprise", 0.1f, 0.75f, 0.3f, {"wordless", "mute"}, {}});
    addEmotion({"stun", "surprise", -0.1f, 0.9f, 0.25f, {"daze", "stupor"}, {}});
    addEmotion({"daze", "surprise", -0.15f, 0.5f, 0.25f, {"fog", "haze"}, {}});
    addEmotion({"unexpected_joy", "surprise", 0.7f, 0.85f, 0.5f, {"pleasant_surprise", "delight"}, {}});
    addEmotion({"unexpected_sorrow", "surprise", -0.5f, 0.8f, 0.3f, {"shocking_grief", "sudden_loss"}, {}});
    addEmotion({"plot_twist", "surprise", 0.2f, 0.85f, 0.45f, {"turn", "reversal"}, {}});
    addEmotion({"double_take", "surprise", 0.1f, 0.7f, 0.4f, {"second_look", "reconsider"}, {}});
    addEmotion({"jaw_drop", "surprise", 0.3f, 0.9f, 0.35f, {"agape", "stunned"}, {}});
    addEmotion({"mind_blown", "surprise", 0.5f, 0.95f, 0.4f, {"amazed", "astounded"}, {}});
    addEmotion({"enlightenment", "surprise", 0.6f, 0.7f, 0.6f, {"awakening", "understanding"}, {}});
    addEmotion({"cognitive_dissonance", "surprise", -0.3f, 0.6f, 0.35f, {"conflict", "contradiction"}, {}});
    addEmotion({"paradigm_shift", "surprise", 0.3f, 0.75f, 0.5f, {"worldview_change", "reframe"}, {}});
    addEmotion({"pleasant_shock", "surprise", 0.5f, 0.85f, 0.4f, {"good_surprise", "delightful_jolt"}, {}});
    addEmotion({"unpleasant_shock", "surprise", -0.5f, 0.85f, 0.3f, {"bad_surprise", "unwelcome_news"}, {}});
    addEmotion({"slow_realization", "surprise", 0.1f, 0.5f, 0.45f, {"dawning", "gradual_understanding"}, {}});
    addEmotion({"sudden_clarity", "surprise", 0.4f, 0.8f, 0.55f, {"instant_insight", "flash"}, {}});
    addEmotion({"caught_off_guard", "surprise", -0.2f, 0.8f, 0.3f, {"unprepared", "blindsided"}, {}});
    addEmotion({"serendipity", "surprise", 0.6f, 0.7f, 0.5f, {"happy_accident", "fortunate_discovery"}, {}});

    // DISGUST FAMILY (36 nodes)  
    addEmotion({"disgust", "disgust", -0.7f, 0.5f, 0.6f, {"revulsion", "repugnance"}, {}});
    addEmotion({"revulsion", "disgust", -0.85f, 0.6f, 0.55f, {"loathing", "abhorrence"}, {}});
    addEmotion({"loathing", "disgust", -0.9f, 0.55f, 0.6f, {"hatred", "detestation"}, {}});
    addEmotion({"contempt", "disgust", -0.6f, 0.4f, 0.75f, {"disdain", "scorn"}, {}});
    addEmotion({"disdain", "disgust", -0.55f, 0.35f, 0.7f, {"contempt", "dismissiveness"}, {}});
    addEmotion({"repugnance", "disgust", -0.8f, 0.55f, 0.55f, {"disgust", "aversion"}, {}});
    addEmotion({"aversion", "disgust", -0.5f, 0.4f, 0.5f, {"dislike", "distaste"}, {}});
    addEmotion({"distaste", "disgust", -0.4f, 0.35f, 0.5f, {"dislike", "displeasure"}, {}});
    addEmotion({"dislike", "disgust", -0.35f, 0.3f, 0.5f, {"aversion", "antipathy"}, {}});
    addEmotion({"nausea", "disgust", -0.7f, 0.6f, 0.4f, {"sickness", "queasiness"}, {}});
    addEmotion({"repulsion", "disgust", -0.75f, 0.55f, 0.5f, {"revulsion", "rejection"}, {}});
    addEmotion({"abhorrence", "disgust", -0.9f, 0.5f, 0.6f, {"loathing", "detestation"}, {}});
    addEmotion({"moral_disgust", "disgust", -0.7f, 0.55f, 0.7f, {"ethical_revulsion", "righteous_anger"}, {}});
    addEmotion({"physical_disgust", "disgust", -0.65f, 0.6f, 0.5f, {"visceral_revulsion", "nausea"}, {}});
    addEmotion({"self_disgust", "disgust", -0.8f, 0.45f, 0.3f, {"self_loathing", "shame"}, {}});
    addEmotion({"disappointment_disgust", "disgust", -0.55f, 0.4f, 0.5f, {"letdown", "dismay"}, {}});
    addEmotion({"squeamishness", "disgust", -0.4f, 0.5f, 0.4f, {"queasiness", "discomfort"}, {}});
    addEmotion({"rejection", "disgust", -0.6f, 0.45f, 0.55f, {"refusal", "denial"}, {}});
    addEmotion({"dismissiveness", "disgust", -0.45f, 0.3f, 0.65f, {"disregard", "indifference"}, {}});
    addEmotion({"scorn", "disgust", -0.65f, 0.45f, 0.7f, {"derision", "mockery"}, {}});
    addEmotion({"derision", "disgust", -0.6f, 0.5f, 0.65f, {"ridicule", "mockery"}, {}});
    addEmotion({"mockery", "disgust", -0.55f, 0.55f, 0.6f, {"ridicule", "scorn"}, {}});
    addEmotion({"snobbery", "disgust", -0.4f, 0.3f, 0.7f, {"elitism", "condescension"}, {}});
    addEmotion({"condescension", "disgust", -0.45f, 0.35f, 0.7f, {"patronizing", "superiority"}, {}});
    addEmotion({"superiority", "disgust", -0.3f, 0.35f, 0.8f, {"arrogance", "haughtiness"}, {}});
    addEmotion({"judgmental", "disgust", -0.5f, 0.4f, 0.65f, {"critical", "condemning"}, {}});
    addEmotion({"intolerance", "disgust", -0.6f, 0.5f, 0.6f, {"bigotry", "narrow_mindedness"}, {}});
    addEmotion({"betrayal_disgust", "disgust", -0.75f, 0.6f, 0.5f, {"violated_trust", "sickened"}, {}});
    addEmotion({"hypocrisy_disgust", "disgust", -0.65f, 0.55f, 0.6f, {"double_standard", "falseness"}, {}});
    addEmotion({"cruelty_disgust", "disgust", -0.8f, 0.6f, 0.55f, {"brutality_revulsion", "inhumanity"}, {}});
    addEmotion({"corruption_disgust", "disgust", -0.7f, 0.5f, 0.6f, {"decay", "rot"}, {}});
    addEmotion({"pollution_disgust", "disgust", -0.55f, 0.45f, 0.5f, {"contamination", "taint"}, {}});
    addEmotion({"visceral_rejection", "disgust", -0.7f, 0.65f, 0.5f, {"gut_reaction", "instinctive_revulsion"}, {}});
    addEmotion({"aesthetic_disgust", "disgust", -0.4f, 0.35f, 0.55f, {"ugliness", "tastelessness"}, {}});
    addEmotion({"social_disgust", "disgust", -0.5f, 0.45f, 0.6f, {"taboo_violation", "norm_breach"}, {}});
    addEmotion({"existential_disgust", "disgust", -0.6f, 0.35f, 0.45f, {"meaninglessness", "absurdity"}, {}});
}

void EmotionThesaurus::buildRelationships() {
    // Build relationships based on VAD proximity
    for (auto& [name1, node1] : emotions_) {
        for (const auto& [name2, node2] : emotions_) {
            if (name1 != name2) {
                float distance = calculateDistance(node1, node2);
                if (distance < 0.4f) {
                    node1.relatedEmotions.push_back(name2);
                }
            }
        }
    }
}

void EmotionThesaurus::addEmotion(const EmotionNodeData& data) {
    emotions_[data.name] = data;
    categoryMap_[data.category].push_back(data.name);
}

const EmotionNodeData* EmotionThesaurus::getEmotion(const std::string& name) const {
    auto it = emotions_.find(name);
    return it != emotions_.end() ? &it->second : nullptr;
}

std::vector<const EmotionNodeData*> EmotionThesaurus::getByCategory(const std::string& category) const {
    std::vector<const EmotionNodeData*> result;
    auto it = categoryMap_.find(category);
    if (it != categoryMap_.end()) {
        for (const auto& name : it->second) {
            if (auto emotion = getEmotion(name)) {
                result.push_back(emotion);
            }
        }
    }
    return result;
}

std::vector<const EmotionNodeData*> EmotionThesaurus::findSimilar(
    const std::string& emotion, 
    float threshold
) const {
    std::vector<const EmotionNodeData*> result;
    const auto* source = getEmotion(emotion);
    if (!source) return result;
    
    for (const auto& [name, node] : emotions_) {
        if (name != emotion && calculateDistance(*source, node) < threshold) {
            result.push_back(&node);
        }
    }
    return result;
}

const EmotionNodeData* EmotionThesaurus::findByVAD(float valence, float arousal, float dominance) const {
    const EmotionNodeData* closest = nullptr;
    float minDistance = std::numeric_limits<float>::max();
    
    for (const auto& [name, node] : emotions_) {
        float d = std::sqrt(
            std::pow(node.valence - valence, 2) +
            std::pow(node.arousal - arousal, 2) +
            std::pow(node.dominance - dominance, 2)
        );
        if (d < minDistance) {
            minDistance = d;
            closest = &node;
        }
    }
    return closest;
}

float EmotionThesaurus::calculateDistance(const EmotionNodeData& a, const EmotionNodeData& b) const {
    return std::sqrt(
        std::pow(a.valence - b.valence, 2) +
        std::pow(a.arousal - b.arousal, 2) +
        std::pow(a.dominance - b.dominance, 2)
    );
}

} // namespace kelly
