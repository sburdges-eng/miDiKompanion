/**
 * midi_pipeline.cpp - MIDI generation pipeline wrapper
 * 
 * Part of Kelly MIDI Companion - Therapeutic Music Generation
 * 
 * This file provides the original midi_pipeline interface while
 * delegating to the full MidiGenerator implementation.
 * 
 * Pipeline stages:
 * 1. Intent → Musical parameters
 * 2. Parameters → Track generation
 * 3. Tracks → MIDI file output
 */

#include "MidiBuilder.h"
#include "InstrumentSelector.h"
#include "Types.h"
#include <string>
#include <vector>
#include <map>
#include <memory>
#include <functional>

namespace kelly {

//=============================================================================
// PIPELINE STRUCTURES
//=============================================================================

struct PipelineStage {
    std::string name;
    std::function<bool(void*)> process;
    bool enabled = true;
};

struct PipelineInput {
    std::string emotion;
    std::string key = "C";
    std::string mode = "major";
    int bars = 8;
    int tempoBpm = 120;
    std::vector<std::string> chordProgression;
    std::map<std::string, float> parameters;
};

struct PipelineOutput {
    std::vector<MidiNote> allNotes;
    std::map<std::string, std::vector<MidiNote>> trackNotes;
    std::vector<uint8_t> midiBytes;
    int totalTicks;
    bool success;
    std::string errorMessage;
};

struct TrackConfig {
    std::string name;
    int channel;
    int program;
    bool enabled = true;
    float velocityScale = 1.0f;
    int octaveOffset = 0;
};

//=============================================================================
// MIDI PIPELINE CLASS
//=============================================================================

class MidiPipeline {
public:
    MidiPipeline()
        : builder_(std::make_unique<MidiBuilder>())
        , instrumentSelector_(std::make_unique<InstrumentSelector>()) {
        initializeDefaultTracks();
    }
    
    PipelineOutput process(const PipelineInput& input) {
        PipelineOutput output;
        output.success = true;
        
        try {
            // Configure builder
            builder_->clear();
            builder_->setTempo(input.tempoBpm);
            builder_->setKeySignature(input.key, input.mode);
            
            // Generate each track
            for (const auto& track : tracks_) {
                if (!track.enabled) continue;
                
                int trackIndex = builder_->addTrack(track.name, track.channel, track.program);
                
                auto notes = generateTrackNotes(track, input);
                output.trackNotes[track.name] = notes;
                
                for (const auto& note : notes) {
                    builder_->addNote(trackIndex, note);
                    output.allNotes.push_back(note);
                }
            }
            
            // Build output
            output.midiBytes = builder_->toBytes();
            output.totalTicks = input.bars * TICKS_PER_BEAT * 4;
            
        } catch (const std::exception& e) {
            output.success = false;
            output.errorMessage = e.what();
        }
        
        return output;
    }
    
    bool writeToFile(const std::string& filename) {
        return builder_->writeToFile(filename);
    }
    
    void addTrack(const TrackConfig& track) {
        tracks_.push_back(track);
    }
    
    void removeTrack(const std::string& name) {
        tracks_.erase(
            std::remove_if(tracks_.begin(), tracks_.end(),
                [&name](const TrackConfig& t) { return t.name == name; }),
            tracks_.end()
        );
    }
    
    void setTrackEnabled(const std::string& name, bool enabled) {
        for (auto& track : tracks_) {
            if (track.name == name) {
                track.enabled = enabled;
                break;
            }
        }
    }
    
    std::vector<std::string> getTrackNames() const {
        std::vector<std::string> names;
        for (const auto& track : tracks_) {
            names.push_back(track.name);
        }
        return names;
    }

private:
    std::unique_ptr<MidiBuilder> builder_;
    std::unique_ptr<InstrumentSelector> instrumentSelector_;
    std::vector<TrackConfig> tracks_;
    
    void initializeDefaultTracks() {
        tracks_.push_back({"Melody", 0, 0, true, 1.0f, 0});
        tracks_.push_back({"Bass", 1, 33, true, 1.0f, -2});
        tracks_.push_back({"Chords", 2, 0, true, 0.8f, 0});
        tracks_.push_back({"Pad", 3, 89, true, 0.6f, -1});
        tracks_.push_back({"Drums", 9, 0, true, 1.0f, 0});
    }
    
    std::vector<MidiNote> generateTrackNotes(const TrackConfig& track, const PipelineInput& input) {
        std::vector<MidiNote> notes;
        
        int ticksPerBar = TICKS_PER_BEAT * 4;
        int baseNote = getMidiNoteForKey(input.key, 4 + track.octaveOffset);
        
        if (track.name == "Melody") {
            notes = generateMelody(input, baseNote, track);
        } else if (track.name == "Bass") {
            notes = generateBass(input, baseNote - 24, track);
        } else if (track.name == "Chords") {
            notes = generateChords(input, baseNote, track);
        } else if (track.name == "Pad") {
            notes = generatePad(input, baseNote - 12, track);
        } else if (track.name == "Drums") {
            notes = generateDrums(input, track);
        }
        
        // Apply velocity scaling
        for (auto& note : notes) {
            note.velocity = static_cast<int>(note.velocity * track.velocityScale);
            note.velocity = std::clamp(note.velocity, 1, 127);
            note.channel = track.channel;
        }
        
        return notes;
    }
    
    std::vector<MidiNote> generateMelody(const PipelineInput& input, int baseNote, const TrackConfig& track) {
        std::vector<MidiNote> notes;
        
        std::vector<int> scale = (input.mode == "minor") ?
            std::vector<int>{0, 2, 3, 5, 7, 8, 10} :
            std::vector<int>{0, 2, 4, 5, 7, 9, 11};
        
        int ticksPerBar = TICKS_PER_BEAT * 4;
        
        for (int bar = 0; bar < input.bars; ++bar) {
            int notesInBar = 4;
            int ticksPerNote = ticksPerBar / notesInBar;
            
            for (int n = 0; n < notesInBar; ++n) {
                MidiNote note;
                note.pitch = baseNote + scale[n % scale.size()];
                note.startTick = bar * ticksPerBar + n * ticksPerNote;
                note.durationTicks = ticksPerNote - 60;
                note.velocity = 70;
                notes.push_back(note);
            }
        }
        
        return notes;
    }
    
    std::vector<MidiNote> generateBass(const PipelineInput& input, int baseNote, const TrackConfig& track) {
        std::vector<MidiNote> notes;
        int ticksPerBar = TICKS_PER_BEAT * 4;
        
        for (int bar = 0; bar < input.bars; ++bar) {
            int rootPitch = baseNote;
            if (!input.chordProgression.empty()) {
                std::string chord = input.chordProgression[bar % input.chordProgression.size()];
                rootPitch = getMidiNoteForKey(chord.substr(0, 1), 2);
            }
            
            MidiNote note;
            note.pitch = rootPitch;
            note.startTick = bar * ticksPerBar;
            note.durationTicks = TICKS_PER_BEAT * 2;
            note.velocity = 85;
            notes.push_back(note);
            
            MidiNote note2;
            note2.pitch = rootPitch;
            note2.startTick = bar * ticksPerBar + TICKS_PER_BEAT * 2;
            note2.durationTicks = TICKS_PER_BEAT * 2;
            note2.velocity = 75;
            notes.push_back(note2);
        }
        
        return notes;
    }
    
    std::vector<MidiNote> generateChords(const PipelineInput& input, int baseNote, const TrackConfig& track) {
        std::vector<MidiNote> notes;
        int ticksPerBar = TICKS_PER_BEAT * 4;
        
        for (int bar = 0; bar < input.bars; ++bar) {
            std::vector<int> chord = {0, 4, 7};  // Major triad
            if (!input.chordProgression.empty()) {
                std::string chordName = input.chordProgression[bar % input.chordProgression.size()];
                if (chordName.find('m') != std::string::npos && 
                    chordName.find("maj") == std::string::npos) {
                    chord = {0, 3, 7};  // Minor triad
                }
            }
            
            for (int interval : chord) {
                MidiNote note;
                note.pitch = baseNote + interval;
                note.startTick = bar * ticksPerBar;
                note.durationTicks = ticksPerBar - 60;
                note.velocity = 55;
                notes.push_back(note);
            }
        }
        
        return notes;
    }
    
    std::vector<MidiNote> generatePad(const PipelineInput& input, int baseNote, const TrackConfig& track) {
        std::vector<MidiNote> notes;
        int ticksPerBar = TICKS_PER_BEAT * 4;
        
        // Sustained pad over multiple bars
        for (int bar = 0; bar < input.bars; bar += 2) {
            std::vector<int> chord = {0, 4, 7, 12};
            
            for (int interval : chord) {
                MidiNote note;
                note.pitch = baseNote + interval;
                note.startTick = bar * ticksPerBar;
                note.durationTicks = ticksPerBar * 2;
                note.velocity = 45;
                notes.push_back(note);
            }
        }
        
        return notes;
    }
    
    std::vector<MidiNote> generateDrums(const PipelineInput& input, const TrackConfig& track) {
        std::vector<MidiNote> notes;
        int ticksPerBar = TICKS_PER_BEAT * 4;
        int ticksPer8th = TICKS_PER_BEAT / 2;
        
        for (int bar = 0; bar < input.bars; ++bar) {
            // Kick on 1 and 3
            for (int beat : {0, 2}) {
                MidiNote kick;
                kick.pitch = 36;
                kick.startTick = bar * ticksPerBar + beat * TICKS_PER_BEAT;
                kick.durationTicks = ticksPer8th;
                kick.velocity = 100;
                notes.push_back(kick);
            }
            
            // Snare on 2 and 4
            for (int beat : {1, 3}) {
                MidiNote snare;
                snare.pitch = 38;
                snare.startTick = bar * ticksPerBar + beat * TICKS_PER_BEAT;
                snare.durationTicks = ticksPer8th;
                snare.velocity = 90;
                notes.push_back(snare);
            }
            
            // Hi-hat on 8ths
            for (int i = 0; i < 8; ++i) {
                MidiNote hat;
                hat.pitch = 42;
                hat.startTick = bar * ticksPerBar + i * ticksPer8th;
                hat.durationTicks = ticksPer8th / 2;
                hat.velocity = (i % 2 == 0) ? 70 : 50;
                notes.push_back(hat);
            }
        }
        
        return notes;
    }
    
    int getMidiNoteForKey(const std::string& key, int octave) {
        static const std::map<std::string, int> noteMap = {
            {"C", 0}, {"C#", 1}, {"Db", 1}, {"D", 2}, {"D#", 3}, {"Eb", 3},
            {"E", 4}, {"F", 5}, {"F#", 6}, {"Gb", 6}, {"G", 7}, {"G#", 8},
            {"Ab", 8}, {"A", 9}, {"A#", 10}, {"Bb", 10}, {"B", 11}
        };
        
        auto it = noteMap.find(key);
        int pc = it != noteMap.end() ? it->second : 0;
        return pc + (octave + 1) * 12;
    }
};

//=============================================================================
// GLOBAL PIPELINE INSTANCE
//=============================================================================

static MidiPipeline g_pipeline;

//=============================================================================
// LEGACY C-STYLE INTERFACE
//=============================================================================

bool generateMidi(const char* emotion, const char* key, int bars, int tempo, const char* outputPath) {
    PipelineInput input;
    input.emotion = emotion;
    input.key = key;
    input.bars = bars;
    input.tempoBpm = tempo;
    
    auto output = g_pipeline.process(input);
    if (!output.success) return false;
    
    return g_pipeline.writeToFile(outputPath);
}

int getNoteCount() {
    PipelineInput input;
    auto output = g_pipeline.process(input);
    return static_cast<int>(output.allNotes.size());
}

//=============================================================================
// CONVENIENCE FUNCTIONS
//=============================================================================

PipelineOutput generateFromEmotion(const std::string& emotion, int bars, int tempo) {
    PipelineInput input;
    input.emotion = emotion;
    input.bars = bars;
    input.tempoBpm = tempo;
    return g_pipeline.process(input);
}

PipelineOutput generateWithChords(
    const std::string& emotion,
    const std::vector<std::string>& chords,
    const std::string& key,
    int bars,
    int tempo
) {
    PipelineInput input;
    input.emotion = emotion;
    input.chordProgression = chords;
    input.key = key;
    input.bars = bars;
    input.tempoBpm = tempo;
    return g_pipeline.process(input);
}

} // namespace kelly
