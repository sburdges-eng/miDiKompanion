#include "MidiBuilder.h"
#include "InstrumentSelector.h"
#include "Types.h"
#include <string>
#include <vector>
#include <map>
#include <memory>

namespace kelly {

//=============================================================================
// MIDI GENERATOR STRUCTURES
//=============================================================================

struct MidiGeneratorConfig {
    std::string emotion = "neutral";
    std::string genre;
    std::string key = "C";
    std::string mode = "major";
    int bars = 8;
    int tempoBpm = 120;
    std::vector<std::string> chordProgression;
    bool includeMelody = true;
    bool includeBass = true;
    bool includeChords = true;
    bool includeDrums = true;
    bool includePad = true;
    float humanization = 0.1f;
    int seed = -1;
};

struct GeneratedTrack {
    std::string name;
    int channel;
    int program;
    std::vector<MidiNote> notes;
};

struct MidiGeneratorOutput {
    std::vector<GeneratedTrack> tracks;
    MidiFile midiFile;
    int totalTicks;
    std::string emotion;
    std::map<std::string, std::string> metadata;
};

//=============================================================================
// MIDI GENERATOR
//=============================================================================

class MidiGenerator {
public:
    MidiGenerator();
    
    MidiGeneratorOutput generate(const MidiGeneratorConfig& config);
    
    MidiGeneratorOutput generate(
        const std::string& emotion,
        const std::vector<std::string>& chordProgression,
        const std::string& key = "C",
        int bars = 8,
        int tempoBpm = 120
    );
    
    bool writeToFile(const MidiGeneratorOutput& output, const std::string& filename);
    
    void setMelodyEngine(void* engine) { /* for future engine injection */ }
    void setBassEngine(void* engine) { /* for future engine injection */ }
    void setGrooveEngine(void* engine) { /* for future engine injection */ }

private:
    std::unique_ptr<InstrumentSelector> instrumentSelector_;
    MidiBuilder builder_;
    
    GeneratedTrack generateMelody(const MidiGeneratorConfig& config, std::mt19937& rng);
    GeneratedTrack generateBass(const MidiGeneratorConfig& config, std::mt19937& rng);
    GeneratedTrack generateChords(const MidiGeneratorConfig& config, std::mt19937& rng);
    GeneratedTrack generateDrums(const MidiGeneratorConfig& config, std::mt19937& rng);
    GeneratedTrack generatePad(const MidiGeneratorConfig& config, std::mt19937& rng);
    
    std::vector<int> parseChord(const std::string& chord);
    int getNoteForKey(const std::string& key, int octave = 4);
};

//=============================================================================
// IMPLEMENTATION
//=============================================================================

MidiGenerator::MidiGenerator()
    : instrumentSelector_(std::make_unique<InstrumentSelector>()) {}

MidiGeneratorOutput MidiGenerator::generate(const MidiGeneratorConfig& config) {
    MidiGeneratorOutput output;
    output.emotion = config.emotion;
    
    std::mt19937 rng(config.seed >= 0 ? config.seed : std::random_device{}());
    
    builder_.clear();
    builder_.setTempo(config.tempoBpm);
    builder_.setTimeSignature(4, 4);
    builder_.setKeySignature(config.key, config.mode);
    
    // Generate tracks
    if (config.includeMelody) {
        auto melody = generateMelody(config, rng);
        output.tracks.push_back(melody);
    }
    
    if (config.includeBass) {
        auto bass = generateBass(config, rng);
        output.tracks.push_back(bass);
    }
    
    if (config.includeChords) {
        auto chords = generateChords(config, rng);
        output.tracks.push_back(chords);
    }
    
    if (config.includePad) {
        auto pad = generatePad(config, rng);
        output.tracks.push_back(pad);
    }
    
    if (config.includeDrums) {
        auto drums = generateDrums(config, rng);
        output.tracks.push_back(drums);
    }
    
    // Build MIDI file
    for (const auto& track : output.tracks) {
        int trackIndex = builder_.addTrack(track.name, track.channel, track.program);
        for (const auto& note : track.notes) {
            builder_.addNote(trackIndex, note);
        }
    }
    
    output.midiFile = builder_.build();
    output.totalTicks = config.bars * TICKS_PER_BEAT * 4;
    
    output.metadata["emotion"] = config.emotion;
    output.metadata["genre"] = config.genre;
    output.metadata["key"] = config.key;
    output.metadata["mode"] = config.mode;
    output.metadata["tempo"] = std::to_string(config.tempoBpm);
    
    return output;
}

MidiGeneratorOutput MidiGenerator::generate(
    const std::string& emotion,
    const std::vector<std::string>& chordProgression,
    const std::string& key,
    int bars,
    int tempoBpm
) {
    MidiGeneratorConfig config;
    config.emotion = emotion;
    config.chordProgression = chordProgression;
    config.key = key;
    config.bars = bars;
    config.tempoBpm = tempoBpm;
    return generate(config);
}

bool MidiGenerator::writeToFile(const MidiGeneratorOutput& output, const std::string& filename) {
    return builder_.writeToFile(filename);
}

GeneratedTrack MidiGenerator::generateMelody(const MidiGeneratorConfig& config, std::mt19937& rng) {
    GeneratedTrack track;
    track.name = "Melody";
    track.channel = 0;
    
    auto instrument = instrumentSelector_->selectForRole(InstrumentRole::Melody, config.emotion);
    track.program = instrument.gmProgram;
    
    int ticksPerBar = TICKS_PER_BEAT * 4;
    int baseNote = getNoteForKey(config.key, 5);
    
    // Simple emotion-based melody generation
    std::vector<int> scaleIntervals = (config.mode == "minor") ?
        std::vector<int>{0, 2, 3, 5, 7, 8, 10} : std::vector<int>{0, 2, 4, 5, 7, 9, 11};
    
    for (int bar = 0; bar < config.bars; ++bar) {
        int notesInBar = 4 + rng() % 4;
        int ticksPerNote = ticksPerBar / notesInBar;
        
        for (int n = 0; n < notesInBar; ++n) {
            MidiNote note;
            int scaleIndex = rng() % scaleIntervals.size();
            note.pitch = baseNote + scaleIntervals[scaleIndex];
            note.startTick = bar * ticksPerBar + n * ticksPerNote;
            note.durationTicks = ticksPerNote - TICKS_PER_BEAT / 8;
            note.velocity = 60 + rng() % 30;
            note.channel = track.channel;
            track.notes.push_back(note);
        }
    }
    
    return track;
}

GeneratedTrack MidiGenerator::generateBass(const MidiGeneratorConfig& config, std::mt19937& rng) {
    GeneratedTrack track;
    track.name = "Bass";
    track.channel = 1;
    
    auto instrument = instrumentSelector_->selectForRole(InstrumentRole::Bass, config.emotion);
    track.program = instrument.gmProgram;
    
    int ticksPerBar = TICKS_PER_BEAT * 4;
    
    for (int bar = 0; bar < config.bars; ++bar) {
        std::string chord = config.chordProgression.empty() ? config.key :
            config.chordProgression[bar % config.chordProgression.size()];
        
        int rootPitch = getNoteForKey(chord.substr(0, 1), 2);
        
        // Root on beat 1
        MidiNote root;
        root.pitch = rootPitch;
        root.startTick = bar * ticksPerBar;
        root.durationTicks = TICKS_PER_BEAT;
        root.velocity = 80;
        root.channel = track.channel;
        track.notes.push_back(root);
        
        // Fifth on beat 3
        MidiNote fifth;
        fifth.pitch = rootPitch + 7;
        fifth.startTick = bar * ticksPerBar + TICKS_PER_BEAT * 2;
        fifth.durationTicks = TICKS_PER_BEAT;
        fifth.velocity = 70;
        fifth.channel = track.channel;
        track.notes.push_back(fifth);
    }
    
    return track;
}

GeneratedTrack MidiGenerator::generateChords(const MidiGeneratorConfig& config, std::mt19937& rng) {
    GeneratedTrack track;
    track.name = "Chords";
    track.channel = 2;
    
    auto instrument = instrumentSelector_->selectForRole(InstrumentRole::Harmony, config.emotion);
    track.program = instrument.gmProgram;
    
    int ticksPerBar = TICKS_PER_BEAT * 4;
    
    for (int bar = 0; bar < config.bars; ++bar) {
        std::string chordName = config.chordProgression.empty() ? config.key :
            config.chordProgression[bar % config.chordProgression.size()];
        
        auto chordPitches = parseChord(chordName);
        
        for (int pitch : chordPitches) {
            MidiNote note;
            note.pitch = pitch + 48;  // Octave 4
            note.startTick = bar * ticksPerBar;
            note.durationTicks = ticksPerBar - TICKS_PER_BEAT / 4;
            note.velocity = 55;
            note.channel = track.channel;
            track.notes.push_back(note);
        }
    }
    
    return track;
}

GeneratedTrack MidiGenerator::generateDrums(const MidiGeneratorConfig& config, std::mt19937& rng) {
    GeneratedTrack track;
    track.name = "Drums";
    track.channel = 9;  // MIDI drum channel
    track.program = 0;
    
    int ticksPerBar = TICKS_PER_BEAT * 4;
    int ticksPer8th = TICKS_PER_BEAT / 2;
    
    for (int bar = 0; bar < config.bars; ++bar) {
        // Kick on 1 and 3
        for (int beat : {0, 2}) {
            MidiNote kick;
            kick.pitch = 36;
            kick.startTick = bar * ticksPerBar + beat * TICKS_PER_BEAT;
            kick.durationTicks = ticksPer8th;
            kick.velocity = 100;
            kick.channel = 9;
            track.notes.push_back(kick);
        }
        
        // Snare on 2 and 4
        for (int beat : {1, 3}) {
            MidiNote snare;
            snare.pitch = 38;
            snare.startTick = bar * ticksPerBar + beat * TICKS_PER_BEAT;
            snare.durationTicks = ticksPer8th;
            snare.velocity = 90;
            snare.channel = 9;
            track.notes.push_back(snare);
        }
        
        // Hi-hat on 8ths
        for (int i = 0; i < 8; ++i) {
            MidiNote hat;
            hat.pitch = 42;
            hat.startTick = bar * ticksPerBar + i * ticksPer8th;
            hat.durationTicks = ticksPer8th / 2;
            hat.velocity = (i % 2 == 0) ? 70 : 50;
            hat.channel = 9;
            track.notes.push_back(hat);
        }
    }
    
    return track;
}

GeneratedTrack MidiGenerator::generatePad(const MidiGeneratorConfig& config, std::mt19937& rng) {
    GeneratedTrack track;
    track.name = "Pad";
    track.channel = 3;
    
    auto instrument = instrumentSelector_->selectForRole(InstrumentRole::Pad, config.emotion);
    track.program = instrument.gmProgram;
    
    int ticksPerBar = TICKS_PER_BEAT * 4;
    
    for (int bar = 0; bar < config.bars; bar += 2) {
        std::string chordName = config.chordProgression.empty() ? config.key :
            config.chordProgression[(bar/2) % config.chordProgression.size()];
        
        auto chordPitches = parseChord(chordName);
        
        for (int pitch : chordPitches) {
            MidiNote note;
            note.pitch = pitch + 36;  // Lower octave
            note.startTick = bar * ticksPerBar;
            note.durationTicks = ticksPerBar * 2;
            note.velocity = 45;
            note.channel = track.channel;
            track.notes.push_back(note);
        }
    }
    
    return track;
}

std::vector<int> MidiGenerator::parseChord(const std::string& chord) {
    static const std::map<std::string, int> noteMap = {
        {"C", 0}, {"C#", 1}, {"Db", 1}, {"D", 2}, {"D#", 3}, {"Eb", 3},
        {"E", 4}, {"F", 5}, {"F#", 6}, {"Gb", 6}, {"G", 7}, {"G#", 8},
        {"Ab", 8}, {"A", 9}, {"A#", 10}, {"Bb", 10}, {"B", 11}
    };
    
    std::string root = chord.substr(0, 1);
    if (chord.size() > 1 && (chord[1] == '#' || chord[1] == 'b')) {
        root = chord.substr(0, 2);
    }
    
    int rootPitch = 0;
    auto it = noteMap.find(root);
    if (it != noteMap.end()) rootPitch = it->second;
    
    bool isMinor = chord.find('m') != std::string::npos && 
                   chord.find("maj") == std::string::npos;
    
    std::vector<int> intervals = isMinor ? 
        std::vector<int>{0, 3, 7} : std::vector<int>{0, 4, 7};
    
    std::vector<int> pitches;
    for (int interval : intervals) {
        pitches.push_back(rootPitch + interval);
    }
    
    return pitches;
}

int MidiGenerator::getNoteForKey(const std::string& key, int octave) {
    static const std::map<std::string, int> noteMap = {
        {"C", 0}, {"C#", 1}, {"Db", 1}, {"D", 2}, {"D#", 3}, {"Eb", 3},
        {"E", 4}, {"F", 5}, {"F#", 6}, {"Gb", 6}, {"G", 7}, {"G#", 8},
        {"Ab", 8}, {"A", 9}, {"A#", 10}, {"Bb", 10}, {"B", 11}
    };
    
    auto it = noteMap.find(key);
    int pc = it != noteMap.end() ? it->second : 0;
    return pc + (octave + 1) * 12;
}

} // namespace kelly
