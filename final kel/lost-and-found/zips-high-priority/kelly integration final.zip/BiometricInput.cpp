#include "Types.h"
#include <string>
#include <vector>
#include <map>
#include <deque>
#include <cmath>

namespace kelly {

//=============================================================================
// BIOMETRIC INPUT STRUCTURES
//=============================================================================

enum class BiometricSource {
    HeartRate,
    HeartRateVariability,
    SkinConductance,
    Respiration,
    Temperature,
    Movement,
    EyeTracking,
    FacialExpression
};

struct BiometricReading {
    BiometricSource source;
    float value;
    float normalizedValue;  // 0-1
    int64_t timestamp;
};

struct BiometricState {
    float arousal;          // 0-1, calm to excited
    float valence;          // -1 to 1, negative to positive
    float stress;           // 0-1
    float engagement;       // 0-1
    float relaxation;       // 0-1
    std::string inferredEmotion;
    float confidence;
};

struct BiometricConfig {
    bool useHeartRate = true;
    bool useHrv = true;
    bool useSkinConductance = true;
    bool useRespiration = false;
    int smoothingWindowMs = 5000;
    float baselineHeartRate = 70.0f;
    float baselineSkinConductance = 2.0f;
};

//=============================================================================
// BIOMETRIC INPUT PROCESSOR
//=============================================================================

class BiometricInput {
public:
    BiometricInput();
    
    void configure(const BiometricConfig& config);
    
    void addReading(BiometricSource source, float value, int64_t timestamp);
    void addReading(const BiometricReading& reading);
    
    BiometricState getCurrentState() const;
    std::string mapToEmotion() const;
    
    void setBaseline(BiometricSource source, float value);
    void resetBaselines();
    
    float getArousal() const;
    float getValence() const;
    bool isCalibrated() const { return calibrated_; }
    
    void calibrate(int durationMs = 30000);
    void stopCalibration();

private:
    BiometricConfig config_;
    std::map<BiometricSource, std::deque<BiometricReading>> readings_;
    std::map<BiometricSource, float> baselines_;
    std::map<BiometricSource, float> currentValues_;
    bool calibrated_ = false;
    bool calibrating_ = false;
    
    float normalizeReading(BiometricSource source, float value) const;
    float calculateArousal() const;
    float calculateValence() const;
    float calculateStress() const;
    void pruneOldReadings(int64_t currentTime);
    std::string inferEmotion(float arousal, float valence, float stress) const;
};

//=============================================================================
// IMPLEMENTATION
//=============================================================================

BiometricInput::BiometricInput() {
    // Default baselines
    baselines_[BiometricSource::HeartRate] = 70.0f;
    baselines_[BiometricSource::HeartRateVariability] = 50.0f;
    baselines_[BiometricSource::SkinConductance] = 2.0f;
    baselines_[BiometricSource::Respiration] = 15.0f;
    baselines_[BiometricSource::Temperature] = 33.0f;
}

void BiometricInput::configure(const BiometricConfig& config) {
    config_ = config;
    baselines_[BiometricSource::HeartRate] = config.baselineHeartRate;
    baselines_[BiometricSource::SkinConductance] = config.baselineSkinConductance;
}

void BiometricInput::addReading(BiometricSource source, float value, int64_t timestamp) {
    BiometricReading reading;
    reading.source = source;
    reading.value = value;
    reading.normalizedValue = normalizeReading(source, value);
    reading.timestamp = timestamp;
    addReading(reading);
}

void BiometricInput::addReading(const BiometricReading& reading) {
    readings_[reading.source].push_back(reading);
    currentValues_[reading.source] = reading.value;
    
    // Limit buffer size
    while (readings_[reading.source].size() > 1000) {
        readings_[reading.source].pop_front();
    }
    
    if (calibrating_) {
        // Update baseline as average of readings
        float sum = 0;
        for (const auto& r : readings_[reading.source]) {
            sum += r.value;
        }
        baselines_[reading.source] = sum / readings_[reading.source].size();
    }
}

BiometricState BiometricInput::getCurrentState() const {
    BiometricState state;
    state.arousal = calculateArousal();
    state.valence = calculateValence();
    state.stress = calculateStress();
    state.engagement = (state.arousal + std::abs(state.valence)) / 2.0f;
    state.relaxation = 1.0f - state.stress;
    state.inferredEmotion = inferEmotion(state.arousal, state.valence, state.stress);
    state.confidence = calibrated_ ? 0.8f : 0.5f;
    return state;
}

std::string BiometricInput::mapToEmotion() const {
    return getCurrentState().inferredEmotion;
}

void BiometricInput::setBaseline(BiometricSource source, float value) {
    baselines_[source] = value;
}

void BiometricInput::resetBaselines() {
    baselines_[BiometricSource::HeartRate] = 70.0f;
    baselines_[BiometricSource::HeartRateVariability] = 50.0f;
    baselines_[BiometricSource::SkinConductance] = 2.0f;
    baselines_[BiometricSource::Respiration] = 15.0f;
    calibrated_ = false;
}

float BiometricInput::getArousal() const {
    return calculateArousal();
}

float BiometricInput::getValence() const {
    return calculateValence();
}

void BiometricInput::calibrate(int durationMs) {
    calibrating_ = true;
    // In real implementation, this would run for durationMs
    // and collect baseline readings
}

void BiometricInput::stopCalibration() {
    calibrating_ = false;
    calibrated_ = true;
}

float BiometricInput::normalizeReading(BiometricSource source, float value) const {
    float baseline = 0;
    auto it = baselines_.find(source);
    if (it != baselines_.end()) baseline = it->second;
    
    switch (source) {
        case BiometricSource::HeartRate:
            // Normal range: 50-180 bpm
            return std::clamp((value - 50.0f) / 130.0f, 0.0f, 1.0f);
            
        case BiometricSource::HeartRateVariability:
            // Higher HRV = more relaxed, range 20-100ms
            return std::clamp((value - 20.0f) / 80.0f, 0.0f, 1.0f);
            
        case BiometricSource::SkinConductance:
            // Higher = more aroused, range 1-20 microsiemens
            return std::clamp((value - 1.0f) / 19.0f, 0.0f, 1.0f);
            
        case BiometricSource::Respiration:
            // Normal range: 8-25 breaths/min
            return std::clamp((value - 8.0f) / 17.0f, 0.0f, 1.0f);
            
        case BiometricSource::Temperature:
            // Skin temp range: 28-36°C
            return std::clamp((value - 28.0f) / 8.0f, 0.0f, 1.0f);
            
        default:
            return std::clamp(value, 0.0f, 1.0f);
    }
}

float BiometricInput::calculateArousal() const {
    float arousal = 0.5f;
    int count = 0;
    
    // Heart rate contributes to arousal
    auto hrIt = currentValues_.find(BiometricSource::HeartRate);
    if (hrIt != currentValues_.end()) {
        float hrBaseline = baselines_.at(BiometricSource::HeartRate);
        float hrDelta = (hrIt->second - hrBaseline) / hrBaseline;
        arousal += hrDelta * 0.4f;
        count++;
    }
    
    // Skin conductance indicates arousal
    auto scIt = currentValues_.find(BiometricSource::SkinConductance);
    if (scIt != currentValues_.end()) {
        float scBaseline = baselines_.at(BiometricSource::SkinConductance);
        float scDelta = (scIt->second - scBaseline) / scBaseline;
        arousal += scDelta * 0.4f;
        count++;
    }
    
    // HRV inversely relates to arousal
    auto hrvIt = currentValues_.find(BiometricSource::HeartRateVariability);
    if (hrvIt != currentValues_.end()) {
        float hrvBaseline = baselines_.at(BiometricSource::HeartRateVariability);
        float hrvDelta = (hrvIt->second - hrvBaseline) / hrvBaseline;
        arousal -= hrvDelta * 0.2f;  // Inverted
        count++;
    }
    
    return std::clamp(arousal, 0.0f, 1.0f);
}

float BiometricInput::calculateValence() const {
    // Valence is harder to determine from biometrics alone
    // High HRV + moderate HR = positive
    // Low HRV + high HR = negative
    
    float valence = 0.0f;
    
    auto hrvIt = currentValues_.find(BiometricSource::HeartRateVariability);
    auto hrIt = currentValues_.find(BiometricSource::HeartRate);
    
    if (hrvIt != currentValues_.end()) {
        float hrvBaseline = baselines_.at(BiometricSource::HeartRateVariability);
        float hrvNorm = (hrvIt->second - hrvBaseline) / hrvBaseline;
        valence += hrvNorm * 0.5f;  // Higher HRV = more positive
    }
    
    if (hrIt != currentValues_.end()) {
        float hrBaseline = baselines_.at(BiometricSource::HeartRate);
        float hrNorm = (hrIt->second - hrBaseline) / hrBaseline;
        // Moderate elevation could be positive, extreme is negative
        if (hrNorm > 0.3f) {
            valence -= (hrNorm - 0.3f) * 0.5f;
        }
    }
    
    return std::clamp(valence, -1.0f, 1.0f);
}

float BiometricInput::calculateStress() const {
    float stress = 0.0f;
    
    // High HR + low HRV = stress
    auto hrIt = currentValues_.find(BiometricSource::HeartRate);
    auto hrvIt = currentValues_.find(BiometricSource::HeartRateVariability);
    auto scIt = currentValues_.find(BiometricSource::SkinConductance);
    
    if (hrIt != currentValues_.end()) {
        float hrBaseline = baselines_.at(BiometricSource::HeartRate);
        stress += std::max(0.0f, (hrIt->second - hrBaseline) / hrBaseline) * 0.3f;
    }
    
    if (hrvIt != currentValues_.end()) {
        float hrvBaseline = baselines_.at(BiometricSource::HeartRateVariability);
        stress += std::max(0.0f, (hrvBaseline - hrvIt->second) / hrvBaseline) * 0.4f;
    }
    
    if (scIt != currentValues_.end()) {
        float scBaseline = baselines_.at(BiometricSource::SkinConductance);
        stress += std::max(0.0f, (scIt->second - scBaseline) / scBaseline) * 0.3f;
    }
    
    return std::clamp(stress, 0.0f, 1.0f);
}

std::string BiometricInput::inferEmotion(float arousal, float valence, float stress) const {
    // Map arousal/valence space to emotions
    
    if (stress > 0.7f) {
        if (arousal > 0.7f) return "anxiety";
        return "fear";
    }
    
    if (valence > 0.3f) {
        if (arousal > 0.7f) return "joy";
        if (arousal > 0.4f) return "hope";
        return "peace";
    }
    
    if (valence < -0.3f) {
        if (arousal > 0.7f) return "anger";
        if (arousal > 0.4f) return "frustration";
        return "sadness";
    }
    
    if (arousal < 0.3f) {
        if (valence < 0) return "melancholy";
        return "serenity";
    }
    
    if (arousal > 0.6f) {
        return "anticipation";
    }
    
    return "neutral";
}

void BiometricInput::pruneOldReadings(int64_t currentTime) {
    int64_t cutoff = currentTime - config_.smoothingWindowMs;
    
    for (auto& [source, queue] : readings_) {
        while (!queue.empty() && queue.front().timestamp < cutoff) {
            queue.pop_front();
        }
    }
}

} // namespace kelly
