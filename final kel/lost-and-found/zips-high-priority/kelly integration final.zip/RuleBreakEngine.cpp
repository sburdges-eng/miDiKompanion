#include "RuleBreakEngine.h"
#include <algorithm>

namespace kelly {

RuleBreakEngine::RuleBreakEngine() {
    initializeRules();
}

void RuleBreakEngine::initializeRules() {
    // HARMONY RULES
    registerRule({
        "HARMONY_AvoidTonicResolution",
        "Avoid Tonic Resolution",
        RuleCategory::Harmony,
        RuleSeverity::Moderate,
        "End progression on IV or vi instead of I",
        "Creates unresolved yearning, the feeling of reaching but never arriving",
        {{"resolution", -0.8f}, {"tension", 0.4f}, {"yearning", 0.9f}},
        {"grief", "longing", "melancholy", "hope", "yearning"}
    });
    
    registerRule({
        "HARMONY_ModalInterchange",
        "Modal Interchange",
        RuleCategory::Harmony,
        RuleSeverity::Moderate,
        "Borrow chords from parallel minor/major",
        "Adds emotional color, the iv chord brings instant melancholy",
        {{"color", 0.7f}, {"surprise", 0.4f}, {"depth", 0.6f}},
        {"grief", "sadness", "bittersweetness", "nostalgia", "hope"}
    });
    
    registerRule({
        "HARMONY_ChromaticMovement",
        "Chromatic Movement",
        RuleCategory::Harmony,
        RuleSeverity::Dramatic,
        "Use chromatic bass lines or voice leading",
        "Creates unsettling movement, nothing feels stable",
        {{"tension", 0.8f}, {"instability", 0.7f}, {"motion", 0.9f}},
        {"anxiety", "fear", "unease", "tension", "anticipation"}
    });
    
    registerRule({
        "HARMONY_DeceptiveCadence",
        "Deceptive Cadence",
        RuleCategory::Harmony,
        RuleSeverity::Subtle,
        "V resolves to vi instead of I",
        "The expected resolution is denied, perfect for disappointment",
        {{"surprise", 0.6f}, {"disappointment", 0.7f}, {"subversion", 0.5f}},
        {"disappointment", "sadness", "surprise", "irony", "regret"}
    });
    
    registerRule({
        "HARMONY_Diminished",
        "Diminished Tension",
        RuleCategory::Harmony,
        RuleSeverity::Dramatic,
        "Use diminished chords for maximum tension",
        "Creates extreme dissonance and instability",
        {{"tension", 0.95f}, {"dissonance", 0.8f}, {"dread", 0.7f}},
        {"fear", "dread", "anxiety", "horror", "panic"}
    });
    
    // RHYTHM RULES
    registerRule({
        "RHYTHM_BreathingSpace",
        "Breathing Space",
        RuleCategory::Rhythm,
        RuleSeverity::Subtle,
        "Add extra beats of rest between phrases",
        "Lets emotion breathe, grief needs air",
        {{"space", 0.8f}, {"breath", 0.9f}, {"pause", 0.7f}},
        {"grief", "sadness", "reflection", "peace", "acceptance"}
    });
    
    registerRule({
        "RHYTHM_Syncopation",
        "Heavy Syncopation",
        RuleCategory::Rhythm,
        RuleSeverity::Moderate,
        "Emphasize off-beats, displace accents",
        "Creates restlessness, the groove never settles",
        {{"energy", 0.7f}, {"instability", 0.5f}, {"drive", 0.8f}},
        {"anger", "frustration", "energy", "defiance", "urgency"}
    });
    
    registerRule({
        "RHYTHM_Fragmentation",
        "Rhythmic Fragmentation",
        RuleCategory::Rhythm,
        RuleSeverity::Dramatic,
        "Break patterns into short, disconnected fragments",
        "Represents scattered thoughts, dissociation",
        {{"fragmentation", 0.9f}, {"chaos", 0.6f}, {"disconnection", 0.8f}},
        {"trauma", "dissociation", "confusion", "panic", "overwhelm"}
    });
    
    registerRule({
        "RHYTHM_Accelerando",
        "Building Urgency",
        RuleCategory::Rhythm,
        RuleSeverity::Moderate,
        "Gradually increase tempo or note density",
        "Creates mounting pressure, panic rising",
        {{"urgency", 0.8f}, {"acceleration", 0.9f}, {"pressure", 0.7f}},
        {"anxiety", "panic", "anticipation", "excitement", "fear"}
    });
    
    // DYNAMICS RULES
    registerRule({
        "DYNAMICS_SubtleSwells",
        "Subtle Swells",
        RuleCategory::Dynamics,
        RuleSeverity::Subtle,
        "Gentle crescendo/decrescendo within phrases",
        "Like breathing, the music inhales and exhales",
        {{"breath", 0.7f}, {"organic", 0.8f}, {"life", 0.6f}},
        {"grief", "tenderness", "intimacy", "peace", "reflection"}
    });
    
    registerRule({
        "DYNAMICS_SuddenContrasts",
        "Sudden Contrasts",
        RuleCategory::Dynamics,
        RuleSeverity::Dramatic,
        "Jarring shifts between loud and soft",
        "Like emotional outbursts, unpredictable",
        {{"surprise", 0.9f}, {"instability", 0.7f}, {"drama", 0.8f}},
        {"anger", "trauma", "bipolar", "volatile", "intensity"}
    });
    
    registerRule({
        "DYNAMICS_ExtremeContrasts",
        "Extreme Dynamic Range",
        RuleCategory::Dynamics,
        RuleSeverity::Extreme,
        "From nearly silent to maximum intensity",
        "Full emotional spectrum, nothing held back",
        {{"range", 1.0f}, {"extremity", 0.9f}, {"expression", 0.8f}},
        {"catharsis", "rage", "grief", "breakthrough", "release"}
    });
    
    registerRule({
        "DYNAMICS_BuildingTension",
        "Sustained Build",
        RuleCategory::Dynamics,
        RuleSeverity::Moderate,
        "Long crescendo without release",
        "Tension that never resolves, pressure mounting",
        {{"tension", 0.9f}, {"anticipation", 0.8f}, {"pressure", 0.85f}},
        {"anxiety", "dread", "anticipation", "suppression", "waiting"}
    });
    
    // ARRANGEMENT RULES
    registerRule({
        "ARRANGEMENT_SparseTexture",
        "Sparse Texture",
        RuleCategory::Arrangement,
        RuleSeverity::Subtle,
        "Remove instruments, create empty space",
        "Isolation made audible",
        {{"space", 0.9f}, {"isolation", 0.8f}, {"vulnerability", 0.7f}},
        {"loneliness", "isolation", "vulnerability", "grief", "emptiness"}
    });
    
    registerRule({
        "ARRANGEMENT_Solo",
        "Isolated Solo",
        RuleCategory::Arrangement,
        RuleSeverity::Moderate,
        "Single instrument alone, no accompaniment",
        "Complete isolation, naked emotion",
        {{"isolation", 1.0f}, {"vulnerability", 0.9f}, {"intimacy", 0.8f}},
        {"loneliness", "grief", "confession", "intimacy", "solitude"}
    });
    
    registerRule({
        "ARRANGEMENT_LayerCollapse",
        "Layer Collapse",
        RuleCategory::Arrangement,
        RuleSeverity::Dramatic,
        "Instruments drop out one by one",
        "Everything falling away",
        {{"loss", 0.9f}, {"decline", 0.8f}, {"entropy", 0.7f}},
        {"grief", "loss", "despair", "letting_go", "acceptance"}
    });
    
    // MELODY RULES
    registerRule({
        "MELODY_CircularMotif",
        "Circular Motif",
        RuleCategory::Melody,
        RuleSeverity::Subtle,
        "Melody that returns to starting note obsessively",
        "Trapped in a loop, can't escape the thought",
        {{"obsession", 0.8f}, {"cycle", 0.9f}, {"trapped", 0.7f}},
        {"obsession", "rumination", "grief", "anxiety", "regret"}
    });
    
    registerRule({
        "MELODY_Collapse",
        "Melodic Collapse",
        RuleCategory::Melody,
        RuleSeverity::Dramatic,
        "Melody descends and loses energy",
        "Giving up, the fight leaving",
        {{"descent", 0.9f}, {"defeat", 0.8f}, {"exhaustion", 0.7f}},
        {"despair", "exhaustion", "defeat", "surrender", "grief"}
    });
    
    // Build emotion mappings
    for (const auto& [id, rule] : rules_) {
        for (const auto& emotion : rule.compatibleEmotions) {
            emotionToRules_[emotion].push_back(id);
        }
    }
}

void RuleBreakEngine::registerRule(const RuleBreak& rule) {
    rules_[rule.id] = rule;
}

void RuleBreakEngine::registerEmotionMapping(const std::string& emotion, const std::string& ruleId) {
    emotionToRules_[emotion].push_back(ruleId);
}

std::vector<RuleBreak> RuleBreakEngine::getRuleBreaksForEmotion(const std::string& emotion) const {
    std::vector<RuleBreak> result;
    auto it = emotionToRules_.find(emotion);
    if (it != emotionToRules_.end()) {
        for (const auto& ruleId : it->second) {
            if (auto rule = getRule(ruleId)) {
                result.push_back(*rule);
            }
        }
    }
    return result;
}

std::vector<RuleBreak> RuleBreakEngine::getRuleBreaksByCategory(RuleCategory category) const {
    std::vector<RuleBreak> result;
    for (const auto& [id, rule] : rules_) {
        if (rule.category == category) {
            result.push_back(rule);
        }
    }
    return result;
}

const RuleBreak* RuleBreakEngine::getRule(const std::string& id) const {
    auto it = rules_.find(id);
    return it != rules_.end() ? &it->second : nullptr;
}

RuleBreakResult RuleBreakEngine::apply(
    const std::string& ruleId, 
    const std::string& emotion, 
    float intensity
) {
    RuleBreakResult result;
    
    const RuleBreak* rule = getRule(ruleId);
    if (!rule) {
        result.wasApplied = false;
        return result;
    }
    
    result.rule = *rule;
    result.wasApplied = true;
    result.appliedEffect = rule->description;
    
    for (const auto& [param, value] : rule->musicalImpact) {
        result.parameters[param] = value * intensity;
    }
    
    return result;
}

std::vector<RuleBreakResult> RuleBreakEngine::applyMultiple(
    const std::vector<std::string>& ruleIds,
    const std::string& emotion,
    float intensity
) {
    std::vector<RuleBreakResult> results;
    for (const auto& id : ruleIds) {
        results.push_back(apply(id, emotion, intensity));
    }
    return results;
}

std::vector<RuleBreak> RuleBreakEngine::suggestRuleBreaks(
    const std::string& emotion,
    float intensity,
    int maxSuggestions
) const {
    auto candidates = getRuleBreaksForEmotion(emotion);
    
    std::sort(candidates.begin(), candidates.end(),
        [this, &emotion, intensity](const RuleBreak& a, const RuleBreak& b) {
            return calculateEffectiveness(a, emotion, intensity) >
                   calculateEffectiveness(b, emotion, intensity);
        }
    );
    
    if (candidates.size() > static_cast<size_t>(maxSuggestions)) {
        candidates.resize(maxSuggestions);
    }
    
    return candidates;
}

bool RuleBreakEngine::isCompatible(const RuleBreak& rule, const std::string& emotion) const {
    return std::find(rule.compatibleEmotions.begin(), 
                     rule.compatibleEmotions.end(), 
                     emotion) != rule.compatibleEmotions.end();
}

float RuleBreakEngine::calculateEffectiveness(
    const RuleBreak& rule, 
    const std::string& emotion, 
    float intensity
) const {
    float base = isCompatible(rule, emotion) ? 1.0f : 0.3f;
    float severityMatch = 1.0f;
    
    if (intensity > 0.8f && rule.severity != RuleSeverity::Extreme) {
        severityMatch = 0.7f;
    } else if (intensity < 0.3f && rule.severity == RuleSeverity::Extreme) {
        severityMatch = 0.5f;
    }
    
    return base * severityMatch * intensity;
}

} // namespace kelly
