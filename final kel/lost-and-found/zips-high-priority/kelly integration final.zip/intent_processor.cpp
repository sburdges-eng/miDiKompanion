/**
 * intent_processor.cpp - Three-phase intent processing wrapper
 * 
 * Part of Kelly MIDI Companion - Therapeutic Music Generation
 * 
 * This file provides the original intent_processor interface while
 * delegating to the full IntentPipeline implementation.
 * 
 * The three phases are:
 * 1. Wound → Identify emotional trigger
 * 2. Emotion → Map to 216-node thesaurus
 * 3. Rule-breaks → Express through musical violations
 */

#include "WoundProcessor.h"
#include "RuleBreakEngine.h"
#include "EmotionThesaurus.h"
#include "Types.h"
#include <string>
#include <vector>
#include <map>
#include <memory>

namespace kelly {

//=============================================================================
// LEGACY STRUCTURES
//=============================================================================

enum class IntentPhase {
    Wound,
    Emotion,
    RuleBreak,
    Complete
};

struct IntentWound {
    std::string description;
    float intensity = 0.5f;
    std::string source;
    std::string desiredOutcome;
};

struct IntentResult {
    std::string primaryEmotion;
    std::string secondaryEmotion;
    float emotionalIntensity;
    std::vector<std::string> suggestedRuleBreaks;
    std::map<std::string, float> musicalParameters;
};

//=============================================================================
// INTENT PROCESSOR CLASS
//=============================================================================

class IntentProcessor {
public:
    IntentProcessor()
        : woundProcessor_(std::make_unique<WoundProcessor>())
        , ruleBreakEngine_(std::make_unique<RuleBreakEngine>())
        , thesaurus_(std::make_unique<EmotionThesaurus>())
        , currentPhase_(IntentPhase::Wound) {}
    
    IntentResult process(const IntentWound& wound) {
        IntentResult result;
        
        // Phase 1: Wound Processing
        currentPhase_ = IntentPhase::Wound;
        Wound w;
        w.description = wound.description;
        w.intensity = wound.intensity;
        w.source = woundProcessor_->classifyWound(wound.description);
        w.desiredOutcome = wound.desiredOutcome;
        
        auto analysis = woundProcessor_->analyze(w);
        
        // Phase 2: Emotion Mapping
        currentPhase_ = IntentPhase::Emotion;
        result.primaryEmotion = analysis.primaryEmotion;
        result.secondaryEmotion = analysis.secondaryEmotion;
        result.emotionalIntensity = analysis.emotionalWeight;
        
        // Phase 3: Rule Break Generation
        currentPhase_ = IntentPhase::RuleBreak;
        result.suggestedRuleBreaks = analysis.suggestedRuleBreaks;
        
        // Compile musical parameters
        result.musicalParameters = compileMusicalParameters(analysis);
        
        currentPhase_ = IntentPhase::Complete;
        return result;
    }
    
    IntentResult processWound(const std::string& description, float intensity = 0.5f) {
        IntentWound wound;
        wound.description = description;
        wound.intensity = intensity;
        return process(wound);
    }
    
    IntentPhase getCurrentPhase() const { return currentPhase_; }
    
    std::string mapWoundToEmotion(const std::string& woundDescription) {
        auto source = woundProcessor_->classifyWound(woundDescription);
        return woundProcessor_->mapToEmotion(source, 0.5f);
    }
    
    std::vector<std::string> getRuleBreaksForEmotion(const std::string& emotion) {
        auto breaks = ruleBreakEngine_->getRuleBreaksForEmotion(emotion);
        std::vector<std::string> ids;
        for (const auto& b : breaks) {
            ids.push_back(b.id);
        }
        return ids;
    }

private:
    std::unique_ptr<WoundProcessor> woundProcessor_;
    std::unique_ptr<RuleBreakEngine> ruleBreakEngine_;
    std::unique_ptr<EmotionThesaurus> thesaurus_;
    IntentPhase currentPhase_;
    
    std::map<std::string, float> compileMusicalParameters(const WoundAnalysis& analysis) {
        std::map<std::string, float> params = analysis.musicalImplications;
        
        // Add emotion-based parameters
        const auto* emotionNode = thesaurus_->getEmotion(analysis.primaryEmotion);
        if (emotionNode) {
            params["valence"] = emotionNode->valence;
            params["arousal"] = emotionNode->arousal;
            params["dominance"] = emotionNode->dominance;
            
            // Derive musical parameters from VAD
            params["tempo_modifier"] = 0.7f + emotionNode->arousal * 0.6f;
            params["dynamic_range"] = 0.3f + std::abs(emotionNode->valence) * 0.7f;
            params["harmonic_complexity"] = 0.3f + (1.0f - emotionNode->dominance) * 0.5f;
        }
        
        params["emotional_weight"] = analysis.emotionalWeight;
        
        return params;
    }
};

//=============================================================================
// LEGACY C-STYLE INTERFACE
//=============================================================================

static IntentProcessor g_processor;

int processWound(const char* description, float intensity) {
    auto result = g_processor.processWound(description, intensity);
    // Return emotion ID (simplified)
    if (result.primaryEmotion == "grief") return 2;
    if (result.primaryEmotion == "rage") return 4;
    if (result.primaryEmotion == "anxiety") return 7;
    return 3;  // Default to melancholy
}

const char* getPrimaryEmotion() {
    static std::string lastEmotion;
    auto result = g_processor.processWound("", 0.5f);
    lastEmotion = result.primaryEmotion;
    return lastEmotion.c_str();
}

float getEmotionalIntensity() {
    auto result = g_processor.processWound("", 0.5f);
    return result.emotionalIntensity;
}

//=============================================================================
// INTENT PIPELINE INTEGRATION
//=============================================================================

struct PipelineConfig {
    bool enableWoundProcessing = true;
    bool enableRuleBreaks = true;
    float intensityThreshold = 0.3f;
    int maxRuleBreaks = 5;
};

struct PipelineResult {
    IntentResult intent;
    std::vector<RuleBreakResult> appliedRuleBreaks;
    GenerationConfig generationConfig;
};

PipelineResult runIntentPipeline(const IntentWound& wound, const PipelineConfig& config) {
    PipelineResult result;
    
    // Process wound
    result.intent = g_processor.process(wound);
    
    // Apply rule breaks
    if (config.enableRuleBreaks) {
        RuleBreakEngine engine;
        for (size_t i = 0; i < result.intent.suggestedRuleBreaks.size() && 
             static_cast<int>(i) < config.maxRuleBreaks; ++i) {
            auto rb = engine.apply(
                result.intent.suggestedRuleBreaks[i],
                result.intent.primaryEmotion,
                result.intent.emotionalIntensity
            );
            result.appliedRuleBreaks.push_back(rb);
        }
    }
    
    // Build generation config
    result.generationConfig.emotion = result.intent.primaryEmotion;
    
    if (result.intent.musicalParameters.count("tempo_modifier")) {
        result.generationConfig.tempoBpm = static_cast<int>(
            100 * result.intent.musicalParameters.at("tempo_modifier")
        );
    }
    
    result.generationConfig.expressiveness = result.intent.emotionalIntensity;
    
    return result;
}

//=============================================================================
// UTILITY FUNCTIONS
//=============================================================================

std::string describeIntent(const IntentResult& intent) {
    std::string desc = "Primary emotion: " + intent.primaryEmotion;
    desc += ", Intensity: " + std::to_string(intent.emotionalIntensity);
    if (!intent.secondaryEmotion.empty()) {
        desc += ", Secondary: " + intent.secondaryEmotion;
    }
    desc += ", Rule breaks: " + std::to_string(intent.suggestedRuleBreaks.size());
    return desc;
}

bool validateIntent(const IntentResult& intent) {
    if (intent.primaryEmotion.empty()) return false;
    if (intent.emotionalIntensity < 0 || intent.emotionalIntensity > 1) return false;
    return true;
}

} // namespace kelly
