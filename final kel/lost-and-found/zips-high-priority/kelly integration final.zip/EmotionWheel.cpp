#include "Types.h"
#include <string>
#include <vector>
#include <map>
#include <cmath>

namespace kelly {

//=============================================================================
// EMOTION WHEEL STRUCTURES
//=============================================================================

struct WheelSegment {
    std::string emotion;
    std::string category;
    float startAngle;
    float endAngle;
    float innerRadius;
    float outerRadius;
    uint32_t color;
    std::vector<std::string> childEmotions;
};

struct WheelSelection {
    std::string emotion;
    std::string category;
    float intensity;
    float x;
    float y;
};

struct EmotionColor {
    uint8_t r, g, b;
    
    uint32_t toRgb() const {
        return (r << 16) | (g << 8) | b;
    }
};

//=============================================================================
// EMOTION WHEEL
//=============================================================================

class EmotionWheel {
public:
    EmotionWheel();
    
    void initialize();
    
    WheelSelection getEmotionAtPoint(float x, float y);
    std::vector<WheelSegment> getSegments() const { return segments_; }
    
    void setCenter(float x, float y) { centerX_ = x; centerY_ = y; }
    void setRadius(float inner, float outer) { innerRadius_ = inner; outerRadius_ = outer; }
    
    std::string getCategoryForEmotion(const std::string& emotion) const;
    EmotionColor getColorForEmotion(const std::string& emotion) const;
    std::vector<std::string> getRelatedEmotions(const std::string& emotion) const;
    
    float getIntensityAtRadius(float radius) const;

private:
    std::vector<WheelSegment> segments_;
    std::map<std::string, EmotionColor> emotionColors_;
    std::map<std::string, std::string> emotionToCategory_;
    std::map<std::string, std::vector<std::string>> categoryEmotions_;
    
    float centerX_ = 0;
    float centerY_ = 0;
    float innerRadius_ = 50;
    float outerRadius_ = 200;
    
    void buildWheel();
    void addCategory(const std::string& category, float startAngle, 
                     const std::vector<std::string>& emotions, const EmotionColor& baseColor);
    float normalizeAngle(float angle);
    std::pair<float, float> polarToCartesian(float angle, float radius);
};

//=============================================================================
// IMPLEMENTATION
//=============================================================================

EmotionWheel::EmotionWheel() {
    initialize();
}

void EmotionWheel::initialize() {
    // Plutchik's 8 basic emotions with colors
    emotionColors_["joy"] = {255, 230, 100};
    emotionColors_["trust"] = {100, 200, 100};
    emotionColors_["fear"] = {100, 200, 100};
    emotionColors_["surprise"] = {100, 200, 255};
    emotionColors_["sadness"] = {100, 150, 255};
    emotionColors_["disgust"] = {200, 100, 200};
    emotionColors_["anger"] = {255, 100, 100};
    emotionColors_["anticipation"] = {255, 180, 100};
    
    // Extended emotions inherit from parents
    emotionColors_["grief"] = {80, 120, 200};
    emotionColors_["melancholy"] = {100, 140, 220};
    emotionColors_["loneliness"] = {90, 130, 210};
    emotionColors_["hope"] = {180, 230, 150};
    emotionColors_["anxiety"] = {180, 255, 180};
    emotionColors_["rage"] = {255, 50, 50};
    emotionColors_["serenity"] = {255, 245, 150};
    emotionColors_["terror"] = {50, 150, 50};
    
    buildWheel();
}

void EmotionWheel::buildWheel() {
    segments_.clear();
    
    float anglePerCategory = 360.0f / 8.0f;
    
    // Joy family (0-45 degrees)
    addCategory("joy", 0, 
        {"ecstasy", "joy", "serenity", "happiness", "elation", "contentment"},
        {255, 230, 100});
    
    // Trust family (45-90 degrees)
    addCategory("trust", 45,
        {"admiration", "trust", "acceptance", "hope", "optimism"},
        {100, 200, 100});
    
    // Fear family (90-135 degrees)
    addCategory("fear", 90,
        {"terror", "fear", "apprehension", "anxiety", "dread", "panic"},
        {100, 200, 100});
    
    // Surprise family (135-180 degrees)
    addCategory("surprise", 135,
        {"amazement", "surprise", "distraction", "shock", "wonder"},
        {100, 200, 255});
    
    // Sadness family (180-225 degrees)
    addCategory("sadness", 180,
        {"grief", "sadness", "pensiveness", "melancholy", "sorrow", "loneliness"},
        {100, 150, 255});
    
    // Disgust family (225-270 degrees)
    addCategory("disgust", 225,
        {"loathing", "disgust", "boredom", "contempt", "revulsion"},
        {200, 100, 200});
    
    // Anger family (270-315 degrees)
    addCategory("anger", 270,
        {"rage", "anger", "annoyance", "fury", "irritation", "resentment"},
        {255, 100, 100});
    
    // Anticipation family (315-360 degrees)
    addCategory("anticipation", 315,
        {"vigilance", "anticipation", "interest", "excitement", "eagerness"},
        {255, 180, 100});
}

void EmotionWheel::addCategory(
    const std::string& category,
    float startAngle,
    const std::vector<std::string>& emotions,
    const EmotionColor& baseColor
) {
    float anglePerCategory = 45.0f;
    float endAngle = startAngle + anglePerCategory;
    
    // Main category segment
    WheelSegment mainSegment;
    mainSegment.emotion = category;
    mainSegment.category = category;
    mainSegment.startAngle = startAngle;
    mainSegment.endAngle = endAngle;
    mainSegment.innerRadius = innerRadius_;
    mainSegment.outerRadius = innerRadius_ + (outerRadius_ - innerRadius_) * 0.3f;
    mainSegment.color = baseColor.toRgb();
    mainSegment.childEmotions = emotions;
    segments_.push_back(mainSegment);
    
    // Add child emotion segments
    float subAngleSize = anglePerCategory / emotions.size();
    float radiusStep = (outerRadius_ - innerRadius_ - (outerRadius_ - innerRadius_) * 0.3f) / 3.0f;
    
    for (size_t i = 0; i < emotions.size(); ++i) {
        WheelSegment subSegment;
        subSegment.emotion = emotions[i];
        subSegment.category = category;
        subSegment.startAngle = startAngle + i * subAngleSize;
        subSegment.endAngle = startAngle + (i + 1) * subAngleSize;
        subSegment.innerRadius = innerRadius_ + (outerRadius_ - innerRadius_) * 0.3f;
        subSegment.outerRadius = outerRadius_;
        
        // Vary color slightly for each sub-emotion
        EmotionColor variedColor = baseColor;
        int variation = static_cast<int>(i) * 15 - 30;
        variedColor.r = std::clamp(static_cast<int>(baseColor.r) + variation, 0, 255);
        variedColor.g = std::clamp(static_cast<int>(baseColor.g) + variation, 0, 255);
        variedColor.b = std::clamp(static_cast<int>(baseColor.b) + variation, 0, 255);
        subSegment.color = variedColor.toRgb();
        
        segments_.push_back(subSegment);
        
        emotionToCategory_[emotions[i]] = category;
        emotionColors_[emotions[i]] = variedColor;
    }
    
    categoryEmotions_[category] = emotions;
}

WheelSelection EmotionWheel::getEmotionAtPoint(float x, float y) {
    WheelSelection selection;
    selection.x = x;
    selection.y = y;
    
    // Convert to polar coordinates
    float dx = x - centerX_;
    float dy = y - centerY_;
    float radius = std::sqrt(dx * dx + dy * dy);
    float angle = std::atan2(dy, dx) * 180.0f / 3.14159f;
    if (angle < 0) angle += 360.0f;
    
    selection.intensity = getIntensityAtRadius(radius);
    
    // Find segment
    for (const auto& segment : segments_) {
        if (radius >= segment.innerRadius && radius <= segment.outerRadius) {
            float normAngle = normalizeAngle(angle);
            float normStart = normalizeAngle(segment.startAngle);
            float normEnd = normalizeAngle(segment.endAngle);
            
            bool inAngle = false;
            if (normStart <= normEnd) {
                inAngle = (normAngle >= normStart && normAngle < normEnd);
            } else {
                inAngle = (normAngle >= normStart || normAngle < normEnd);
            }
            
            if (inAngle) {
                selection.emotion = segment.emotion;
                selection.category = segment.category;
                return selection;
            }
        }
    }
    
    selection.emotion = "neutral";
    selection.category = "neutral";
    return selection;
}

std::string EmotionWheel::getCategoryForEmotion(const std::string& emotion) const {
    auto it = emotionToCategory_.find(emotion);
    return it != emotionToCategory_.end() ? it->second : "unknown";
}

EmotionColor EmotionWheel::getColorForEmotion(const std::string& emotion) const {
    auto it = emotionColors_.find(emotion);
    return it != emotionColors_.end() ? it->second : EmotionColor{128, 128, 128};
}

std::vector<std::string> EmotionWheel::getRelatedEmotions(const std::string& emotion) const {
    std::string category = getCategoryForEmotion(emotion);
    auto it = categoryEmotions_.find(category);
    return it != categoryEmotions_.end() ? it->second : std::vector<std::string>();
}

float EmotionWheel::getIntensityAtRadius(float radius) const {
    if (radius < innerRadius_) return 0.0f;
    if (radius > outerRadius_) return 1.0f;
    return (radius - innerRadius_) / (outerRadius_ - innerRadius_);
}

float EmotionWheel::normalizeAngle(float angle) {
    while (angle < 0) angle += 360.0f;
    while (angle >= 360.0f) angle -= 360.0f;
    return angle;
}

std::pair<float, float> EmotionWheel::polarToCartesian(float angle, float radius) {
    float radians = angle * 3.14159f / 180.0f;
    return {
        centerX_ + radius * std::cos(radians),
        centerY_ + radius * std::sin(radians)
    };
}

} // namespace kelly
