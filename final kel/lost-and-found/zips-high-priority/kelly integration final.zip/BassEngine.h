#pragma once

#include "Types.h"
#include <string>
#include <vector>
#include <map>
#include <optional>

namespace kelly {

enum class BassPattern {
    Root,           // Just root notes
    RootFifth,      // Root and fifth
    Walking,        // Walking bass line
    Octave,         // Octave jumps
    Syncopated,     // Off-beat emphasis
    Arpeggiated,    // Broken chord
    Pedal,          // Sustained drone
    Driving,        // Eighth notes
    Slap,           // Funky slap style
    Ghost           // Ghost notes, subtle
};

enum class BassArticulation {
    Sustain,
    Staccato,
    Legato,
    Slide,
    Hammer,
    Muted
};

struct BassNote {
    int pitch;
    int startTick;
    int durationTicks;
    int velocity;
    BassArticulation articulation = BassArticulation::Sustain;
    int timingOffset = 0;
};

struct BassConfig {
    std::string emotion = "neutral";
    std::vector<std::string> chordProgression;
    std::string key = "C";
    int bars = 4;
    int tempoBpm = 120;
    int beatsPerBar = 4;
    std::optional<BassPattern> patternOverride;
    int seed = -1;
};

struct BassOutput {
    std::vector<BassNote> notes;
    std::string emotion;
    BassPattern patternUsed;
    int gmInstrument;
    int totalTicks;
};

struct BassEmotionProfile {
    std::vector<BassPattern> preferredPatterns;
    std::pair<int, int> velocityRange;
    float noteDensity;
    float swingAmount;
    int gmInstrument;
    std::pair<int, int> registerRange;
    float ghostNoteProbability;
};

class BassEngine {
public:
    BassEngine();
    
    BassOutput generate(
        const std::string& emotion,
        const std::vector<std::string>& chordProgression,
        const std::string& key = "C",
        int bars = 4,
        int tempoBpm = 120
    );
    
    BassOutput generate(const BassConfig& config);

private:
    std::map<std::string, BassEmotionProfile> profiles_;
    
    void initializeProfiles();
    int getRootPitch(const std::string& chord, int octave = 2);
    std::vector<BassNote> generatePattern(
        BassPattern pattern,
        const std::string& chord,
        int startTick,
        int durationTicks,
        const BassEmotionProfile& profile,
        std::mt19937& rng
    );
};

} // namespace kelly
