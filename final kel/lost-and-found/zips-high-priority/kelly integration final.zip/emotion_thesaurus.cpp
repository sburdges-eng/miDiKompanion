/**
 * emotion_thesaurus.cpp - Expanded 216-node emotion system
 * 
 * Part of Kelly MIDI Companion - Therapeutic Music Generation
 * 
 * This file provides backward compatibility with the original emotion_thesaurus
 * interface while leveraging the full EmotionThesaurus class.
 * 
 * The 216-node thesaurus is organized as:
 * - 6 primary emotion families (Plutchik's wheel)
 * - 36 emotions per family
 * - 3 dimensions: Valence, Arousal, Dominance (VAD)
 */

#include "EmotionThesaurus.h"
#include <algorithm>
#include <cmath>

namespace kelly {

//=============================================================================
// LEGACY INTERFACE STRUCTURES
//=============================================================================

struct LegacyEmotionNode {
    int id;
    std::string name;
    std::string category;
    float intensity;
    float valence;
    float arousal;
    std::vector<int> relatedIds;
};

//=============================================================================
// GLOBAL THESAURUS INSTANCE
//=============================================================================

static EmotionThesaurus g_thesaurus;

//=============================================================================
// LEGACY INTERFACE FUNCTIONS
//=============================================================================

int getEmotionCount() {
    return static_cast<int>(g_thesaurus.size());
}

bool hasEmotion(const std::string& name) {
    return g_thesaurus.getEmotion(name) != nullptr;
}

float getValence(const std::string& emotion) {
    const auto* node = g_thesaurus.getEmotion(emotion);
    return node ? node->valence : 0.0f;
}

float getArousal(const std::string& emotion) {
    const auto* node = g_thesaurus.getEmotion(emotion);
    return node ? node->arousal : 0.5f;
}

float getDominance(const std::string& emotion) {
    const auto* node = g_thesaurus.getEmotion(emotion);
    return node ? node->dominance : 0.5f;
}

std::string getCategory(const std::string& emotion) {
    const auto* node = g_thesaurus.getEmotion(emotion);
    return node ? node->category : "unknown";
}

std::vector<std::string> getSynonyms(const std::string& emotion) {
    const auto* node = g_thesaurus.getEmotion(emotion);
    return node ? node->synonyms : std::vector<std::string>();
}

std::vector<std::string> getRelatedEmotions(const std::string& emotion) {
    const auto* node = g_thesaurus.getEmotion(emotion);
    return node ? node->relatedEmotions : std::vector<std::string>();
}

std::vector<std::string> getEmotionsByCategory(const std::string& category) {
    std::vector<std::string> result;
    auto nodes = g_thesaurus.getByCategory(category);
    for (const auto* node : nodes) {
        result.push_back(node->name);
    }
    return result;
}

std::string findClosestEmotion(float valence, float arousal, float dominance) {
    const auto* node = g_thesaurus.findByVAD(valence, arousal, dominance);
    return node ? node->name : "neutral";
}

std::vector<std::string> findSimilarEmotions(const std::string& emotion, int maxResults) {
    std::vector<std::string> result;
    auto nodes = g_thesaurus.findSimilar(emotion, 0.4f);
    for (size_t i = 0; i < nodes.size() && static_cast<int>(i) < maxResults; ++i) {
        result.push_back(nodes[i]->name);
    }
    return result;
}

//=============================================================================
// EMOTION DISTANCE CALCULATIONS
//=============================================================================

float calculateEmotionDistance(const std::string& emotion1, const std::string& emotion2) {
    const auto* node1 = g_thesaurus.getEmotion(emotion1);
    const auto* node2 = g_thesaurus.getEmotion(emotion2);
    
    if (!node1 || !node2) return 1.0f;
    
    float dv = node1->valence - node2->valence;
    float da = node1->arousal - node2->arousal;
    float dd = node1->dominance - node2->dominance;
    
    return std::sqrt(dv*dv + da*da + dd*dd);
}

bool areEmotionsRelated(const std::string& emotion1, const std::string& emotion2, float threshold) {
    return calculateEmotionDistance(emotion1, emotion2) < threshold;
}

//=============================================================================
// MUSICAL ATTRIBUTE MAPPING
//=============================================================================

struct EmotionMusicalAttributes {
    float tempoModifier;
    std::string preferredMode;
    float dynamicRange;
    float harmonicComplexity;
    float rhythmicDensity;
    std::vector<std::string> suggestedInstruments;
};

EmotionMusicalAttributes getMusicalAttributes(const std::string& emotion) {
    EmotionMusicalAttributes attrs;
    
    const auto* node = g_thesaurus.getEmotion(emotion);
    if (!node) {
        attrs.tempoModifier = 1.0f;
        attrs.preferredMode = "major";
        attrs.dynamicRange = 0.5f;
        attrs.harmonicComplexity = 0.5f;
        attrs.rhythmicDensity = 0.5f;
        return attrs;
    }
    
    // Map VAD to musical attributes
    attrs.tempoModifier = 0.7f + node->arousal * 0.6f;  // 0.7 - 1.3
    attrs.preferredMode = node->valence < 0 ? "minor" : "major";
    attrs.dynamicRange = 0.3f + std::abs(node->valence) * 0.7f;
    attrs.harmonicComplexity = 0.3f + (1.0f - node->dominance) * 0.7f;
    attrs.rhythmicDensity = node->arousal;
    
    // Suggest instruments based on emotion category
    std::string category = node->category;
    
    if (category == "joy") {
        attrs.suggestedInstruments = {"piano", "strings", "brass"};
    } else if (category == "sadness") {
        attrs.suggestedInstruments = {"piano", "cello", "pad"};
    } else if (category == "anger") {
        attrs.suggestedInstruments = {"distortion_guitar", "drums", "bass"};
    } else if (category == "fear") {
        attrs.suggestedInstruments = {"strings", "synth", "percussion"};
    } else if (category == "surprise") {
        attrs.suggestedInstruments = {"bells", "piano", "orchestra"};
    } else if (category == "disgust") {
        attrs.suggestedInstruments = {"brass", "bass", "synth"};
    } else {
        attrs.suggestedInstruments = {"piano", "strings", "pad"};
    }
    
    return attrs;
}

//=============================================================================
// EMOTION INTERPOLATION
//=============================================================================

std::string interpolateEmotions(const std::string& from, const std::string& to, float t) {
    const auto* fromNode = g_thesaurus.getEmotion(from);
    const auto* toNode = g_thesaurus.getEmotion(to);
    
    if (!fromNode || !toNode) return t < 0.5f ? from : to;
    
    float v = fromNode->valence + (toNode->valence - fromNode->valence) * t;
    float a = fromNode->arousal + (toNode->arousal - fromNode->arousal) * t;
    float d = fromNode->dominance + (toNode->dominance - fromNode->dominance) * t;
    
    return findClosestEmotion(v, a, d);
}

std::vector<std::string> getEmotionPath(const std::string& from, const std::string& to, int steps) {
    std::vector<std::string> path;
    path.push_back(from);
    
    for (int i = 1; i < steps - 1; ++i) {
        float t = static_cast<float>(i) / (steps - 1);
        path.push_back(interpolateEmotions(from, to, t));
    }
    
    path.push_back(to);
    return path;
}

//=============================================================================
// EMOTION BLENDING
//=============================================================================

struct BlendedEmotion {
    std::string primary;
    std::string secondary;
    float blendRatio;
    std::string resultantEmotion;
    float confidence;
};

BlendedEmotion blendEmotions(const std::string& emotion1, const std::string& emotion2, float ratio) {
    BlendedEmotion result;
    result.primary = emotion1;
    result.secondary = emotion2;
    result.blendRatio = ratio;
    result.resultantEmotion = interpolateEmotions(emotion1, emotion2, ratio);
    result.confidence = 1.0f - calculateEmotionDistance(emotion1, emotion2) * 0.5f;
    return result;
}

//=============================================================================
// PLUTCHIK WHEEL FUNCTIONS
//=============================================================================

std::string getOppositeEmotion(const std::string& emotion) {
    const auto* node = g_thesaurus.getEmotion(emotion);
    if (!node) return emotion;
    
    // Find emotion with inverted valence
    return findClosestEmotion(-node->valence, node->arousal, node->dominance);
}

std::vector<std::string> getAdjacentEmotions(const std::string& emotion) {
    const auto* node = g_thesaurus.getEmotion(emotion);
    if (!node) return {};
    
    std::vector<std::string> adjacent;
    auto similar = g_thesaurus.findSimilar(emotion, 0.25f);
    for (const auto* s : similar) {
        if (s->name != emotion) {
            adjacent.push_back(s->name);
        }
    }
    return adjacent;
}

//=============================================================================
// EMOTION INTENSITY SCALING
//=============================================================================

std::string scaleEmotionIntensity(const std::string& emotion, float intensityScale) {
    const auto* node = g_thesaurus.getEmotion(emotion);
    if (!node) return emotion;
    
    // Scale arousal and look for matching emotion
    float scaledArousal = std::clamp(node->arousal * intensityScale, 0.0f, 1.0f);
    return findClosestEmotion(node->valence, scaledArousal, node->dominance);
}

//=============================================================================
// CATEGORY FUNCTIONS
//=============================================================================

std::vector<std::string> getAllCategories() {
    return {"joy", "sadness", "anger", "fear", "surprise", "disgust"};
}

int getCategorySize(const std::string& category) {
    return static_cast<int>(g_thesaurus.getByCategory(category).size());
}

float getCategoryValence(const std::string& category) {
    auto emotions = g_thesaurus.getByCategory(category);
    if (emotions.empty()) return 0.0f;
    
    float sum = 0;
    for (const auto* e : emotions) {
        sum += e->valence;
    }
    return sum / emotions.size();
}

//=============================================================================
// EMOTION QUERYING
//=============================================================================

std::vector<std::string> getHighArousalEmotions(float threshold) {
    std::vector<std::string> result;
    auto all = g_thesaurus.getAllEmotions();
    for (const auto& name : all) {
        const auto* node = g_thesaurus.getEmotion(name);
        if (node && node->arousal >= threshold) {
            result.push_back(name);
        }
    }
    return result;
}

std::vector<std::string> getPositiveEmotions(float threshold) {
    std::vector<std::string> result;
    auto all = g_thesaurus.getAllEmotions();
    for (const auto& name : all) {
        const auto* node = g_thesaurus.getEmotion(name);
        if (node && node->valence >= threshold) {
            result.push_back(name);
        }
    }
    return result;
}

std::vector<std::string> getNegativeEmotions(float threshold) {
    std::vector<std::string> result;
    auto all = g_thesaurus.getAllEmotions();
    for (const auto& name : all) {
        const auto* node = g_thesaurus.getEmotion(name);
        if (node && node->valence <= -threshold) {
            result.push_back(name);
        }
    }
    return result;
}

//=============================================================================
// THERAPEUTIC EMOTION FUNCTIONS
//=============================================================================

std::string suggestTherapeuticTransition(const std::string& currentEmotion) {
    const auto* node = g_thesaurus.getEmotion(currentEmotion);
    if (!node) return "serenity";
    
    // Move toward more positive, moderate arousal
    float targetValence = node->valence + (node->valence < 0 ? 0.3f : 0.1f);
    float targetArousal = 0.4f + (node->arousal - 0.5f) * 0.5f;  // Move toward middle
    
    return findClosestEmotion(targetValence, targetArousal, 0.5f);
}

std::vector<std::string> getTherapeuticPath(const std::string& from, const std::string& target, int maxSteps) {
    std::vector<std::string> path;
    path.push_back(from);
    
    std::string current = from;
    for (int i = 0; i < maxSteps - 1; ++i) {
        std::string next = suggestTherapeuticTransition(current);
        if (next == target) {
            path.push_back(target);
            break;
        }
        
        float distToTarget = calculateEmotionDistance(next, target);
        float distFromCurrent = calculateEmotionDistance(next, current);
        
        if (distFromCurrent < 0.1f || distToTarget > calculateEmotionDistance(current, target)) {
            // Stuck or moving away, interpolate directly
            next = interpolateEmotions(current, target, 0.3f);
        }
        
        path.push_back(next);
        current = next;
    }
    
    if (path.back() != target) {
        path.push_back(target);
    }
    
    return path;
}

} // namespace kelly
