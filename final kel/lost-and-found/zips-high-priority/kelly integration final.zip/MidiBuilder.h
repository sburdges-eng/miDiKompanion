#pragma once

#include "Types.h"
#include <string>
#include <vector>
#include <map>
#include <fstream>

namespace kelly {

struct MidiTrack {
    std::string name;
    int channel;
    int program;
    std::vector<MidiEvent> events;
    std::vector<MidiNote> notes;
};

struct MidiFile {
    int format = 1;
    int ticksPerBeat = 480;
    int tempoBpm = 120;
    TimeSignature timeSignature = {4, 4};
    KeySignature keySignature;
    std::vector<MidiTrack> tracks;
};

class MidiBuilder {
public:
    MidiBuilder();
    
    void setTempo(int bpm);
    void setTimeSignature(int numerator, int denominator);
    void setKeySignature(const std::string& key, const std::string& mode);
    void setTicksPerBeat(int ticks);
    
    int addTrack(const std::string& name, int channel = 0, int program = 0);
    
    void addNote(int trackIndex, int pitch, int startTick, int durationTicks, int velocity);
    void addNote(int trackIndex, const MidiNote& note);
    void addNotes(int trackIndex, const std::vector<MidiNote>& notes);
    
    void addProgramChange(int trackIndex, int program, int tick = 0);
    void addControlChange(int trackIndex, int controller, int value, int tick);
    void addPitchBend(int trackIndex, int value, int tick);
    
    MidiFile build() const;
    
    bool writeToFile(const std::string& filename) const;
    std::vector<uint8_t> toBytes() const;
    
    void clear();

private:
    MidiFile file_;
    
    std::vector<uint8_t> encodeVariableLength(uint32_t value) const;
    std::vector<uint8_t> encodeTrack(const MidiTrack& track) const;
    std::vector<uint8_t> encodeTempoEvent(int bpm) const;
    std::vector<uint8_t> encodeTimeSignatureEvent() const;
};

} // namespace kelly
