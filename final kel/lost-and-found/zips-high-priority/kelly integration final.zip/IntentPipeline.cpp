#include "WoundProcessor.h"
#include "RuleBreakEngine.h"
#include "Types.h"
#include <string>
#include <vector>
#include <map>
#include <memory>

namespace kelly {

//=============================================================================
// INTENT PIPELINE STRUCTURES
//=============================================================================

struct IntentResult {
    Wound wound;
    WoundAnalysis woundAnalysis;
    std::string primaryEmotion;
    float emotionIntensity;
    std::vector<RuleBreakResult> appliedRuleBreaks;
    std::map<std::string, float> musicalParameters;
    GenerationConfig generationConfig;
};

enum class IntentPhase {
    Wound,
    Emotion,
    RuleBreak,
    Complete
};

//=============================================================================
// INTENT PIPELINE
//=============================================================================

class IntentPipeline {
public:
    IntentPipeline() 
        : woundProcessor_(std::make_unique<WoundProcessor>())
        , ruleBreakEngine_(std::make_unique<RuleBreakEngine>())
        , currentPhase_(IntentPhase::Wound) {}
    
    IntentResult process(const Wound& wound) {
        IntentResult result;
        result.wound = wound;
        
        // Phase 1: Wound Analysis
        currentPhase_ = IntentPhase::Wound;
        result.woundAnalysis = woundProcessor_->analyze(wound);
        result.primaryEmotion = result.woundAnalysis.primaryEmotion;
        result.emotionIntensity = result.woundAnalysis.emotionalWeight;
        
        // Phase 2: Emotion Processing
        currentPhase_ = IntentPhase::Emotion;
        auto suggestedBreaks = result.woundAnalysis.suggestedRuleBreaks;
        
        // Phase 3: Rule Break Application
        currentPhase_ = IntentPhase::RuleBreak;
        result.appliedRuleBreaks = ruleBreakEngine_->applyMultiple(
            suggestedBreaks,
            result.primaryEmotion,
            result.emotionIntensity
        );
        
        // Compile musical parameters
        result.musicalParameters = compileMusicalParameters(result);
        result.generationConfig = buildGenerationConfig(result);
        
        currentPhase_ = IntentPhase::Complete;
        return result;
    }
    
    IntentResult process(const std::string& woundDescription, float intensity = 0.5f) {
        Wound wound;
        wound.description = woundDescription;
        wound.intensity = intensity;
        wound.source = woundProcessor_->classifyWound(woundDescription);
        return process(wound);
    }
    
    IntentPhase getCurrentPhase() const { return currentPhase_; }
    
    void setRuleBreakFilter(const std::vector<RuleCategory>& allowedCategories) {
        allowedCategories_ = allowedCategories;
    }

private:
    std::unique_ptr<WoundProcessor> woundProcessor_;
    std::unique_ptr<RuleBreakEngine> ruleBreakEngine_;
    IntentPhase currentPhase_;
    std::vector<RuleCategory> allowedCategories_;
    
    std::map<std::string, float> compileMusicalParameters(const IntentResult& result) {
        std::map<std::string, float> params;
        
        // Start with wound analysis implications
        params = result.woundAnalysis.musicalImplications;
        
        // Layer in rule break parameters
        for (const auto& rb : result.appliedRuleBreaks) {
            if (rb.wasApplied) {
                for (const auto& [key, value] : rb.parameters) {
                    if (params.find(key) != params.end()) {
                        params[key] = (params[key] + value) / 2.0f;
                    } else {
                        params[key] = value;
                    }
                }
            }
        }
        
        return params;
    }
    
    GenerationConfig buildGenerationConfig(const IntentResult& result) {
        GenerationConfig config;
        
        // Map emotion to tempo
        float tempoMod = 1.0f;
        if (result.musicalParameters.count("tempo_modifier")) {
            tempoMod = result.musicalParameters.at("tempo_modifier");
        }
        config.tempoBpm = static_cast<int>(100 * tempoMod);
        
        // Map to mode
        float minorTendency = 0.5f;
        if (result.musicalParameters.count("minor_tendency")) {
            minorTendency = result.musicalParameters.at("minor_tendency");
        }
        config.key.mode = minorTendency > 0.5f ? "minor" : "major";
        
        // Set emotion
        config.emotion = result.primaryEmotion;
        
        // Expressiveness from intensity
        config.expressiveness = result.emotionIntensity;
        
        // Complexity from rule break count
        config.complexity = std::min(1.0f, result.appliedRuleBreaks.size() * 0.2f);
        
        return config;
    }
};

} // namespace kelly
