#include "MidiBuilder.h"
#include <algorithm>
#include <cstring>

namespace kelly {

MidiBuilder::MidiBuilder() {
    file_.ticksPerBeat = TICKS_PER_BEAT;
}

void MidiBuilder::setTempo(int bpm) {
    file_.tempoBpm = bpm;
}

void MidiBuilder::setTimeSignature(int numerator, int denominator) {
    file_.timeSignature.numerator = numerator;
    file_.timeSignature.denominator = denominator;
}

void MidiBuilder::setKeySignature(const std::string& key, const std::string& mode) {
    file_.keySignature.root = key;
    file_.keySignature.mode = mode;
}

void MidiBuilder::setTicksPerBeat(int ticks) {
    file_.ticksPerBeat = ticks;
}

int MidiBuilder::addTrack(const std::string& name, int channel, int program) {
    MidiTrack track;
    track.name = name;
    track.channel = channel;
    track.program = program;
    file_.tracks.push_back(track);
    return static_cast<int>(file_.tracks.size()) - 1;
}

void MidiBuilder::addNote(int trackIndex, int pitch, int startTick, int durationTicks, int velocity) {
    if (trackIndex < 0 || trackIndex >= static_cast<int>(file_.tracks.size())) return;
    
    MidiNote note;
    note.pitch = pitch;
    note.startTick = startTick;
    note.durationTicks = durationTicks;
    note.velocity = velocity;
    note.channel = file_.tracks[trackIndex].channel;
    
    file_.tracks[trackIndex].notes.push_back(note);
}

void MidiBuilder::addNote(int trackIndex, const MidiNote& note) {
    if (trackIndex < 0 || trackIndex >= static_cast<int>(file_.tracks.size())) return;
    file_.tracks[trackIndex].notes.push_back(note);
}

void MidiBuilder::addNotes(int trackIndex, const std::vector<MidiNote>& notes) {
    for (const auto& note : notes) {
        addNote(trackIndex, note);
    }
}

void MidiBuilder::addProgramChange(int trackIndex, int program, int tick) {
    if (trackIndex < 0 || trackIndex >= static_cast<int>(file_.tracks.size())) return;
    
    MidiEvent event;
    event.tick = tick;
    event.type = 0xC0;
    event.channel = file_.tracks[trackIndex].channel;
    event.data1 = program;
    event.data2 = 0;
    
    file_.tracks[trackIndex].events.push_back(event);
    file_.tracks[trackIndex].program = program;
}

void MidiBuilder::addControlChange(int trackIndex, int controller, int value, int tick) {
    if (trackIndex < 0 || trackIndex >= static_cast<int>(file_.tracks.size())) return;
    
    MidiEvent event;
    event.tick = tick;
    event.type = 0xB0;
    event.channel = file_.tracks[trackIndex].channel;
    event.data1 = controller;
    event.data2 = value;
    
    file_.tracks[trackIndex].events.push_back(event);
}

void MidiBuilder::addPitchBend(int trackIndex, int value, int tick) {
    if (trackIndex < 0 || trackIndex >= static_cast<int>(file_.tracks.size())) return;
    
    MidiEvent event;
    event.tick = tick;
    event.type = 0xE0;
    event.channel = file_.tracks[trackIndex].channel;
    event.data1 = value & 0x7F;
    event.data2 = (value >> 7) & 0x7F;
    
    file_.tracks[trackIndex].events.push_back(event);
}

MidiFile MidiBuilder::build() const {
    return file_;
}

bool MidiBuilder::writeToFile(const std::string& filename) const {
    std::ofstream out(filename, std::ios::binary);
    if (!out) return false;
    
    auto bytes = toBytes();
    out.write(reinterpret_cast<const char*>(bytes.data()), bytes.size());
    return out.good();
}

std::vector<uint8_t> MidiBuilder::toBytes() const {
    std::vector<uint8_t> bytes;
    
    // Header chunk "MThd"
    bytes.push_back('M');
    bytes.push_back('T');
    bytes.push_back('h');
    bytes.push_back('d');
    
    // Header length (6 bytes)
    bytes.push_back(0);
    bytes.push_back(0);
    bytes.push_back(0);
    bytes.push_back(6);
    
    // Format type (1 = multiple tracks)
    bytes.push_back(0);
    bytes.push_back(static_cast<uint8_t>(file_.format));
    
    // Number of tracks
    int numTracks = static_cast<int>(file_.tracks.size()) + 1;  // +1 for tempo track
    bytes.push_back(static_cast<uint8_t>(numTracks >> 8));
    bytes.push_back(static_cast<uint8_t>(numTracks & 0xFF));
    
    // Ticks per beat
    bytes.push_back(static_cast<uint8_t>(file_.ticksPerBeat >> 8));
    bytes.push_back(static_cast<uint8_t>(file_.ticksPerBeat & 0xFF));
    
    // Tempo track
    std::vector<uint8_t> tempoTrack;
    auto tempoEvent = encodeTempoEvent(file_.tempoBpm);
    tempoTrack.insert(tempoTrack.end(), tempoEvent.begin(), tempoEvent.end());
    auto tsEvent = encodeTimeSignatureEvent();
    tempoTrack.insert(tempoTrack.end(), tsEvent.begin(), tsEvent.end());
    // End of track
    tempoTrack.push_back(0x00);
    tempoTrack.push_back(0xFF);
    tempoTrack.push_back(0x2F);
    tempoTrack.push_back(0x00);
    
    // Write tempo track
    bytes.push_back('M');
    bytes.push_back('T');
    bytes.push_back('r');
    bytes.push_back('k');
    uint32_t tempoLen = static_cast<uint32_t>(tempoTrack.size());
    bytes.push_back(static_cast<uint8_t>(tempoLen >> 24));
    bytes.push_back(static_cast<uint8_t>(tempoLen >> 16));
    bytes.push_back(static_cast<uint8_t>(tempoLen >> 8));
    bytes.push_back(static_cast<uint8_t>(tempoLen & 0xFF));
    bytes.insert(bytes.end(), tempoTrack.begin(), tempoTrack.end());
    
    // Encode each track
    for (const auto& track : file_.tracks) {
        auto trackBytes = encodeTrack(track);
        bytes.insert(bytes.end(), trackBytes.begin(), trackBytes.end());
    }
    
    return bytes;
}

void MidiBuilder::clear() {
    file_.tracks.clear();
    file_.tempoBpm = 120;
    file_.timeSignature = {4, 4};
}

std::vector<uint8_t> MidiBuilder::encodeVariableLength(uint32_t value) const {
    std::vector<uint8_t> result;
    
    if (value == 0) {
        result.push_back(0);
        return result;
    }
    
    std::vector<uint8_t> temp;
    while (value > 0) {
        temp.push_back(value & 0x7F);
        value >>= 7;
    }
    
    for (int i = static_cast<int>(temp.size()) - 1; i >= 0; --i) {
        if (i > 0) {
            result.push_back(temp[i] | 0x80);
        } else {
            result.push_back(temp[i]);
        }
    }
    
    return result;
}

std::vector<uint8_t> MidiBuilder::encodeTrack(const MidiTrack& track) const {
    std::vector<uint8_t> trackData;
    
    // Program change at start
    trackData.push_back(0x00);  // Delta time 0
    trackData.push_back(static_cast<uint8_t>(0xC0 | (track.channel & 0x0F)));
    trackData.push_back(static_cast<uint8_t>(track.program));
    
    // Collect all events with absolute times
    struct TimedEvent {
        int tick;
        std::vector<uint8_t> data;
    };
    std::vector<TimedEvent> events;
    
    // Add note events
    for (const auto& note : track.notes) {
        // Note on
        TimedEvent noteOn;
        noteOn.tick = note.startTick;
        noteOn.data.push_back(static_cast<uint8_t>(0x90 | (track.channel & 0x0F)));
        noteOn.data.push_back(static_cast<uint8_t>(note.pitch));
        noteOn.data.push_back(static_cast<uint8_t>(note.velocity));
        events.push_back(noteOn);
        
        // Note off
        TimedEvent noteOff;
        noteOff.tick = note.startTick + note.durationTicks;
        noteOff.data.push_back(static_cast<uint8_t>(0x80 | (track.channel & 0x0F)));
        noteOff.data.push_back(static_cast<uint8_t>(note.pitch));
        noteOff.data.push_back(0);
        events.push_back(noteOff);
    }
    
    // Sort by time
    std::sort(events.begin(), events.end(),
        [](const TimedEvent& a, const TimedEvent& b) { return a.tick < b.tick; });
    
    // Convert to delta times and write
    int lastTick = 0;
    for (const auto& event : events) {
        int delta = event.tick - lastTick;
        lastTick = event.tick;
        
        auto deltaBytes = encodeVariableLength(delta);
        trackData.insert(trackData.end(), deltaBytes.begin(), deltaBytes.end());
        trackData.insert(trackData.end(), event.data.begin(), event.data.end());
    }
    
    // End of track
    trackData.push_back(0x00);
    trackData.push_back(0xFF);
    trackData.push_back(0x2F);
    trackData.push_back(0x00);
    
    // Build complete track chunk
    std::vector<uint8_t> result;
    result.push_back('M');
    result.push_back('T');
    result.push_back('r');
    result.push_back('k');
    
    uint32_t len = static_cast<uint32_t>(trackData.size());
    result.push_back(static_cast<uint8_t>(len >> 24));
    result.push_back(static_cast<uint8_t>(len >> 16));
    result.push_back(static_cast<uint8_t>(len >> 8));
    result.push_back(static_cast<uint8_t>(len & 0xFF));
    
    result.insert(result.end(), trackData.begin(), trackData.end());
    return result;
}

std::vector<uint8_t> MidiBuilder::encodeTempoEvent(int bpm) const {
    std::vector<uint8_t> result;
    
    uint32_t microsecondsPerBeat = 60000000 / bpm;
    
    result.push_back(0x00);  // Delta time
    result.push_back(0xFF);  // Meta event
    result.push_back(0x51);  // Tempo
    result.push_back(0x03);  // Length
    result.push_back(static_cast<uint8_t>(microsecondsPerBeat >> 16));
    result.push_back(static_cast<uint8_t>(microsecondsPerBeat >> 8));
    result.push_back(static_cast<uint8_t>(microsecondsPerBeat & 0xFF));
    
    return result;
}

std::vector<uint8_t> MidiBuilder::encodeTimeSignatureEvent() const {
    std::vector<uint8_t> result;
    
    // Calculate denominator as power of 2
    int denomPow = 0;
    int denom = file_.timeSignature.denominator;
    while (denom > 1) {
        denom >>= 1;
        denomPow++;
    }
    
    result.push_back(0x00);  // Delta time
    result.push_back(0xFF);  // Meta event
    result.push_back(0x58);  // Time signature
    result.push_back(0x04);  // Length
    result.push_back(static_cast<uint8_t>(file_.timeSignature.numerator));
    result.push_back(static_cast<uint8_t>(denomPow));
    result.push_back(24);    // MIDI clocks per metronome click
    result.push_back(8);     // 32nd notes per quarter note
    
    return result;
}

} // namespace kelly
