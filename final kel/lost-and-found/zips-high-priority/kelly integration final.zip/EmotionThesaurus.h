#pragma once

#include <string>
#include <vector>
#include <map>

namespace kelly {

//=============================================================================
// EMOTION NODE DATA
//=============================================================================

struct EmotionNodeData {
    std::string name;
    std::string category;
    float valence;       // -1.0 to 1.0 (negative to positive)
    float arousal;       // 0.0 to 1.0 (calm to excited)
    float dominance;     // 0.0 to 1.0 (submissive to dominant)
    std::vector<std::string> synonyms;
    std::vector<std::string> relatedEmotions;
};

//=============================================================================
// EMOTION THESAURUS (216-node)
//=============================================================================

class EmotionThesaurus {
public:
    EmotionThesaurus();
    
    const EmotionNodeData* getEmotion(const std::string& name) const;
    std::vector<const EmotionNodeData*> getByCategory(const std::string& category) const;
    std::vector<const EmotionNodeData*> findSimilar(const std::string& emotion, float threshold = 0.3f) const;
    const EmotionNodeData* findByVAD(float valence, float arousal, float dominance) const;
    
    std::vector<std::string> getAllEmotions() const;
    std::vector<std::string> getCategories() const;
    size_t size() const { return emotions_.size(); }

private:
    std::map<std::string, EmotionNodeData> emotions_;
    std::map<std::string, std::vector<std::string>> categoryMap_;
    
    void initializeEmotions();
    void buildRelationships();
    void addEmotion(const EmotionNodeData& data);
    float calculateDistance(const EmotionNodeData& a, const EmotionNodeData& b) const;
};

} // namespace kelly
