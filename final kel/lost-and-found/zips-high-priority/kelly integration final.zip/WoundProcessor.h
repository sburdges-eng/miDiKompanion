#pragma once

#include "Types.h"
#include <string>
#include <vector>
#include <map>
#include <optional>

namespace kelly {

//=============================================================================
// ENUMS
//=============================================================================

enum class WoundSource {
    Loss,
    Betrayal,
    Rejection,
    Failure,
    Trauma,
    Loneliness,
    Regret,
    Fear,
    Shame,
    Helplessness
};

enum class WoundExpression {
    Direct,         // Express the wound directly
    Sublimated,     // Channel into something else
    Suppressed,     // Hold back, tension
    Released,       // Let go, catharsis
    Processed       // Working through
};

//=============================================================================
// DATA STRUCTURES
//=============================================================================

struct Wound {
    std::string description;
    WoundSource source = WoundSource::Loss;
    float intensity = 0.5f;         // 0.0 - 1.0
    float urgency = 0.5f;           // How pressing
    std::string desiredOutcome;     // What healing looks like
    WoundExpression expression = WoundExpression::Direct;
};

struct WoundAnalysis {
    Wound wound;
    std::string primaryEmotion;
    std::string secondaryEmotion;
    float emotionalWeight;
    std::vector<std::string> suggestedRuleBreaks;
    std::map<std::string, float> musicalImplications;
};

struct WoundProfile {
    WoundSource source;
    std::vector<std::string> associatedEmotions;
    std::vector<std::string> defaultRuleBreaks;
    std::map<std::string, float> musicalTendencies;
    std::string therapeuticApproach;
};

//=============================================================================
// WOUND PROCESSOR
//=============================================================================

class WoundProcessor {
public:
    WoundProcessor();
    
    WoundAnalysis analyze(const Wound& wound);
    WoundAnalysis analyze(const std::string& description, float intensity = 0.5f);
    
    std::string mapToEmotion(WoundSource source, float intensity);
    std::vector<std::string> suggestRuleBreaks(const Wound& wound);
    
    const WoundProfile* getProfile(WoundSource source) const;
    WoundSource classifyWound(const std::string& description) const;

private:
    std::map<WoundSource, WoundProfile> profiles_;
    
    void initializeProfiles();
    float calculateEmotionalWeight(const Wound& wound) const;
    std::map<std::string, float> deriveMusicalImplications(const Wound& wound) const;
};

} // namespace kelly
