#include "WoundProcessor.h"
#include <algorithm>
#include <cctype>

namespace kelly {

//=============================================================================
// CONSTRUCTOR
//=============================================================================

WoundProcessor::WoundProcessor() {
    initializeProfiles();
}

//=============================================================================
// PROFILE INITIALIZATION
//=============================================================================

void WoundProcessor::initializeProfiles() {
    profiles_[WoundSource::Loss] = {
        WoundSource::Loss,
        {"grief", "sadness", "longing", "melancholy", "yearning"},
        {"HARMONY_AvoidTonicResolution", "RHYTHM_BreathingSpace", "DYNAMICS_SubtleSwells"},
        {{"tempo_modifier", 0.85f}, {"minor_tendency", 0.8f}, {"space", 0.7f}},
        "Allow space for grief to breathe"
    };
    
    profiles_[WoundSource::Betrayal] = {
        WoundSource::Betrayal,
        {"anger", "hurt", "distrust", "bitterness", "resentment"},
        {"HARMONY_UnexpectedModulation", "RHYTHM_Syncopation", "DYNAMICS_SuddenContrasts"},
        {{"tempo_modifier", 1.1f}, {"dissonance", 0.6f}, {"instability", 0.7f}},
        "Validate the betrayal, channel rage constructively"
    };
    
    profiles_[WoundSource::Rejection] = {
        WoundSource::Rejection,
        {"sadness", "shame", "loneliness", "unworthiness", "isolation"},
        {"HARMONY_ModalInterchange", "RHYTHM_Isolation", "ARRANGEMENT_SparseTexture"},
        {{"tempo_modifier", 0.9f}, {"minor_tendency", 0.7f}, {"sparse", 0.6f}},
        "Gentle affirmation, build connection"
    };
    
    profiles_[WoundSource::Failure] = {
        WoundSource::Failure,
        {"shame", "disappointment", "frustration", "self_doubt", "regret"},
        {"HARMONY_DeceptiveCadence", "RHYTHM_Hesitation", "DYNAMICS_Restraint"},
        {{"tempo_modifier", 0.95f}, {"uncertainty", 0.5f}, {"restraint", 0.6f}},
        "Reframe failure as learning"
    };
    
    profiles_[WoundSource::Trauma] = {
        WoundSource::Trauma,
        {"fear", "hypervigilance", "numbness", "grief", "anger"},
        {"HARMONY_ChromaticMovement", "RHYTHM_Fragmentation", "DYNAMICS_Unpredictable"},
        {{"tempo_modifier", 1.0f}, {"tension", 0.8f}, {"unpredictability", 0.7f}},
        "Safety first, gradual exposure"
    };
    
    profiles_[WoundSource::Loneliness] = {
        WoundSource::Loneliness,
        {"sadness", "emptiness", "yearning", "isolation", "melancholy"},
        {"ARRANGEMENT_Solo", "RHYTHM_Sparse", "HARMONY_Unresolved"},
        {{"tempo_modifier", 0.88f}, {"sparse", 0.8f}, {"echo", 0.6f}},
        "Acknowledge isolation, suggest connection"
    };
    
    profiles_[WoundSource::Regret] = {
        WoundSource::Regret,
        {"sadness", "guilt", "nostalgia", "longing", "melancholy"},
        {"HARMONY_RevisitMotif", "RHYTHM_Retrospective", "DYNAMICS_Fading"},
        {{"tempo_modifier", 0.82f}, {"nostalgia", 0.7f}, {"minor_tendency", 0.6f}},
        "Accept what cannot change"
    };
    
    profiles_[WoundSource::Fear] = {
        WoundSource::Fear,
        {"anxiety", "dread", "panic", "apprehension", "terror"},
        {"HARMONY_Diminished", "RHYTHM_Accelerating", "DYNAMICS_Building"},
        {{"tempo_modifier", 1.15f}, {"tension", 0.9f}, {"instability", 0.8f}},
        "Ground and soothe"
    };
    
    profiles_[WoundSource::Shame] = {
        WoundSource::Shame,
        {"humiliation", "unworthiness", "self_loathing", "exposure", "hiding"},
        {"HARMONY_Chromatic", "RHYTHM_Withdrawn", "ARRANGEMENT_Hidden"},
        {{"tempo_modifier", 0.9f}, {"withdrawn", 0.7f}, {"minor_tendency", 0.8f}},
        "Compassionate witness"
    };
    
    profiles_[WoundSource::Helplessness] = {
        WoundSource::Helplessness,
        {"despair", "frustration", "resignation", "hopelessness", "surrender"},
        {"HARMONY_Stasis", "RHYTHM_Repetitive", "DYNAMICS_Flat"},
        {{"tempo_modifier", 0.75f}, {"static", 0.8f}, {"weight", 0.7f}},
        "Small steps toward agency"
    };
}

//=============================================================================
// ANALYSIS
//=============================================================================

WoundAnalysis WoundProcessor::analyze(const Wound& wound) {
    WoundAnalysis analysis;
    analysis.wound = wound;
    
    const auto* profile = getProfile(wound.source);
    if (profile && !profile->associatedEmotions.empty()) {
        analysis.primaryEmotion = profile->associatedEmotions[0];
        if (profile->associatedEmotions.size() > 1) {
            analysis.secondaryEmotion = profile->associatedEmotions[1];
        }
    }
    
    analysis.emotionalWeight = calculateEmotionalWeight(wound);
    analysis.suggestedRuleBreaks = suggestRuleBreaks(wound);
    analysis.musicalImplications = deriveMusicalImplications(wound);
    
    return analysis;
}

WoundAnalysis WoundProcessor::analyze(const std::string& description, float intensity) {
    Wound wound;
    wound.description = description;
    wound.intensity = intensity;
    wound.source = classifyWound(description);
    return analyze(wound);
}

//=============================================================================
// EMOTION MAPPING
//=============================================================================

std::string WoundProcessor::mapToEmotion(WoundSource source, float intensity) {
    const auto* profile = getProfile(source);
    if (!profile || profile->associatedEmotions.empty()) {
        return "neutral";
    }
    
    size_t index = static_cast<size_t>(intensity * (profile->associatedEmotions.size() - 1));
    index = std::min(index, profile->associatedEmotions.size() - 1);
    return profile->associatedEmotions[index];
}

//=============================================================================
// RULE BREAKS
//=============================================================================

std::vector<std::string> WoundProcessor::suggestRuleBreaks(const Wound& wound) {
    std::vector<std::string> breaks;
    
    const auto* profile = getProfile(wound.source);
    if (profile) {
        breaks = profile->defaultRuleBreaks;
    }
    
    if (wound.intensity > 0.8f) {
        breaks.push_back("DYNAMICS_ExtremeContrasts");
    }
    if (wound.urgency > 0.7f) {
        breaks.push_back("RHYTHM_Accelerando");
    }
    if (wound.expression == WoundExpression::Suppressed) {
        breaks.push_back("DYNAMICS_BuildingTension");
    }
    if (wound.expression == WoundExpression::Released) {
        breaks.push_back("DYNAMICS_Catharsis");
    }
    
    return breaks;
}

//=============================================================================
// HELPERS
//=============================================================================

const WoundProfile* WoundProcessor::getProfile(WoundSource source) const {
    auto it = profiles_.find(source);
    return it != profiles_.end() ? &it->second : nullptr;
}

WoundSource WoundProcessor::classifyWound(const std::string& description) const {
    std::string lower = description;
    std::transform(lower.begin(), lower.end(), lower.begin(), ::tolower);
    
    if (lower.find("lost") != std::string::npos || 
        lower.find("died") != std::string::npos ||
        lower.find("gone") != std::string::npos ||
        lower.find("death") != std::string::npos) {
        return WoundSource::Loss;
    }
    if (lower.find("betray") != std::string::npos ||
        lower.find("cheat") != std::string::npos ||
        lower.find("lied") != std::string::npos) {
        return WoundSource::Betrayal;
    }
    if (lower.find("reject") != std::string::npos ||
        lower.find("abandon") != std::string::npos) {
        return WoundSource::Rejection;
    }
    if (lower.find("fail") != std::string::npos ||
        lower.find("mistake") != std::string::npos) {
        return WoundSource::Failure;
    }
    if (lower.find("trauma") != std::string::npos ||
        lower.find("abuse") != std::string::npos) {
        return WoundSource::Trauma;
    }
    if (lower.find("alone") != std::string::npos ||
        lower.find("lonely") != std::string::npos) {
        return WoundSource::Loneliness;
    }
    if (lower.find("regret") != std::string::npos ||
        lower.find("wish") != std::string::npos) {
        return WoundSource::Regret;
    }
    if (lower.find("afraid") != std::string::npos ||
        lower.find("fear") != std::string::npos ||
        lower.find("scared") != std::string::npos) {
        return WoundSource::Fear;
    }
    if (lower.find("shame") != std::string::npos ||
        lower.find("embarrass") != std::string::npos) {
        return WoundSource::Shame;
    }
    if (lower.find("helpless") != std::string::npos ||
        lower.find("hopeless") != std::string::npos ||
        lower.find("stuck") != std::string::npos) {
        return WoundSource::Helplessness;
    }
    
    return WoundSource::Loss;
}

float WoundProcessor::calculateEmotionalWeight(const Wound& wound) const {
    float weight = wound.intensity;
    weight += wound.urgency * 0.3f;
    
    if (wound.expression == WoundExpression::Suppressed) {
        weight *= 1.2f;
    }
    
    return std::min(1.0f, weight);
}

std::map<std::string, float> WoundProcessor::deriveMusicalImplications(const Wound& wound) const {
    std::map<std::string, float> implications;
    
    const auto* profile = getProfile(wound.source);
    if (profile) {
        implications = profile->musicalTendencies;
    }
    
    for (auto& [key, value] : implications) {
        value *= wound.intensity;
    }
    
    implications["emotional_weight"] = calculateEmotionalWeight(wound);
    
    return implications;
}

} // namespace kelly
