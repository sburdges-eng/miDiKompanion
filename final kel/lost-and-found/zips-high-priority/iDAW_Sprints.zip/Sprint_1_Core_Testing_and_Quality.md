# Sprint 1 – Core Testing & Quality
- Run full test suite
- Fix failures
...