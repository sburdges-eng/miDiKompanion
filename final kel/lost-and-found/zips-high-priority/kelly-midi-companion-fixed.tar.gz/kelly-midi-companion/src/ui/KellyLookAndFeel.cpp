#include <juce_gui_basics/juce_gui_basics.h>
namespace kelly { /* Stub - will be implemented in Phase 3 */ }
