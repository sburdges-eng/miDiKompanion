#include <juce_gui_basics/juce_gui_basics.h>
namespace kelly { /* Stub - see PluginEditor.cpp */ }
