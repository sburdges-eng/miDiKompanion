#include "common/Types.h"

// Stub files for future expansion
// WoundProcessor.cpp - Currently integrated into IntentPipeline
// RuleBreakEngine.cpp - Currently integrated into IntentPipeline

namespace kelly {
// These are placeholder implementations
// The functionality is currently in IntentPipeline.cpp
} // namespace kelly
