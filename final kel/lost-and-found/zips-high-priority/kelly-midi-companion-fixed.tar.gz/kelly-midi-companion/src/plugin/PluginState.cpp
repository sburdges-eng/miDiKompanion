// Stub implementations for components that need minimal code

// ============================================================================
// src/plugin/PluginState.cpp
// ============================================================================
#include "common/Types.h"

namespace kelly {
// Plugin state management - currently handled by JUCE's ValueTreeState
} // namespace kelly
