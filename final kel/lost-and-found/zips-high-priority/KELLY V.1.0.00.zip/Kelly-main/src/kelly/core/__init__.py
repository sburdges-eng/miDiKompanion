"""Core module init."""
