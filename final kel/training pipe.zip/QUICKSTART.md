# Kelly ML Training - Quick Start

## 1. Install Dependencies

```bash
pip install torch librosa pandas pretty_midi tqdm zenodo_get
```

## 2. Get Datasets

### Option A: Auto-download EMOPIA
```bash
python train_kelly_models.py --download
```

### Option B: Manual download

**DEAM** (1,802 songs, ~14GB):
```
https://cvml.unige.ch/databases/DEAM/
├── DEAM_audio.zip        # Audio files
└── DEAM_Annotations.zip  # Valence/arousal labels
```

**EMOPIA** (1,087 clips, ~200MB):
```
https://zenodo.org/record/5090631
└── EMOPIA_1.0/midis/     # MIDI files with Q1-Q4 emotion labels
```

Extract to:
```
./data/
├── DEAM/
│   ├── DEAM_audio/
│   └── annotations/
└── EMOPIA/
    └── midis/
```

## 3. Train Models

```bash
# Full training (recommended)
python train_kelly_models.py \
    --deam-path ./data/DEAM \
    --emopia-path ./data/EMOPIA \
    --output ./trained_models \
    --epochs 100 \
    --device auto

# Quick test (synthetic data if datasets missing)
python train_kelly_models.py --epochs 10
```

## 4. Output Structure

```
./trained_models/
├── emotionrecognizer.json   # RTNeural format
├── melodytransformer.json
├── harmonypredictor.json
├── dynamicsengine.json
├── groovepredictor.json
├── checkpoints/
│   ├── emotionrecognizer.pt # PyTorch weights
│   └── ...
└── cache/
    ├── deam_cache.pt        # Preprocessed DEAM
    └── emopia_cache.pt      # Preprocessed EMOPIA
```

## 5. Copy to Plugin

```bash
cp trained_models/*.json /path/to/kelly/Resources/models/
```

## Training Time Estimates

| Dataset Size | Device | Time |
|--------------|--------|------|
| Synthetic only | CPU | ~5 min |
| EMOPIA only | CPU | ~30 min |
| DEAM + EMOPIA | CPU | ~2 hours |
| DEAM + EMOPIA | GPU/MPS | ~20 min |

## Troubleshooting

**"librosa not found"**
```bash
pip install librosa soundfile
```

**"DEAM audio not found"**
- Check path structure matches expected layout
- Script will fall back to synthetic data

**"Out of memory"**
```bash
python train_kelly_models.py --batch-size 16
```

**Apple Silicon (M1/M2/M3)**
```bash
python train_kelly_models.py --device mps
```
