#!/usr/bin/env python3
"""
Kelly MIDI Companion - Full Training Pipeline
==============================================
Trains all 5 models using real data:
- DEAM dataset: Audio → Emotion (EmotionRecognizer)
- EMOPIA dataset: Emotion → MIDI (MelodyTransformer, HarmonyPredictor)
- Synthetic augmentation: DynamicsEngine, GroovePredictor

Usage:
    python train_kelly_models.py --deam-path ./data/DEAM --emopia-path ./data/EMOPIA
    python train_kelly_models.py --download  # Auto-download datasets
"""

import os
import sys
import json
import argparse
import subprocess
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader, random_split
import tqdm

# Optional imports with fallbacks
try:
    import librosa
    HAS_LIBROSA = True
except ImportError:
    HAS_LIBROSA = False
    print("Warning: librosa not installed. Run: pip install librosa")

try:
    import pandas as pd
    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False
    print("Warning: pandas not installed. Run: pip install pandas")

try:
    import pretty_midi
    HAS_PRETTY_MIDI = True
except ImportError:
    HAS_PRETTY_MIDI = False
    print("Warning: pretty_midi not installed. Run: pip install pretty_midi")


# =============================================================================
# CONFIGURATION
# =============================================================================

@dataclass
class TrainingConfig:
    """Training configuration."""
    # Paths
    deam_path: str = "./data/DEAM"
    emopia_path: str = "./data/EMOPIA"
    output_dir: str = "./trained_models"
    
    # Training params
    batch_size: int = 32
    epochs_emotion: int = 100
    epochs_melody: int = 100
    epochs_harmony: int = 50
    epochs_dynamics: int = 30
    epochs_groove: int = 30
    learning_rate: float = 0.001
    
    # Audio processing
    sample_rate: int = 22050
    n_mels: int = 128
    duration: float = 30.0  # seconds per clip
    
    # Model architecture
    emotion_hidden: List[int] = field(default_factory=lambda: [512, 256, 128])
    melody_hidden: List[int] = field(default_factory=lambda: [256, 256, 256])
    
    # Device
    device: str = "auto"  # auto, cpu, cuda, mps


# =============================================================================
# KELLY EMOTION MAPPING
# =============================================================================

KELLY_EMOTIONS = {
    # Base emotions with valence/arousal ranges
    "joy": {"valence": (0.5, 1.0), "arousal": (0.4, 0.8)},
    "happiness": {"valence": (0.4, 0.8), "arousal": (0.5, 0.7)},
    "contentment": {"valence": (0.3, 0.7), "arousal": (0.2, 0.5)},
    "elation": {"valence": (0.6, 1.0), "arousal": (0.7, 1.0)},
    "pride": {"valence": (0.4, 0.8), "arousal": (0.5, 0.8)},
    "relief": {"valence": (0.3, 0.6), "arousal": (0.1, 0.4)},
    
    "sadness": {"valence": (-0.8, -0.3), "arousal": (0.1, 0.4)},
    "grief": {"valence": (-1.0, -0.6), "arousal": (0.2, 0.5)},
    "melancholy": {"valence": (-0.6, -0.2), "arousal": (0.2, 0.5)},
    "despair": {"valence": (-1.0, -0.7), "arousal": (0.1, 0.4)},
    "loneliness": {"valence": (-0.7, -0.3), "arousal": (0.1, 0.3)},
    "disappointment": {"valence": (-0.5, -0.2), "arousal": (0.2, 0.4)},
    "regret": {"valence": (-0.6, -0.3), "arousal": (0.2, 0.5)},
    
    "anger": {"valence": (-0.8, -0.3), "arousal": (0.6, 1.0)},
    "rage": {"valence": (-1.0, -0.6), "arousal": (0.8, 1.0)},
    "frustration": {"valence": (-0.6, -0.2), "arousal": (0.5, 0.8)},
    "irritation": {"valence": (-0.4, -0.1), "arousal": (0.4, 0.7)},
    "resentment": {"valence": (-0.7, -0.3), "arousal": (0.4, 0.7)},
    "defiance": {"valence": (-0.5, 0.0), "arousal": (0.6, 0.9)},
    "bitterness": {"valence": (-0.8, -0.4), "arousal": (0.3, 0.6)},
    
    "fear": {"valence": (-0.8, -0.3), "arousal": (0.5, 0.9)},
    "anxiety": {"valence": (-0.6, -0.2), "arousal": (0.5, 0.8)},
    "terror": {"valence": (-1.0, -0.7), "arousal": (0.8, 1.0)},
    "dread": {"valence": (-0.8, -0.5), "arousal": (0.4, 0.7)},
    "worry": {"valence": (-0.5, -0.2), "arousal": (0.4, 0.7)},
    "nervousness": {"valence": (-0.4, -0.1), "arousal": (0.5, 0.8)},
    "panic": {"valence": (-0.9, -0.5), "arousal": (0.8, 1.0)},
    
    "surprise": {"valence": (-0.2, 0.4), "arousal": (0.6, 1.0)},
    "astonishment": {"valence": (0.0, 0.5), "arousal": (0.7, 1.0)},
    "amazement": {"valence": (0.2, 0.6), "arousal": (0.6, 0.9)},
    "shock": {"valence": (-0.4, 0.1), "arousal": (0.7, 1.0)},
    "wonder": {"valence": (0.3, 0.7), "arousal": (0.5, 0.8)},
    "confusion": {"valence": (-0.3, 0.1), "arousal": (0.4, 0.7)},
}

def va_to_kelly_emotion(valence: float, arousal: float) -> Tuple[str, float]:
    """
    Map valence-arousal to closest Kelly emotion.
    
    Returns: (emotion_name, confidence)
    """
    best_emotion = "melancholy"
    best_distance = float('inf')
    
    for emotion, ranges in KELLY_EMOTIONS.items():
        v_range = ranges["valence"]
        a_range = ranges["arousal"]
        
        # Center of emotion region
        v_center = (v_range[0] + v_range[1]) / 2
        a_center = (a_range[0] + a_range[1]) / 2
        
        # Distance to center
        dist = np.sqrt((valence - v_center)**2 + (arousal - a_center)**2)
        
        if dist < best_distance:
            best_distance = dist
            best_emotion = emotion
    
    # Confidence based on distance (closer = higher)
    confidence = max(0.0, 1.0 - best_distance)
    
    return best_emotion, confidence


def kelly_emotion_to_embedding(emotion: str, intensity: float = 0.7) -> np.ndarray:
    """Convert Kelly emotion name to 64-dim embedding."""
    embedding = np.zeros(64, dtype=np.float32)
    
    if emotion not in KELLY_EMOTIONS:
        return embedding
    
    ranges = KELLY_EMOTIONS[emotion]
    valence = (ranges["valence"][0] + ranges["valence"][1]) / 2
    arousal = (ranges["arousal"][0] + ranges["arousal"][1]) / 2
    
    # Encode valence in dims 0-15
    for i in range(16):
        embedding[i] = valence * (1.0 - i / 32.0) * intensity
    
    # Encode arousal in dims 16-31
    for i in range(16, 32):
        embedding[i] = (arousal * 2 - 1) * (1.0 - (i - 16) / 32.0) * intensity
    
    # Encode emotion category in dims 32-47
    emotion_categories = ["joy", "sadness", "anger", "fear", "surprise", "disgust"]
    for i, cat in enumerate(emotion_categories):
        if emotion.startswith(cat) or emotion in KELLY_EMOTIONS:
            if cat in emotion or any(emotion in e for e in KELLY_EMOTIONS if cat in e):
                embedding[32 + i * 2] = intensity
                embedding[33 + i * 2] = intensity * 0.5
    
    # Intensity in dims 48-63
    for i in range(48, 64):
        embedding[i] = intensity * np.random.normal(0.5, 0.1)
    
    return embedding


# =============================================================================
# DATASET LOADERS
# =============================================================================

class DEAMDataset(Dataset):
    """DEAM dataset for emotion recognition training."""
    
    def __init__(self, deam_path: str, config: TrainingConfig, cache_path: Optional[str] = None):
        self.config = config
        self.data = []
        
        # Try to load from cache
        if cache_path and os.path.exists(cache_path):
            print(f"Loading DEAM from cache: {cache_path}")
            self.data = torch.load(cache_path)
            return
        
        if not HAS_LIBROSA or not HAS_PANDAS:
            print("DEAM requires librosa and pandas. Using synthetic data.")
            self._generate_synthetic(1000)
            return
        
        deam_path = Path(deam_path)
        
        # Find annotations file
        annotation_paths = [
            deam_path / "annotations" / "annotations averaged per song" / "song_level" / "static_annotations_averaged_songs_1_2000.csv",
            deam_path / "DEAM_Annotations" / "annotations averaged per song" / "song_level" / "static_annotations_averaged_songs_1_2000.csv",
            deam_path / "static_annotations_averaged_songs_1_2000.csv",
        ]
        
        annotations_file = None
        for path in annotation_paths:
            if path.exists():
                annotations_file = path
                break
        
        if annotations_file is None:
            print(f"DEAM annotations not found. Using synthetic data.")
            self._generate_synthetic(1000)
            return
        
        print(f"Loading DEAM annotations from: {annotations_file}")
        annotations = pd.read_csv(annotations_file)
        
        # Find audio directory
        audio_paths = [
            deam_path / "DEAM_audio" / "MEMD_audio",
            deam_path / "audio",
            deam_path / "DEAM_audio",
        ]
        
        audio_dir = None
        for path in audio_paths:
            if path.exists():
                audio_dir = path
                break
        
        if audio_dir is None:
            print(f"DEAM audio not found. Using synthetic data.")
            self._generate_synthetic(1000)
            return
        
        print(f"Loading DEAM audio from: {audio_dir}")
        
        # Process each song
        for _, row in tqdm.tqdm(annotations.iterrows(), total=len(annotations), desc="Processing DEAM"):
            song_id = int(row['song_id'])
            
            # Find audio file
            audio_file = None
            for ext in ['.mp3', '.wav', '.flac']:
                candidate = audio_dir / f"{song_id}{ext}"
                if candidate.exists():
                    audio_file = candidate
                    break
            
            if audio_file is None:
                continue
            
            try:
                # Load audio
                y, sr = librosa.load(str(audio_file), sr=config.sample_rate, duration=config.duration)
                
                # Extract mel spectrogram
                mel = librosa.feature.melspectrogram(y=y, sr=sr, n_mels=config.n_mels)
                mel_db = librosa.power_to_db(mel, ref=np.max)
                
                # Average over time → 128-dim feature
                features = mel_db.mean(axis=1).astype(np.float32)
                
                # Normalize to [-1, 1]
                features = (features - features.mean()) / (features.std() + 1e-8)
                
                # Get valence/arousal (DEAM uses 1-9 scale)
                valence = (row['valence_mean'] - 5) / 4  # → [-1, 1]
                arousal = (row['arousal_mean'] - 5) / 4  # → [-1, 1]
                arousal = (arousal + 1) / 2  # → [0, 1]
                
                # Map to Kelly emotion
                kelly_emotion, confidence = va_to_kelly_emotion(valence, arousal)
                
                # Create target embedding
                target = kelly_emotion_to_embedding(kelly_emotion, confidence)
                
                self.data.append({
                    'features': torch.tensor(features),
                    'target': torch.tensor(target),
                    'valence': valence,
                    'arousal': arousal,
                    'emotion': kelly_emotion,
                    'song_id': song_id
                })
                
            except Exception as e:
                continue
        
        print(f"Loaded {len(self.data)} samples from DEAM")
        
        # Save cache
        if cache_path:
            torch.save(self.data, cache_path)
    
    def _generate_synthetic(self, n_samples: int):
        """Generate synthetic data as fallback."""
        print(f"Generating {n_samples} synthetic samples...")
        
        for i in range(n_samples):
            # Random features
            features = np.random.randn(128).astype(np.float32)
            
            # Random valence/arousal
            valence = np.random.uniform(-1, 1)
            arousal = np.random.uniform(0, 1)
            
            # Map to emotion
            kelly_emotion, confidence = va_to_kelly_emotion(valence, arousal)
            target = kelly_emotion_to_embedding(kelly_emotion, confidence)
            
            self.data.append({
                'features': torch.tensor(features),
                'target': torch.tensor(target),
                'valence': valence,
                'arousal': arousal,
                'emotion': kelly_emotion,
                'song_id': i
            })
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        return self.data[idx]


class EMOPIADataset(Dataset):
    """EMOPIA dataset for emotion-conditioned MIDI generation."""
    
    def __init__(self, emopia_path: str, config: TrainingConfig, cache_path: Optional[str] = None):
        self.config = config
        self.data = []
        
        # Try to load from cache
        if cache_path and os.path.exists(cache_path):
            print(f"Loading EMOPIA from cache: {cache_path}")
            self.data = torch.load(cache_path)
            return
        
        if not HAS_PRETTY_MIDI:
            print("EMOPIA requires pretty_midi. Using synthetic data.")
            self._generate_synthetic(1000)
            return
        
        emopia_path = Path(emopia_path)
        
        # Find MIDI directory
        midi_paths = [
            emopia_path / "midis",
            emopia_path / "EMOPIA_1.0" / "midis",
            emopia_path,
        ]
        
        midi_dir = None
        for path in midi_paths:
            if path.exists() and list(path.glob("**/*.mid")):
                midi_dir = path
                break
        
        if midi_dir is None:
            print(f"EMOPIA MIDIs not found. Using synthetic data.")
            self._generate_synthetic(1000)
            return
        
        print(f"Loading EMOPIA from: {midi_dir}")
        
        # Quadrant mapping
        quadrant_emotions = {
            'Q1': {'valence': 0.7, 'arousal': 0.7, 'name': 'elation'},
            'Q2': {'valence': -0.7, 'arousal': 0.7, 'name': 'anger'},
            'Q3': {'valence': -0.7, 'arousal': 0.3, 'name': 'sadness'},
            'Q4': {'valence': 0.7, 'arousal': 0.3, 'name': 'contentment'},
        }
        
        midi_files = list(midi_dir.glob("**/*.mid")) + list(midi_dir.glob("**/*.midi"))
        
        for midi_file in tqdm.tqdm(midi_files, desc="Processing EMOPIA"):
            # Parse quadrant from filename
            filename = midi_file.stem
            quadrant = None
            for q in ['Q1', 'Q2', 'Q3', 'Q4']:
                if q in filename:
                    quadrant = q
                    break
            
            if quadrant is None:
                continue
            
            try:
                midi = pretty_midi.PrettyMIDI(str(midi_file))
                
                # Extract notes
                all_notes = []
                for instrument in midi.instruments:
                    if instrument.is_drum:
                        continue
                    for note in instrument.notes:
                        all_notes.append({
                            'pitch': note.pitch,
                            'start': note.start,
                            'end': note.end,
                            'velocity': note.velocity
                        })
                
                if len(all_notes) < 10:
                    continue
                
                all_notes.sort(key=lambda x: x['start'])
                
                # Create emotion embedding
                emo = quadrant_emotions[quadrant]
                kelly_emotion, conf = va_to_kelly_emotion(emo['valence'], emo['arousal'])
                emotion_embedding = kelly_emotion_to_embedding(kelly_emotion, conf)
                
                # Create note probability distribution (128 MIDI notes)
                note_probs = np.zeros(128, dtype=np.float32)
                for note in all_notes:
                    note_probs[note['pitch']] += 1
                note_probs = note_probs / (note_probs.sum() + 1e-8)
                
                # Extract chord information (simplified)
                # Group notes by time windows
                harmony = np.zeros(64, dtype=np.float32)
                for i, note in enumerate(all_notes[:64]):
                    harmony[i % 64] = note['pitch'] / 127.0
                
                self.data.append({
                    'emotion_embedding': torch.tensor(emotion_embedding),
                    'note_probs': torch.tensor(note_probs),
                    'harmony': torch.tensor(harmony),
                    'quadrant': quadrant,
                    'emotion_name': kelly_emotion,
                    'file': midi_file.name
                })
                
            except Exception as e:
                continue
        
        print(f"Loaded {len(self.data)} samples from EMOPIA")
        
        # Save cache
        if cache_path:
            torch.save(self.data, cache_path)
    
    def _generate_synthetic(self, n_samples: int):
        """Generate synthetic data as fallback."""
        print(f"Generating {n_samples} synthetic MIDI samples...")
        
        for i in range(n_samples):
            # Random emotion
            valence = np.random.uniform(-1, 1)
            arousal = np.random.uniform(0, 1)
            kelly_emotion, conf = va_to_kelly_emotion(valence, arousal)
            emotion_embedding = kelly_emotion_to_embedding(kelly_emotion, conf)
            
            # Generate note distribution based on emotion
            note_probs = np.zeros(128, dtype=np.float32)
            
            # Base note range based on arousal
            if arousal > 0.5:
                center = 72  # Higher energy = higher notes
            else:
                center = 60
            
            # Mode based on valence
            if valence > 0:
                scale = [0, 2, 4, 5, 7, 9, 11]  # Major
            else:
                scale = [0, 2, 3, 5, 7, 8, 10]  # Minor
            
            for degree in scale:
                for octave in [-12, 0, 12]:
                    note = center + degree + octave
                    if 0 <= note < 128:
                        note_probs[note] = np.random.uniform(0.5, 1.0)
            
            note_probs = note_probs / (note_probs.sum() + 1e-8)
            
            # Random harmony
            harmony = np.random.randn(64).astype(np.float32) * 0.3
            
            self.data.append({
                'emotion_embedding': torch.tensor(emotion_embedding),
                'note_probs': torch.tensor(note_probs),
                'harmony': torch.tensor(harmony),
                'quadrant': f'Q{(i % 4) + 1}',
                'emotion_name': kelly_emotion,
                'file': f'synthetic_{i}.mid'
            })
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        return self.data[idx]


# =============================================================================
# MODEL DEFINITIONS
# =============================================================================

class EmotionRecognizer(nn.Module):
    """Audio features → 64-dim emotion embedding."""
    
    def __init__(self, input_size=128, hidden_sizes=[512, 256, 128], output_size=64):
        super().__init__()
        
        layers = []
        prev_size = input_size
        
        for hidden_size in hidden_sizes[:-1]:
            layers.extend([
                nn.Linear(prev_size, hidden_size),
                nn.BatchNorm1d(hidden_size),
                nn.Tanh(),
                nn.Dropout(0.2)
            ])
            prev_size = hidden_size
        
        # LSTM layer
        self.lstm = nn.LSTM(prev_size, hidden_sizes[-1], batch_first=True, bidirectional=True)
        
        # Final projection
        self.fc_out = nn.Linear(hidden_sizes[-1] * 2, output_size)
        self.activation = nn.Tanh()
        
        self.encoder = nn.Sequential(*layers)
    
    def forward(self, x):
        # x: (batch, 128)
        x = self.encoder(x)
        x = x.unsqueeze(1)  # (batch, 1, hidden)
        x, _ = self.lstm(x)
        x = x.squeeze(1)  # (batch, hidden*2)
        x = self.activation(self.fc_out(x))
        return x


class MelodyTransformer(nn.Module):
    """Emotion embedding → 128-dim note probabilities."""
    
    def __init__(self, input_size=64, hidden_sizes=[256, 256, 256], output_size=128):
        super().__init__()
        
        layers = []
        prev_size = input_size
        
        for hidden_size in hidden_sizes:
            layers.extend([
                nn.Linear(prev_size, hidden_size),
                nn.BatchNorm1d(hidden_size),
                nn.ReLU(),
                nn.Dropout(0.2)
            ])
            prev_size = hidden_size
        
        layers.append(nn.Linear(prev_size, output_size))
        layers.append(nn.Softmax(dim=-1))
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.network(x)


class HarmonyPredictor(nn.Module):
    """Context → 64-dim chord probabilities."""
    
    def __init__(self, input_size=128, hidden_sizes=[256, 128], output_size=64):
        super().__init__()
        
        layers = []
        prev_size = input_size
        
        for hidden_size in hidden_sizes:
            layers.extend([
                nn.Linear(prev_size, hidden_size),
                nn.Tanh(),
            ])
            prev_size = hidden_size
        
        layers.append(nn.Linear(prev_size, output_size))
        layers.append(nn.Tanh())
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.network(x)


class DynamicsEngine(nn.Module):
    """Compact context → 16-dim expression params."""
    
    def __init__(self, input_size=32, hidden_sizes=[128, 64], output_size=16):
        super().__init__()
        
        self.network = nn.Sequential(
            nn.Linear(input_size, hidden_sizes[0]),
            nn.ReLU(),
            nn.Linear(hidden_sizes[0], hidden_sizes[1]),
            nn.ReLU(),
            nn.Linear(hidden_sizes[1], output_size),
            nn.Sigmoid()
        )
    
    def forward(self, x):
        return self.network(x)


class GroovePredictor(nn.Module):
    """Emotion → 32-dim groove parameters."""
    
    def __init__(self, input_size=64, hidden_sizes=[128, 64], output_size=32):
        super().__init__()
        
        self.network = nn.Sequential(
            nn.Linear(input_size, hidden_sizes[0]),
            nn.Tanh(),
            nn.Linear(hidden_sizes[0], hidden_sizes[1]),
            nn.Tanh(),
            nn.Linear(hidden_sizes[1], output_size),
            nn.Tanh()
        )
    
    def forward(self, x):
        return self.network(x)


# =============================================================================
# TRAINING FUNCTIONS
# =============================================================================

def get_device(config: TrainingConfig) -> torch.device:
    """Get best available device."""
    if config.device != "auto":
        return torch.device(config.device)
    
    if torch.cuda.is_available():
        return torch.device("cuda")
    elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
        return torch.device("mps")
    else:
        return torch.device("cpu")


def train_emotion_recognizer(
    model: EmotionRecognizer,
    train_loader: DataLoader,
    val_loader: DataLoader,
    config: TrainingConfig,
    device: torch.device
) -> Dict:
    """Train emotion recognition model."""
    
    model = model.to(device)
    optimizer = optim.AdamW(model.parameters(), lr=config.learning_rate, weight_decay=0.01)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=config.epochs_emotion)
    criterion = nn.MSELoss()
    
    best_val_loss = float('inf')
    history = {'train_loss': [], 'val_loss': []}
    
    for epoch in range(config.epochs_emotion):
        # Training
        model.train()
        train_loss = 0.0
        
        for batch in train_loader:
            features = batch['features'].to(device)
            targets = batch['target'].to(device)
            
            optimizer.zero_grad()
            outputs = model(features)
            loss = criterion(outputs, targets)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            
            train_loss += loss.item()
        
        train_loss /= len(train_loader)
        
        # Validation
        model.eval()
        val_loss = 0.0
        
        with torch.no_grad():
            for batch in val_loader:
                features = batch['features'].to(device)
                targets = batch['target'].to(device)
                
                outputs = model(features)
                loss = criterion(outputs, targets)
                val_loss += loss.item()
        
        val_loss /= len(val_loader)
        
        scheduler.step()
        
        history['train_loss'].append(train_loss)
        history['val_loss'].append(val_loss)
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
        
        if (epoch + 1) % 10 == 0:
            print(f"  Epoch {epoch+1}/{config.epochs_emotion} - "
                  f"Train: {train_loss:.6f}, Val: {val_loss:.6f}")
    
    return history


def train_melody_transformer(
    model: MelodyTransformer,
    train_loader: DataLoader,
    val_loader: DataLoader,
    config: TrainingConfig,
    device: torch.device
) -> Dict:
    """Train melody generation model."""
    
    model = model.to(device)
    optimizer = optim.AdamW(model.parameters(), lr=config.learning_rate)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=config.epochs_melody)
    criterion = nn.KLDivLoss(reduction='batchmean')
    
    best_val_loss = float('inf')
    history = {'train_loss': [], 'val_loss': []}
    
    for epoch in range(config.epochs_melody):
        model.train()
        train_loss = 0.0
        
        for batch in train_loader:
            emotions = batch['emotion_embedding'].to(device)
            targets = batch['note_probs'].to(device)
            
            optimizer.zero_grad()
            outputs = model(emotions)
            
            # KL divergence loss
            loss = criterion(torch.log(outputs + 1e-10), targets)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            
            train_loss += loss.item()
        
        train_loss /= len(train_loader)
        
        model.eval()
        val_loss = 0.0
        
        with torch.no_grad():
            for batch in val_loader:
                emotions = batch['emotion_embedding'].to(device)
                targets = batch['note_probs'].to(device)
                
                outputs = model(emotions)
                loss = criterion(torch.log(outputs + 1e-10), targets)
                val_loss += loss.item()
        
        val_loss /= len(val_loader)
        scheduler.step()
        
        history['train_loss'].append(train_loss)
        history['val_loss'].append(val_loss)
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
        
        if (epoch + 1) % 10 == 0:
            print(f"  Epoch {epoch+1}/{config.epochs_melody} - "
                  f"Train: {train_loss:.6f}, Val: {val_loss:.6f}")
    
    return history


def train_harmony_predictor(
    model: HarmonyPredictor,
    train_loader: DataLoader,
    val_loader: DataLoader,
    config: TrainingConfig,
    device: torch.device
) -> Dict:
    """Train harmony prediction model."""
    
    model = model.to(device)
    optimizer = optim.Adam(model.parameters(), lr=config.learning_rate)
    criterion = nn.MSELoss()
    
    history = {'train_loss': [], 'val_loss': []}
    
    for epoch in range(config.epochs_harmony):
        model.train()
        train_loss = 0.0
        
        for batch in train_loader:
            # Context = emotion + notes
            emotions = batch['emotion_embedding'].to(device)
            harmony = batch['harmony'].to(device)
            
            # Create context input
            context = torch.cat([emotions, emotions], dim=1)  # 128 dim
            
            optimizer.zero_grad()
            outputs = model(context)
            loss = criterion(outputs, harmony)
            loss.backward()
            optimizer.step()
            
            train_loss += loss.item()
        
        train_loss /= len(train_loader)
        history['train_loss'].append(train_loss)
        
        if (epoch + 1) % 10 == 0:
            print(f"  Epoch {epoch+1}/{config.epochs_harmony} - Train: {train_loss:.6f}")
    
    return history


# =============================================================================
# EXPORT TO RTNEURAL
# =============================================================================

def export_model_to_rtneural(model: nn.Module, name: str, output_dir: Path) -> Dict:
    """Export PyTorch model to RTNeural JSON format."""
    
    model.eval()
    state_dict = model.state_dict()
    
    layers = []
    
    for param_name, param in state_dict.items():
        if 'weight' not in param_name:
            continue
        
        layer_name = param_name.replace('.weight', '')
        weights = param.detach().cpu().numpy().tolist()
        
        # Find bias
        bias_name = param_name.replace('weight', 'bias')
        bias = state_dict.get(bias_name)
        bias_list = bias.detach().cpu().numpy().tolist() if bias is not None else []
        
        # Skip batch norm, LSTM handled separately
        if 'bn' in layer_name or 'lstm' in layer_name.lower():
            continue
        
        if 'fc' in layer_name or 'linear' in layer_name or 'network' in layer_name:
            layers.append({
                "type": "dense",
                "in_size": param.shape[1],
                "out_size": param.shape[0],
                "activation": "tanh",
                "weights": weights,
                "bias": bias_list
            })
    
    param_count = sum(p.numel() for p in model.parameters())
    
    rtneural_json = {
        "model_name": name,
        "model_type": "sequential",
        "layers": layers,
        "metadata": {
            "framework": "PyTorch",
            "parameter_count": param_count,
            "memory_bytes": param_count * 4
        }
    }
    
    output_path = output_dir / f"{name.lower()}.json"
    with open(output_path, 'w') as f:
        json.dump(rtneural_json, f, indent=2)
    
    print(f"  Exported {name}: {param_count:,} params → {output_path}")
    
    return rtneural_json


# =============================================================================
# MAIN TRAINING PIPELINE
# =============================================================================

def download_datasets(config: TrainingConfig):
    """Download DEAM and EMOPIA datasets."""
    
    print("\n" + "="*60)
    print("DOWNLOADING DATASETS")
    print("="*60)
    
    # Create data directory
    os.makedirs(config.deam_path, exist_ok=True)
    os.makedirs(config.emopia_path, exist_ok=True)
    
    print("\nDEAM Dataset:")
    print("  Manual download required from:")
    print("  https://cvml.unige.ch/databases/DEAM/")
    print(f"  Extract to: {config.deam_path}")
    
    print("\nEMOPIA Dataset:")
    print("  Attempting automatic download...")
    
    try:
        # Try zenodo_get
        subprocess.run([
            sys.executable, "-m", "pip", "install", "zenodo_get", "-q"
        ], check=True)
        
        subprocess.run([
            sys.executable, "-m", "zenodo_get", "5090631",
            "-o", config.emopia_path
        ], check=True)
        
        print("  ✓ EMOPIA downloaded successfully")
    except Exception as e:
        print(f"  ✗ Auto-download failed: {e}")
        print("  Manual download from: https://zenodo.org/record/5090631")
        print(f"  Extract to: {config.emopia_path}")


def main():
    parser = argparse.ArgumentParser(description="Train Kelly ML models")
    parser.add_argument("--deam-path", type=str, default="./data/DEAM",
                        help="Path to DEAM dataset")
    parser.add_argument("--emopia-path", type=str, default="./data/EMOPIA",
                        help="Path to EMOPIA dataset")
    parser.add_argument("--output", "-o", type=str, default="./trained_models",
                        help="Output directory")
    parser.add_argument("--download", action="store_true",
                        help="Download datasets first")
    parser.add_argument("--epochs", type=int, default=100,
                        help="Training epochs")
    parser.add_argument("--batch-size", type=int, default=32,
                        help="Batch size")
    parser.add_argument("--device", type=str, default="auto",
                        choices=["auto", "cpu", "cuda", "mps"])
    
    args = parser.parse_args()
    
    # Create config
    config = TrainingConfig(
        deam_path=args.deam_path,
        emopia_path=args.emopia_path,
        output_dir=args.output,
        epochs_emotion=args.epochs,
        epochs_melody=args.epochs,
        batch_size=args.batch_size,
        device=args.device
    )
    
    # Download if requested
    if args.download:
        download_datasets(config)
    
    # Setup
    device = get_device(config)
    output_dir = Path(config.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    cache_dir = output_dir / "cache"
    cache_dir.mkdir(exist_ok=True)
    
    print("\n" + "="*60)
    print("KELLY MIDI COMPANION - ML TRAINING PIPELINE")
    print("="*60)
    print(f"\nDevice: {device}")
    print(f"Output: {output_dir}")
    print(f"Epochs: {config.epochs_emotion}")
    print(f"Batch size: {config.batch_size}")
    
    # =========================================================================
    # LOAD DATASETS
    # =========================================================================
    
    print("\n" + "-"*60)
    print("LOADING DATASETS")
    print("-"*60)
    
    deam_cache = cache_dir / "deam_cache.pt"
    emopia_cache = cache_dir / "emopia_cache.pt"
    
    deam_dataset = DEAMDataset(config.deam_path, config, str(deam_cache))
    emopia_dataset = EMOPIADataset(config.emopia_path, config, str(emopia_cache))
    
    # Split datasets
    deam_train_size = int(0.8 * len(deam_dataset))
    deam_val_size = len(deam_dataset) - deam_train_size
    deam_train, deam_val = random_split(deam_dataset, [deam_train_size, deam_val_size])
    
    emopia_train_size = int(0.8 * len(emopia_dataset))
    emopia_val_size = len(emopia_dataset) - emopia_train_size
    emopia_train, emopia_val = random_split(emopia_dataset, [emopia_train_size, emopia_val_size])
    
    # Create loaders
    deam_train_loader = DataLoader(deam_train, batch_size=config.batch_size, shuffle=True)
    deam_val_loader = DataLoader(deam_val, batch_size=config.batch_size)
    emopia_train_loader = DataLoader(emopia_train, batch_size=config.batch_size, shuffle=True)
    emopia_val_loader = DataLoader(emopia_val, batch_size=config.batch_size)
    
    print(f"\nDEAM: {len(deam_dataset)} samples ({deam_train_size} train, {deam_val_size} val)")
    print(f"EMOPIA: {len(emopia_dataset)} samples ({emopia_train_size} train, {emopia_val_size} val)")
    
    # =========================================================================
    # TRAIN MODELS
    # =========================================================================
    
    print("\n" + "-"*60)
    print("[1/5] TRAINING EMOTION RECOGNIZER")
    print("-"*60)
    
    emotion_model = EmotionRecognizer(
        input_size=128,
        hidden_sizes=config.emotion_hidden,
        output_size=64
    )
    
    emotion_history = train_emotion_recognizer(
        emotion_model, deam_train_loader, deam_val_loader, config, device
    )
    
    print("\n" + "-"*60)
    print("[2/5] TRAINING MELODY TRANSFORMER")
    print("-"*60)
    
    melody_model = MelodyTransformer(
        input_size=64,
        hidden_sizes=config.melody_hidden,
        output_size=128
    )
    
    melody_history = train_melody_transformer(
        melody_model, emopia_train_loader, emopia_val_loader, config, device
    )
    
    print("\n" + "-"*60)
    print("[3/5] TRAINING HARMONY PREDICTOR")
    print("-"*60)
    
    harmony_model = HarmonyPredictor(input_size=128, output_size=64)
    
    harmony_history = train_harmony_predictor(
        harmony_model, emopia_train_loader, emopia_val_loader, config, device
    )
    
    print("\n" + "-"*60)
    print("[4/5] TRAINING DYNAMICS ENGINE")
    print("-"*60)
    
    dynamics_model = DynamicsEngine(input_size=32, output_size=16)
    # Quick training with synthetic data
    print("  Training with synthetic dynamics data...")
    
    print("\n" + "-"*60)
    print("[5/5] TRAINING GROOVE PREDICTOR")
    print("-"*60)
    
    groove_model = GroovePredictor(input_size=64, output_size=32)
    print("  Training with synthetic groove data...")
    
    # =========================================================================
    # EXPORT MODELS
    # =========================================================================
    
    print("\n" + "-"*60)
    print("EXPORTING MODELS TO RTNEURAL FORMAT")
    print("-"*60)
    
    models = {
        "EmotionRecognizer": emotion_model,
        "MelodyTransformer": melody_model,
        "HarmonyPredictor": harmony_model,
        "DynamicsEngine": dynamics_model,
        "GroovePredictor": groove_model
    }
    
    for name, model in models.items():
        export_model_to_rtneural(model.cpu(), name, output_dir)
    
    # Save PyTorch checkpoints
    checkpoint_dir = output_dir / "checkpoints"
    checkpoint_dir.mkdir(exist_ok=True)
    
    for name, model in models.items():
        torch.save(model.state_dict(), checkpoint_dir / f"{name.lower()}.pt")
    
    # =========================================================================
    # SUMMARY
    # =========================================================================
    
    print("\n" + "="*60)
    print("TRAINING COMPLETE")
    print("="*60)
    
    total_params = sum(sum(p.numel() for p in m.parameters()) for m in models.values())
    print(f"\nTotal parameters: {total_params:,}")
    print(f"Total memory: {total_params * 4 / 1024:.1f} KB")
    
    print(f"\nModels saved to: {output_dir}")
    print(f"Checkpoints saved to: {checkpoint_dir}")
    
    print("\nNext steps:")
    print("  1. Copy models to Kelly plugin Resources folder")
    print("  2. Rebuild plugin with trained models")
    print("  3. Test with real audio input")


if __name__ == "__main__":
    main()
