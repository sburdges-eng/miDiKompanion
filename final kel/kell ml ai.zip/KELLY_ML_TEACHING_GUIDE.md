# Kelly MIDI Companion - ML Teaching Guide

**Complete Implementation Reference**

---

## 1. Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    ML PIPELINE FLOW                          │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  [Audio Input] ─────────────────────────────────────────────┐
│       │                                                      │
│       ▼                                                      │
│  ┌────────────────────┐                                     │
│  │ MLFeatureExtractor │  128-dim mel-like features         │
│  └─────────┬──────────┘                                     │
│            │                                                 │
│            ▼                                                 │
│  ┌────────────────────┐    Lock-Free                       │
│  │ LockFreeRingBuffer │◄───────────────────────────────────┤
│  └─────────┬──────────┘    Request Queue                   │
│            │                                                 │
│            ▼                                                 │
│  ┌────────────────────┐                                     │
│  │ InferenceThread    │  Background (non-realtime)         │
│  │ ├─ RTNeural        │  ~2ms inference                    │
│  │ ├─ ONNX Runtime    │  Transformer MIDI                  │
│  │ └─ DDSP            │  Neural synthesis                  │
│  └─────────┬──────────┘                                     │
│            │                                                 │
│            ▼                                                 │
│  ┌────────────────────┐    Lock-Free                       │
│  │ LockFreeRingBuffer │◄───────────────────────────────────┤
│  └─────────┬──────────┘    Result Queue                    │
│            │                                                 │
│            ▼                                                 │
│  ┌────────────────────┐                                     │
│  │ EmotionFusion      │  Blend rule-based + neural         │
│  └─────────┬──────────┘                                     │
│            │                                                 │
│            ▼                                                 │
│  ┌────────────────────┐                                     │
│  │ MidiGenerator      │  Emotion-conditioned output        │
│  └────────────────────┘                                     │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Lock-Free Ring Buffer

```cpp
// src/ml/LockFreeRingBuffer.h
#pragma once
#include <atomic>
#include <array>
#include <optional>

namespace kelly {
namespace ml {

template<typename T, size_t Capacity>
class LockFreeRingBuffer {
public:
    bool push(const T& item) {
        size_t currentWrite = writePos_.load(std::memory_order_relaxed);
        size_t nextWrite = (currentWrite + 1) % Capacity;
        
        if (nextWrite == readPos_.load(std::memory_order_acquire)) {
            return false; // Buffer full
        }
        
        buffer_[currentWrite] = item;
        writePos_.store(nextWrite, std::memory_order_release);
        return true;
    }
    
    std::optional<T> pop() {
        size_t currentRead = readPos_.load(std::memory_order_relaxed);
        
        if (currentRead == writePos_.load(std::memory_order_acquire)) {
            return std::nullopt; // Buffer empty
        }
        
        T item = buffer_[currentRead];
        readPos_.store((currentRead + 1) % Capacity, std::memory_order_release);
        return item;
    }
    
    bool empty() const {
        return readPos_.load(std::memory_order_acquire) == 
               writePos_.load(std::memory_order_acquire);
    }
    
    size_t size() const {
        size_t w = writePos_.load(std::memory_order_acquire);
        size_t r = readPos_.load(std::memory_order_acquire);
        return (w >= r) ? (w - r) : (Capacity - r + w);
    }

private:
    std::array<T, Capacity> buffer_;
    std::atomic<size_t> readPos_{0};
    std::atomic<size_t> writePos_{0};
};

} // namespace ml
} // namespace kelly
```

---

## 3. Feature Extractor

```cpp
// src/ml/MLFeatureExtractor.h
#pragma once
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_dsp/juce_dsp.h>
#include <array>
#include <cmath>

namespace kelly {
namespace ml {

constexpr size_t FEATURE_DIM = 128;
constexpr size_t FFT_SIZE = 2048;
constexpr size_t HOP_SIZE = 512;
constexpr size_t NUM_MEL_BANDS = 40;
constexpr size_t NUM_MFCC = 13;

class MLFeatureExtractor {
public:
    MLFeatureExtractor() {
        fft_ = std::make_unique<juce::dsp::FFT>(11); // 2^11 = 2048
        initMelFilterbank();
    }
    
    std::array<float, FEATURE_DIM> extractFeatures(
        const juce::AudioBuffer<float>& buffer
    ) {
        std::array<float, FEATURE_DIM> features{};
        const float* data = buffer.getReadPointer(0);
        int numSamples = buffer.getNumSamples();
        
        // 1. Time-domain features [0-15]
        float rms = computeRMS(data, numSamples);
        float zcr = computeZCR(data, numSamples);
        float crest = computeCrestFactor(data, numSamples);
        
        features[0] = rms;
        features[1] = zcr;
        features[2] = crest;
        features[3] = computeEnergy(data, numSamples);
        
        // Temporal envelope (4 segments)
        for (int i = 0; i < 4; ++i) {
            int start = i * numSamples / 4;
            int len = numSamples / 4;
            features[4 + i] = computeRMS(data + start, len);
        }
        
        // Attack/decay characteristics
        features[8] = computeAttackTime(data, numSamples);
        features[9] = computeDecayTime(data, numSamples);
        
        // Padding
        for (int i = 10; i < 16; ++i) features[i] = 0.0f;
        
        // 2. Spectral features [16-47]
        computeFFT(data, numSamples);
        
        features[16] = computeSpectralCentroid();
        features[17] = computeSpectralSpread();
        features[18] = computeSpectralRolloff(0.85f);
        features[19] = computeSpectralFlux();
        features[20] = computeSpectralFlatness();
        features[21] = computeSpectralCrest();
        features[22] = computeSpectralSlope();
        features[23] = computeSpectralEntropy();
        
        // Spectral band energies (8 bands)
        computeBandEnergies(&features[24]);
        
        // 3. MFCCs [48-63]
        computeMelSpectrum();
        computeMFCCs(&features[48], NUM_MFCC);
        
        // Delta MFCCs (placeholder)
        for (int i = 61; i < 64; ++i) features[i] = 0.0f;
        
        // 4. Mel band energies [64-103]
        for (size_t i = 0; i < NUM_MEL_BANDS; ++i) {
            features[64 + i] = melSpectrum_[i];
        }
        
        // 5. Harmonic features [104-119]
        features[104] = computeF0();
        features[105] = computeHNR();
        features[106] = computeInharmonicity();
        
        // Harmonic amplitudes (first 8)
        computeHarmonicAmplitudes(&features[107], 8);
        
        // Padding
        for (int i = 115; i < 120; ++i) features[i] = 0.0f;
        
        // 6. Statistical moments [120-127]
        features[120] = computeSkewness(data, numSamples);
        features[121] = computeKurtosis(data, numSamples);
        features[122] = spectralSkewness_;
        features[123] = spectralKurtosis_;
        
        // Normalize features
        for (size_t i = 0; i < FEATURE_DIM; ++i) {
            features[i] = std::tanh(features[i]); // Soft clamp to [-1, 1]
        }
        
        return features;
    }

private:
    std::unique_ptr<juce::dsp::FFT> fft_;
    std::array<float, FFT_SIZE> fftBuffer_{};
    std::array<float, FFT_SIZE / 2> magnitude_{};
    std::array<float, FFT_SIZE / 2> prevMagnitude_{};
    std::array<float, NUM_MEL_BANDS> melSpectrum_{};
    std::array<std::array<float, FFT_SIZE / 2>, NUM_MEL_BANDS> melFilterbank_{};
    float spectralSkewness_ = 0.0f;
    float spectralKurtosis_ = 0.0f;
    
    void initMelFilterbank() {
        float fMin = 20.0f;
        float fMax = 8000.0f;
        float melMin = 2595.0f * std::log10(1.0f + fMin / 700.0f);
        float melMax = 2595.0f * std::log10(1.0f + fMax / 700.0f);
        
        std::array<float, NUM_MEL_BANDS + 2> melPoints;
        for (size_t i = 0; i < NUM_MEL_BANDS + 2; ++i) {
            float mel = melMin + (melMax - melMin) * i / (NUM_MEL_BANDS + 1);
            melPoints[i] = 700.0f * (std::pow(10.0f, mel / 2595.0f) - 1.0f);
        }
        
        float binWidth = 44100.0f / FFT_SIZE;
        for (size_t m = 0; m < NUM_MEL_BANDS; ++m) {
            for (size_t k = 0; k < FFT_SIZE / 2; ++k) {
                float freq = k * binWidth;
                float weight = 0.0f;
                
                if (freq >= melPoints[m] && freq <= melPoints[m + 1]) {
                    weight = (freq - melPoints[m]) / (melPoints[m + 1] - melPoints[m]);
                } else if (freq > melPoints[m + 1] && freq <= melPoints[m + 2]) {
                    weight = (melPoints[m + 2] - freq) / (melPoints[m + 2] - melPoints[m + 1]);
                }
                
                melFilterbank_[m][k] = weight;
            }
        }
    }
    
    float computeRMS(const float* data, int n) {
        float sum = 0.0f;
        for (int i = 0; i < n; ++i) sum += data[i] * data[i];
        return std::sqrt(sum / n);
    }
    
    float computeZCR(const float* data, int n) {
        int crossings = 0;
        for (int i = 1; i < n; ++i) {
            if ((data[i] >= 0) != (data[i-1] >= 0)) crossings++;
        }
        return static_cast<float>(crossings) / n;
    }
    
    float computeCrestFactor(const float* data, int n) {
        float peak = 0.0f;
        float rms = computeRMS(data, n);
        for (int i = 0; i < n; ++i) {
            peak = std::max(peak, std::abs(data[i]));
        }
        return (rms > 1e-6f) ? peak / rms : 0.0f;
    }
    
    float computeEnergy(const float* data, int n) {
        float sum = 0.0f;
        for (int i = 0; i < n; ++i) sum += data[i] * data[i];
        return sum;
    }
    
    float computeAttackTime(const float* data, int n) {
        float maxAbs = 0.0f;
        int maxIdx = 0;
        for (int i = 0; i < n; ++i) {
            if (std::abs(data[i]) > maxAbs) {
                maxAbs = std::abs(data[i]);
                maxIdx = i;
            }
        }
        return static_cast<float>(maxIdx) / n;
    }
    
    float computeDecayTime(const float* data, int n) {
        return 1.0f - computeAttackTime(data, n);
    }
    
    void computeFFT(const float* data, int n) {
        prevMagnitude_ = magnitude_;
        
        std::fill(fftBuffer_.begin(), fftBuffer_.end(), 0.0f);
        int copyLen = std::min(n, static_cast<int>(FFT_SIZE));
        
        // Apply Hann window
        for (int i = 0; i < copyLen; ++i) {
            float window = 0.5f * (1.0f - std::cos(2.0f * M_PI * i / (copyLen - 1)));
            fftBuffer_[i] = data[i] * window;
        }
        
        fft_->performRealOnlyForwardTransform(fftBuffer_.data());
        
        for (size_t i = 0; i < FFT_SIZE / 2; ++i) {
            float re = fftBuffer_[i * 2];
            float im = fftBuffer_[i * 2 + 1];
            magnitude_[i] = std::sqrt(re * re + im * im);
        }
    }
    
    float computeSpectralCentroid() {
        float weightedSum = 0.0f, sum = 0.0f;
        for (size_t i = 0; i < FFT_SIZE / 2; ++i) {
            weightedSum += i * magnitude_[i];
            sum += magnitude_[i];
        }
        return (sum > 1e-6f) ? weightedSum / sum / (FFT_SIZE / 2) : 0.5f;
    }
    
    float computeSpectralSpread() {
        float centroid = computeSpectralCentroid() * (FFT_SIZE / 2);
        float weightedVar = 0.0f, sum = 0.0f;
        for (size_t i = 0; i < FFT_SIZE / 2; ++i) {
            float diff = i - centroid;
            weightedVar += diff * diff * magnitude_[i];
            sum += magnitude_[i];
        }
        return (sum > 1e-6f) ? std::sqrt(weightedVar / sum) / (FFT_SIZE / 2) : 0.0f;
    }
    
    float computeSpectralRolloff(float threshold) {
        float total = 0.0f;
        for (size_t i = 0; i < FFT_SIZE / 2; ++i) total += magnitude_[i];
        
        float cumSum = 0.0f;
        float target = threshold * total;
        for (size_t i = 0; i < FFT_SIZE / 2; ++i) {
            cumSum += magnitude_[i];
            if (cumSum >= target) {
                return static_cast<float>(i) / (FFT_SIZE / 2);
            }
        }
        return 1.0f;
    }
    
    float computeSpectralFlux() {
        float flux = 0.0f;
        for (size_t i = 0; i < FFT_SIZE / 2; ++i) {
            float diff = magnitude_[i] - prevMagnitude_[i];
            flux += diff * diff;
        }
        return std::sqrt(flux / (FFT_SIZE / 2));
    }
    
    float computeSpectralFlatness() {
        float logSum = 0.0f, sum = 0.0f;
        int count = 0;
        for (size_t i = 1; i < FFT_SIZE / 2; ++i) {
            if (magnitude_[i] > 1e-10f) {
                logSum += std::log(magnitude_[i]);
                sum += magnitude_[i];
                count++;
            }
        }
        if (count == 0 || sum < 1e-10f) return 0.0f;
        float geoMean = std::exp(logSum / count);
        float ariMean = sum / count;
        return geoMean / ariMean;
    }
    
    float computeSpectralCrest() {
        float maxMag = 0.0f, sum = 0.0f;
        for (size_t i = 0; i < FFT_SIZE / 2; ++i) {
            maxMag = std::max(maxMag, magnitude_[i]);
            sum += magnitude_[i];
        }
        return (sum > 1e-6f) ? maxMag / (sum / (FFT_SIZE / 2)) : 0.0f;
    }
    
    float computeSpectralSlope() {
        float sumX = 0.0f, sumY = 0.0f, sumXY = 0.0f, sumX2 = 0.0f;
        int n = FFT_SIZE / 2;
        for (int i = 0; i < n; ++i) {
            sumX += i;
            sumY += magnitude_[i];
            sumXY += i * magnitude_[i];
            sumX2 += i * i;
        }
        float denom = n * sumX2 - sumX * sumX;
        return (std::abs(denom) > 1e-6f) ? (n * sumXY - sumX * sumY) / denom : 0.0f;
    }
    
    float computeSpectralEntropy() {
        float sum = 0.0f;
        for (size_t i = 0; i < FFT_SIZE / 2; ++i) sum += magnitude_[i];
        if (sum < 1e-6f) return 0.0f;
        
        float entropy = 0.0f;
        for (size_t i = 0; i < FFT_SIZE / 2; ++i) {
            float p = magnitude_[i] / sum;
            if (p > 1e-10f) entropy -= p * std::log2(p);
        }
        return entropy / std::log2(static_cast<float>(FFT_SIZE / 2));
    }
    
    void computeBandEnergies(float* output) {
        const int bandBounds[] = {0, 64, 128, 256, 384, 512, 768, 1024};
        for (int b = 0; b < 8; ++b) {
            float energy = 0.0f;
            int start = bandBounds[b];
            int end = (b < 7) ? bandBounds[b + 1] : FFT_SIZE / 2;
            for (int i = start; i < end && i < FFT_SIZE / 2; ++i) {
                energy += magnitude_[i] * magnitude_[i];
            }
            output[b] = std::sqrt(energy / (end - start));
        }
    }
    
    void computeMelSpectrum() {
        for (size_t m = 0; m < NUM_MEL_BANDS; ++m) {
            float sum = 0.0f;
            for (size_t k = 0; k < FFT_SIZE / 2; ++k) {
                sum += melFilterbank_[m][k] * magnitude_[k];
            }
            melSpectrum_[m] = std::log(sum + 1e-10f);
        }
    }
    
    void computeMFCCs(float* output, size_t numCoeffs) {
        for (size_t i = 0; i < numCoeffs; ++i) {
            float sum = 0.0f;
            for (size_t m = 0; m < NUM_MEL_BANDS; ++m) {
                sum += melSpectrum_[m] * std::cos(M_PI * i * (m + 0.5f) / NUM_MEL_BANDS);
            }
            output[i] = sum;
        }
    }
    
    float computeF0() {
        // Simple autocorrelation-based pitch detection
        return 0.5f; // Placeholder
    }
    
    float computeHNR() {
        return 0.5f; // Placeholder
    }
    
    float computeInharmonicity() {
        return 0.0f; // Placeholder
    }
    
    void computeHarmonicAmplitudes(float* output, int n) {
        for (int i = 0; i < n; ++i) output[i] = 0.0f;
    }
    
    float computeSkewness(const float* data, int n) {
        float mean = 0.0f;
        for (int i = 0; i < n; ++i) mean += data[i];
        mean /= n;
        
        float m2 = 0.0f, m3 = 0.0f;
        for (int i = 0; i < n; ++i) {
            float d = data[i] - mean;
            m2 += d * d;
            m3 += d * d * d;
        }
        m2 /= n;
        m3 /= n;
        
        float sigma = std::sqrt(m2);
        return (sigma > 1e-6f) ? m3 / (sigma * sigma * sigma) : 0.0f;
    }
    
    float computeKurtosis(const float* data, int n) {
        float mean = 0.0f;
        for (int i = 0; i < n; ++i) mean += data[i];
        mean /= n;
        
        float m2 = 0.0f, m4 = 0.0f;
        for (int i = 0; i < n; ++i) {
            float d = data[i] - mean;
            m2 += d * d;
            m4 += d * d * d * d;
        }
        m2 /= n;
        m4 /= n;
        
        return (m2 > 1e-6f) ? m4 / (m2 * m2) - 3.0f : 0.0f;
    }
};

} // namespace ml
} // namespace kelly
```

---

## 4. RTNeural Processor

```cpp
// src/ml/RTNeuralProcessor.h
#pragma once
#include <RTNeural/RTNeural.h>
#include <juce_core/juce_core.h>
#include <array>
#include <fstream>

namespace kelly {
namespace ml {

constexpr size_t INPUT_SIZE = 128;
constexpr size_t HIDDEN_SIZE = 256;
constexpr size_t OUTPUT_SIZE = 64;

// Compile-time optimized model architecture
using EmotionModel = RTNeural::ModelT<float, INPUT_SIZE, OUTPUT_SIZE,
    RTNeural::DenseT<float, INPUT_SIZE, HIDDEN_SIZE>,
    RTNeural::TanhActivationT<float, HIDDEN_SIZE>,
    RTNeural::DenseT<float, HIDDEN_SIZE, HIDDEN_SIZE>,
    RTNeural::TanhActivationT<float, HIDDEN_SIZE>,
    RTNeural::DenseT<float, HIDDEN_SIZE, OUTPUT_SIZE>,
    RTNeural::TanhActivationT<float, OUTPUT_SIZE>
>;

class RTNeuralProcessor {
public:
    RTNeuralProcessor() = default;
    
    bool loadModel(const juce::File& modelFile) {
        if (!modelFile.existsAsFile()) {
            juce::Logger::writeToLog("Model file not found: " + modelFile.getFullPathName());
            return false;
        }
        
        try {
            std::ifstream jsonStream(modelFile.getFullPathName().toStdString());
            nlohmann::json modelJson;
            jsonStream >> modelJson;
            
            model_.parseJson(modelJson);
            model_.reset();
            
            isLoaded_ = true;
            juce::Logger::writeToLog("RTNeural model loaded successfully");
            return true;
        }
        catch (const std::exception& e) {
            juce::Logger::writeToLog("Failed to load model: " + juce::String(e.what()));
            return false;
        }
    }
    
    std::array<float, OUTPUT_SIZE> process(const std::array<float, INPUT_SIZE>& input) {
        if (!isLoaded_) {
            return std::array<float, OUTPUT_SIZE>{};
        }
        
        alignas(16) std::array<float, INPUT_SIZE> alignedInput = input;
        alignas(16) std::array<float, OUTPUT_SIZE> output{};
        
        // RTNeural forward pass (sample-by-sample for real-time)
        auto* result = model_.forward(alignedInput.data());
        std::copy(result, result + OUTPUT_SIZE, output.begin());
        
        return output;
    }
    
    void reset() {
        if (isLoaded_) {
            model_.reset();
        }
    }
    
    bool isLoaded() const { return isLoaded_; }

private:
    EmotionModel model_;
    bool isLoaded_ = false;
};

} // namespace ml
} // namespace kelly
```

---

## 5. Inference Thread Manager

```cpp
// src/ml/InferenceThreadManager.h
#pragma once
#include "LockFreeRingBuffer.h"
#include "RTNeuralProcessor.h"
#include "MLFeatureExtractor.h"
#include <juce_core/juce_core.h>
#include <thread>
#include <atomic>

namespace kelly {
namespace ml {

struct InferenceRequest {
    std::array<float, INPUT_SIZE> features;
    uint64_t timestamp = 0;
};

struct InferenceResult {
    std::array<float, OUTPUT_SIZE> emotionVector;
    uint64_t timestamp = 0;
    float inferenceTimeMs = 0.0f;
};

class InferenceThreadManager {
public:
    InferenceThreadManager() = default;
    
    ~InferenceThreadManager() {
        stop();
    }
    
    bool start(const juce::File& modelFile) {
        if (!processor_.loadModel(modelFile)) {
            return false;
        }
        
        running_.store(true, std::memory_order_release);
        inferenceThread_ = std::thread(&InferenceThreadManager::inferenceLoop, this);
        
        return true;
    }
    
    void stop() {
        running_.store(false, std::memory_order_release);
        if (inferenceThread_.joinable()) {
            inferenceThread_.join();
        }
    }
    
    // Called from audio thread (lock-free)
    bool submitRequest(const InferenceRequest& request) {
        return requestQueue_.push(request);
    }
    
    // Called from audio thread (lock-free)
    bool getResult(InferenceResult& result) {
        auto opt = resultQueue_.pop();
        if (opt) {
            result = *opt;
            return true;
        }
        return false;
    }
    
    float getAverageLatencyMs() const {
        return averageLatencyMs_.load(std::memory_order_acquire);
    }
    
    bool isRunning() const {
        return running_.load(std::memory_order_acquire);
    }

private:
    void inferenceLoop() {
        while (running_.load(std::memory_order_acquire)) {
            auto request = requestQueue_.pop();
            
            if (request) {
                auto startTime = std::chrono::high_resolution_clock::now();
                
                // Run inference
                auto emotionVector = processor_.process(request->features);
                
                auto endTime = std::chrono::high_resolution_clock::now();
                float latencyMs = std::chrono::duration<float, std::milli>(
                    endTime - startTime).count();
                
                // Update average latency (exponential moving average)
                float currentAvg = averageLatencyMs_.load(std::memory_order_relaxed);
                averageLatencyMs_.store(
                    currentAvg * 0.9f + latencyMs * 0.1f,
                    std::memory_order_release
                );
                
                // Push result
                InferenceResult result;
                result.emotionVector = emotionVector;
                result.timestamp = request->timestamp;
                result.inferenceTimeMs = latencyMs;
                
                resultQueue_.push(result);
            }
            else {
                // No work, sleep briefly
                std::this_thread::sleep_for(std::chrono::microseconds(100));
            }
        }
    }
    
    RTNeuralProcessor processor_;
    LockFreeRingBuffer<InferenceRequest, 64> requestQueue_;
    LockFreeRingBuffer<InferenceResult, 64> resultQueue_;
    
    std::thread inferenceThread_;
    std::atomic<bool> running_{false};
    std::atomic<float> averageLatencyMs_{0.0f};
};

} // namespace ml
} // namespace kelly
```

---

## 6. Emotion Fusion Layer

```cpp
// src/ml/EmotionFusionLayer.h
#pragma once
#include <array>
#include <cmath>
#include <deque>

namespace kelly {
namespace ml {

struct VADCoordinates {
    float valence = 0.0f;   // [-1, +1]
    float arousal = 0.5f;   // [0, 1]
    float dominance = 0.5f; // [0, 1]
    float confidence = 0.0f;
};

class EmotionFusionLayer {
public:
    // Blend rule-based and neural VAD
    VADCoordinates fuse(
        const VADCoordinates& ruleBased,
        const VADCoordinates& neural,
        float neuralWeight = 0.5f
    ) {
        float w = neuralWeight * neural.confidence;
        float rw = 1.0f - w;
        
        VADCoordinates fused;
        fused.valence = rw * ruleBased.valence + w * neural.valence;
        fused.arousal = rw * ruleBased.arousal + w * neural.arousal;
        fused.dominance = rw * ruleBased.dominance + w * neural.dominance;
        fused.confidence = std::max(ruleBased.confidence, neural.confidence);
        
        // Apply temporal smoothing
        return smooth(fused);
    }
    
    // Convert 64-dim emotion vector to VAD
    VADCoordinates vectorToVAD(const std::array<float, 64>& emotionVector) {
        VADCoordinates vad;
        
        // First 32 dims → valence
        float valenceSum = 0.0f;
        for (size_t i = 0; i < 32; ++i) {
            valenceSum += emotionVector[i];
        }
        vad.valence = std::tanh(valenceSum / 32.0f);
        
        // Next 16 dims → arousal
        float arousalSum = 0.0f;
        for (size_t i = 32; i < 48; ++i) {
            arousalSum += emotionVector[i];
        }
        vad.arousal = (std::tanh(arousalSum / 16.0f) + 1.0f) * 0.5f;
        
        // Last 16 dims → dominance
        float dominanceSum = 0.0f;
        for (size_t i = 48; i < 64; ++i) {
            dominanceSum += emotionVector[i];
        }
        vad.dominance = (std::tanh(dominanceSum / 16.0f) + 1.0f) * 0.5f;
        
        // Confidence from vector magnitude
        float mag = 0.0f;
        for (const auto& v : emotionVector) mag += v * v;
        vad.confidence = std::min(1.0f, std::sqrt(mag) / 8.0f);
        
        return vad;
    }
    
    void reset() {
        history_.clear();
    }

private:
    VADCoordinates smooth(const VADCoordinates& input) {
        history_.push_back(input);
        if (history_.size() > smoothingWindow_) {
            history_.pop_front();
        }
        
        VADCoordinates smoothed{};
        float weightSum = 0.0f;
        
        for (size_t i = 0; i < history_.size(); ++i) {
            float weight = static_cast<float>(i + 1);
            smoothed.valence += history_[i].valence * weight;
            smoothed.arousal += history_[i].arousal * weight;
            smoothed.dominance += history_[i].dominance * weight;
            smoothed.confidence += history_[i].confidence * weight;
            weightSum += weight;
        }
        
        smoothed.valence /= weightSum;
        smoothed.arousal /= weightSum;
        smoothed.dominance /= weightSum;
        smoothed.confidence /= weightSum;
        
        return smoothed;
    }
    
    std::deque<VADCoordinates> history_;
    size_t smoothingWindow_ = 8;
};

} // namespace ml
} // namespace kelly
```

---

## 7. Training Script (PyTorch)

```python
#!/usr/bin/env python3
"""
Kelly MIDI Companion - Emotion Model Training
Exports to RTNeural JSON format
"""

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import json
import argparse
from pathlib import Path
import librosa


class EmotionRecognitionModel(nn.Module):
    """Matches RTNeural architecture exactly"""
    
    def __init__(self, input_size=128, hidden_size=256, output_size=64):
        super().__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, output_size)
        self.activation = nn.Tanh()
        
    def forward(self, x):
        x = self.activation(self.fc1(x))
        x = self.activation(self.fc2(x))
        x = self.activation(self.fc3(x))
        return x


class EmotionDataset(Dataset):
    """Dataset for emotion recognition training"""
    
    def __init__(self, audio_dir: Path, labels_csv: Path = None):
        self.audio_dir = audio_dir
        self.samples = []
        
        if labels_csv and labels_csv.exists():
            self._load_labeled_data(labels_csv)
        else:
            self._generate_placeholder_data()
    
    def _load_labeled_data(self, labels_csv: Path):
        import csv
        with open(labels_csv) as f:
            reader = csv.DictReader(f)
            for row in reader:
                audio_path = self.audio_dir / row['filename']
                if audio_path.exists():
                    self.samples.append({
                        'path': audio_path,
                        'valence': float(row['valence']),
                        'arousal': float(row['arousal'])
                    })
    
    def _generate_placeholder_data(self):
        """Generate synthetic training data for testing"""
        print("Generating placeholder training data...")
        for i in range(1000):
            valence = np.random.uniform(-1, 1)
            arousal = np.random.uniform(0, 1)
            self.samples.append({
                'features': np.random.randn(128).astype(np.float32),
                'valence': valence,
                'arousal': arousal
            })
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        sample = self.samples[idx]
        
        if 'features' in sample:
            features = sample['features']
        else:
            features = self._extract_features(sample['path'])
        
        # Target: 64-dim vector encoding valence/arousal
        target = np.zeros(64, dtype=np.float32)
        v, a = sample['valence'], sample['arousal']
        
        # Encode valence in first 32 dims
        for i in range(32):
            target[i] = v * (1 - i/32) + np.random.randn() * 0.1
        
        # Encode arousal in next 16 dims
        for i in range(16):
            target[32 + i] = (a * 2 - 1) * (1 - i/16) + np.random.randn() * 0.1
        
        # Encode dominance proxy in last 16 dims
        d = (v + a) / 2
        for i in range(16):
            target[48 + i] = d * (1 - i/16) + np.random.randn() * 0.1
        
        return torch.tensor(features), torch.tensor(target)
    
    def _extract_features(self, audio_path: Path) -> np.ndarray:
        """Extract 128-dim features from audio file"""
        y, sr = librosa.load(str(audio_path), sr=22050, duration=5.0)
        
        features = []
        
        # Time-domain
        rms = librosa.feature.rms(y=y).mean()
        zcr = librosa.feature.zero_crossing_rate(y).mean()
        features.extend([rms, zcr])
        
        # Spectral
        spec_cent = librosa.feature.spectral_centroid(y=y, sr=sr).mean()
        spec_bw = librosa.feature.spectral_bandwidth(y=y, sr=sr).mean()
        spec_rolloff = librosa.feature.spectral_rolloff(y=y, sr=sr).mean()
        spec_flat = librosa.feature.spectral_flatness(y=y).mean()
        features.extend([spec_cent/sr, spec_bw/sr, spec_rolloff/sr, spec_flat])
        
        # MFCCs
        mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=40)
        features.extend(mfccs.mean(axis=1).tolist())
        
        # Chroma
        chroma = librosa.feature.chroma_stft(y=y, sr=sr)
        features.extend(chroma.mean(axis=1).tolist())
        
        # Mel spectrogram bands
        mel = librosa.feature.melspectrogram(y=y, sr=sr, n_mels=40)
        mel_db = librosa.power_to_db(mel)
        features.extend(mel_db.mean(axis=1).tolist())
        
        # Pad/truncate to 128
        features = np.array(features, dtype=np.float32)
        if len(features) < 128:
            features = np.pad(features, (0, 128 - len(features)))
        else:
            features = features[:128]
        
        # Normalize
        features = np.tanh(features / np.abs(features).max())
        
        return features


def export_to_rtneural(model: nn.Module, output_path: Path):
    """Export PyTorch model to RTNeural JSON format"""
    model.eval()
    
    state_dict = model.state_dict()
    
    model_json = {
        "model_type": "sequential",
        "input_size": 128,
        "output_size": 64,
        "layers": []
    }
    
    # Layer 1: Dense 128→256
    model_json["layers"].append({
        "type": "dense",
        "in_size": 128,
        "out_size": 256,
        "activation": "tanh",
        "weights": state_dict["fc1.weight"].T.flatten().tolist(),
        "bias": state_dict["fc1.bias"].tolist()
    })
    
    # Layer 2: Dense 256→256
    model_json["layers"].append({
        "type": "dense",
        "in_size": 256,
        "out_size": 256,
        "activation": "tanh",
        "weights": state_dict["fc2.weight"].T.flatten().tolist(),
        "bias": state_dict["fc2.bias"].tolist()
    })
    
    # Layer 3: Dense 256→64
    model_json["layers"].append({
        "type": "dense",
        "in_size": 256,
        "out_size": 64,
        "activation": "tanh",
        "weights": state_dict["fc3.weight"].T.flatten().tolist(),
        "bias": state_dict["fc3.bias"].tolist()
    })
    
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, 'w') as f:
        json.dump(model_json, f, indent=2)
    
    print(f"Model exported to {output_path}")


def train(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    
    # Dataset
    dataset = EmotionDataset(
        audio_dir=Path(args.dataset) if args.dataset else Path("."),
        labels_csv=Path(args.labels) if args.labels else None
    )
    
    train_size = int(0.8 * len(dataset))
    val_size = len(dataset) - train_size
    train_dataset, val_dataset = torch.utils.data.random_split(
        dataset, [train_size, val_size]
    )
    
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=args.batch_size)
    
    # Model
    model = EmotionRecognitionModel(
        input_size=128,
        hidden_size=args.hidden_size,
        output_size=64
    ).to(device)
    
    criterion = nn.MSELoss()
    optimizer = optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-5)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    
    best_val_loss = float('inf')
    
    for epoch in range(args.epochs):
        # Train
        model.train()
        train_loss = 0.0
        for features, targets in train_loader:
            features, targets = features.to(device), targets.to(device)
            
            optimizer.zero_grad()
            outputs = model(features)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            
            train_loss += loss.item()
        
        train_loss /= len(train_loader)
        
        # Validate
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for features, targets in val_loader:
                features, targets = features.to(device), targets.to(device)
                outputs = model(features)
                loss = criterion(outputs, targets)
                val_loss += loss.item()
        
        val_loss /= len(val_loader)
        scheduler.step()
        
        print(f"Epoch {epoch+1}/{args.epochs} | "
              f"Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f}")
        
        # Save best
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save(model.state_dict(), args.output / "best_model.pt")
    
    # Load best and export
    model.load_state_dict(torch.load(args.output / "best_model.pt"))
    export_to_rtneural(model, args.output / "emotion_model.json")
    
    print(f"\nTraining complete!")
    print(f"Best validation loss: {best_val_loss:.4f}")
    print(f"Model saved to: {args.output / 'emotion_model.json'}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train Kelly emotion model")
    parser.add_argument("--dataset", type=str, default=None,
                       help="Audio dataset directory")
    parser.add_argument("--labels", type=str, default=None,
                       help="Labels CSV file")
    parser.add_argument("--output", type=Path, default=Path("../Resources"),
                       help="Output directory")
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--hidden-size", type=int, default=256)
    parser.add_argument("--lr", type=float, default=1e-3)
    
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    
    train(args)
```

---

## 8. Plugin Processor Integration

```cpp
// In PluginProcessor.cpp - Add to processBlock()

void KellyProcessor::processBlock(juce::AudioBuffer<float>& buffer,
                                   juce::MidiBuffer& midiMessages)
{
    // ... existing code ...
    
    // === ML INTEGRATION ===
    if (mlEnabled_.load(std::memory_order_acquire)) {
        // Extract features from audio
        auto features = featureExtractor_.extractFeatures(buffer);
        
        // Submit to inference thread (non-blocking)
        InferenceRequest request;
        request.features = features;
        request.timestamp = currentTimestamp_++;
        inferenceManager_.submitRequest(request);
        
        // Check for results (non-blocking)
        InferenceResult result;
        if (inferenceManager_.getResult(result)) {
            // Convert to VAD
            auto neuralVAD = fusionLayer_.vectorToVAD(result.emotionVector);
            
            // Get rule-based VAD
            VADCoordinates ruleVAD;
            ruleVAD.valence = currentIntent_.valence;
            ruleVAD.arousal = currentIntent_.arousal;
            ruleVAD.dominance = currentIntent_.dominance;
            ruleVAD.confidence = 0.8f;
            
            // Fuse
            auto fusedVAD = fusionLayer_.fuse(
                ruleVAD,
                neuralVAD,
                mlBlendAmount_.load(std::memory_order_acquire)
            );
            
            // Apply to emotion engine
            applyFusedEmotion(fusedVAD);
        }
    }
    
    // ... rest of processing ...
}

void KellyProcessor::enableMLInference(bool enable) {
    mlEnabled_.store(enable, std::memory_order_release);
}

void KellyProcessor::setMLBlend(float blend) {
    mlBlendAmount_.store(blend, std::memory_order_release);
}
```

---

## 9. CMake Integration

```cmake
# In CMakeLists.txt

# Fetch RTNeural
include(FetchContent)
FetchContent_Declare(
    RTNeural
    GIT_REPOSITORY https://github.com/jatinchowdhury18/RTNeural.git
    GIT_TAG v1.0.0
)
FetchContent_MakeAvailable(RTNeural)

# Add ML sources
set(ML_SOURCES
    src/ml/LockFreeRingBuffer.h
    src/ml/MLFeatureExtractor.h
    src/ml/RTNeuralProcessor.h
    src/ml/InferenceThreadManager.h
    src/ml/EmotionFusionLayer.h
)

target_sources(${PROJECT_NAME} PRIVATE ${ML_SOURCES})
target_link_libraries(${PROJECT_NAME} PRIVATE RTNeural)

# Copy model to resources
add_custom_command(TARGET ${PROJECT_NAME} POST_BUILD
    COMMAND ${CMAKE_COMMAND} -E copy_if_different
    ${CMAKE_SOURCE_DIR}/Resources/emotion_model.json
    $<TARGET_FILE_DIR:${PROJECT_NAME}>/Resources/emotion_model.json
)
```

---

## 10. Quick Reference

### File Structure
```
src/
├── ml/
│   ├── LockFreeRingBuffer.h     # Thread-safe queue
│   ├── MLFeatureExtractor.h     # 128-dim audio features
│   ├── RTNeuralProcessor.h      # Neural inference
│   ├── InferenceThreadManager.h # Async ML pipeline
│   └── EmotionFusionLayer.h     # VAD fusion
├── plugin/
│   └── PluginProcessor.cpp      # Integration point
└── engine/
    └── EmotionMusicMapper.h     # Formulas (unchanged)

ml_training/
├── train_emotion_model.py       # PyTorch training
├── requirements.txt             # torch, librosa, numpy
└── README.md

Resources/
└── emotion_model.json           # RTNeural weights
```

### Key Formulas (From Existing Code)
```cpp
tempo = 60 + 120 * arousal           // 60-180 BPM
velocity = 60 + 67 * dominance       // 60-127
mode = major if valence > 0 else minor
reward = 0.4*E + 0.3*C + 0.2*N + 0.1*F
resonance = 0.3*Δhrv + 0.2*Δeda + 0.3*v + 0.2*c
```

### Training Commands
```bash
# Setup
cd ml_training
python -m venv venv
source venv/bin/activate
pip install torch librosa numpy

# Train with placeholder data
python train_emotion_model.py --epochs 50

# Train with DEAM dataset
python train_emotion_model.py \
  --dataset /path/to/DEAM/audio \
  --labels /path/to/DEAM/annotations.csv \
  --epochs 100

# Output: Resources/emotion_model.json
```

### Build Commands
```bash
# Rebuild with ML
cmake -B build -G Ninja
cmake --build build --target KellyMidiCompanion_AU

# Test
auval -v aumu Kell Antc
```

---

## 11. Datasets for Training

| Dataset | Size | Labels | URL |
|---------|------|--------|-----|
| DEAM | 1802 clips | V/A continuous | cvml.unige.ch/databases/DEAM |
| EMOPIA | 387 MIDI | Quadrant emotions | github.com/annahung31/EMOPIA |
| PMEmo | 794 songs | V/A + physio | github.com/HuiZhangDB/PMEmo |
| Lakh MIDI | 176k files | No emotion | colinraffel.com/projects/lmd |

---

**Implementation Order**:
1. `LockFreeRingBuffer.h` → Test standalone
2. `MLFeatureExtractor.h` → Verify 128-dim output
3. `RTNeuralProcessor.h` → Load placeholder model
4. `InferenceThreadManager.h` → Test async pipeline
5. `EmotionFusionLayer.h` → VAD conversion
6. Plugin integration → Full system test
7. Train real model → Replace placeholder
