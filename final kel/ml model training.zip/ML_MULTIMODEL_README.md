# Kelly MIDI Companion - Multi-Model ML Architecture

## 5-Model System (~1M params, ~4MB, <10ms inference)

| Model | Architecture | Params | Memory | Purpose |
|-------|-------------|--------|--------|---------|
| EmotionRecognizer | 128→512→256→128→64 | ~500K | ~2MB | Audio → Emotion |
| MelodyTransformer | 64→256→256→256→128 | ~400K | ~1.6MB | Emotion → MIDI |
| HarmonyPredictor | 128→256→128→64 | ~100K | ~400KB | Context → Chords |
| DynamicsEngine | 32→128→64→16 | ~20K | ~80KB | Context → Expression |
| GroovePredictor | 64→128→64→32 | ~25K | ~100KB | Emotion → Groove |

## Files

```
├── MultiModelProcessor.h      # Simplified all-in-one header (use this)
├── RTNeuralMultiModel.h       # Full header with all features
├── RTNeuralMultiModel.cpp     # Implementation
├── models/
│   ├── model_architectures.json   # All model specs
│   └── emotion_recognizer.json    # Placeholder weights
└── ml_training/
    └── train_all_models.py    # PyTorch training → RTNeural export
```

## Quick Integration

```cpp
#include "MultiModelProcessor.h"

Kelly::ML::MultiModelProcessor mlProcessor;
mlProcessor.initialize(modelsDirectory);

// In processBlock:
std::array<float, 128> features = extractMelFeatures(buffer);
auto result = mlProcessor.runFullPipeline(features);

// Use results:
// result.emotionEmbedding[0-63]     → valence/arousal
// result.melodyProbabilities[0-127] → note suggestions
// result.harmonyPrediction[0-63]    → chord weights
// result.dynamicsOutput[0-15]       → velocity/timing
// result.grooveParameters[0-31]     → swing/shuffle
```

## Async Usage (Audio Thread Safe)

```cpp
Kelly::ML::AsyncMLPipeline asyncML(mlProcessor);
asyncML.start();

// Audio thread:
asyncML.submitFeatures(features);  // Non-blocking

// Check for results:
if (asyncML.hasResult()) {
    auto result = asyncML.getResult();
}
```

## Training

```bash
cd ml_training
python train_all_models.py --output ../models --epochs 100 --device mps
```

## Limits

- Per model: Up to ~5M params comfortably
- Total models: 3-5 concurrent, ~50MB total
- Hard ceiling: ~100M params before DAW issues
