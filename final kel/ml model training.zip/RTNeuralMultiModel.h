#pragma once

#include <juce_core/juce_core.h>
#include <array>
#include <memory>
#include <string>
#include <vector>
#include <functional>
#include <atomic>
#include <mutex>

#ifdef ENABLE_RTNEURAL
#include <RTNeural/RTNeural.h>
#endif

namespace Kelly {
namespace ML {

// ============================================================================
// Model Configuration
// ============================================================================

enum class ModelType {
    EmotionRecognizer,    // Audio features → Emotion embedding
    MelodyTransformer,    // Emotion → Melody suggestions
    HarmonyPredictor,     // Context → Chord predictions
    DynamicsEngine,       // Context → Velocity/timing
    GroovePredictor       // Emotion → Groove patterns
};

struct ModelConfig {
    ModelType type;
    std::string name;
    std::string jsonPath;
    size_t inputSize;
    size_t outputSize;
    std::vector<size_t> hiddenSizes;
    bool enabled = true;
    float inferenceWeight = 1.0f;  // For blending multiple model outputs
};

// Default configurations for the 5-model architecture
inline std::vector<ModelConfig> getDefaultModelConfigs() {
    return {
        {
            ModelType::EmotionRecognizer,
            "EmotionRecognizer",
            "models/emotion_recognizer.json",
            128,    // Mel-spectrogram features
            64,     // Emotion embedding
            {512, 256, 128},
            true,
            1.0f
        },
        {
            ModelType::MelodyTransformer,
            "MelodyTransformer", 
            "models/melody_transformer.json",
            64,     // Emotion embedding
            128,    // MIDI note probabilities
            {256, 256, 256},
            true,
            1.0f
        },
        {
            ModelType::HarmonyPredictor,
            "HarmonyPredictor",
            "models/harmony_predictor.json",
            128,    // Context (emotion + current state)
            64,     // Chord probabilities
            {256, 128},
            true,
            1.0f
        },
        {
            ModelType::DynamicsEngine,
            "DynamicsEngine",
            "models/dynamics_engine.json",
            32,     // Compact context
            16,     // Velocity, timing, expression
            {128, 64},
            true,
            1.0f
        },
        {
            ModelType::GroovePredictor,
            "GroovePredictor",
            "models/groove_predictor.json",
            64,     // Emotion embedding
            32,     // Groove parameters
            {128, 64},
            true,
            1.0f
        }
    };
}

// ============================================================================
// Runtime Model Wrapper (Heap Allocated, Any Size)
// ============================================================================

class RuntimeModelWrapper {
public:
    RuntimeModelWrapper(const ModelConfig& config)
        : config_(config), loaded_(false) {}
    
    ~RuntimeModelWrapper() = default;
    
    bool loadFromJson(const juce::File& jsonFile);
    bool loadFromMemory(const void* data, size_t size);
    
    std::vector<float> forward(const std::vector<float>& input);
    
    bool isLoaded() const { return loaded_.load(); }
    const ModelConfig& getConfig() const { return config_; }
    
    size_t getParameterCount() const { return parameterCount_; }
    size_t getMemoryUsageBytes() const { return memoryUsage_; }
    
    void setEnabled(bool enabled) { config_.enabled = enabled; }
    bool isEnabled() const { return config_.enabled; }

private:
    ModelConfig config_;
    std::atomic<bool> loaded_{false};
    size_t parameterCount_ = 0;
    size_t memoryUsage_ = 0;
    
#ifdef ENABLE_RTNEURAL
    // Use unique_ptr for heap allocation - no size limits!
    std::unique_ptr<RTNeural::Model<float>> model_;
#endif
    
    // Fallback weights for when RTNeural is disabled
    std::vector<std::vector<float>> fallbackWeights_;
    std::vector<float> fallbackBiases_;
};

// ============================================================================
// Multi-Model Manager
// ============================================================================

class MultiModelManager {
public:
    MultiModelManager();
    ~MultiModelManager();
    
    // Initialization
    bool initialize(const juce::File& modelsDirectory);
    bool initialize(const std::vector<ModelConfig>& configs);
    
    // Model management
    bool loadModel(ModelType type, const juce::File& jsonFile);
    bool unloadModel(ModelType type);
    void unloadAll();
    
    // Enable/disable individual models
    void setModelEnabled(ModelType type, bool enabled);
    bool isModelEnabled(ModelType type) const;
    bool isModelLoaded(ModelType type) const;
    
    // Inference
    std::vector<float> infer(ModelType type, const std::vector<float>& input);
    
    // Batch inference (run multiple models in sequence)
    struct InferenceResult {
        std::vector<float> emotionEmbedding;      // 64 dims
        std::vector<float> melodyProbabilities;   // 128 dims
        std::vector<float> harmonyPrediction;     // 64 dims
        std::vector<float> dynamicsOutput;        // 16 dims
        std::vector<float> grooveParameters;      // 32 dims
    };
    
    InferenceResult runFullPipeline(const std::vector<float>& audioFeatures);
    
    // Statistics
    size_t getTotalParameterCount() const;
    size_t getTotalMemoryUsage() const;
    size_t getLoadedModelCount() const;
    
    // Thread safety
    void lock() { mutex_.lock(); }
    void unlock() { mutex_.unlock(); }
    std::unique_lock<std::mutex> getScopedLock() { return std::unique_lock<std::mutex>(mutex_); }

private:
    std::array<std::unique_ptr<RuntimeModelWrapper>, 5> models_;
    std::vector<ModelConfig> configs_;
    mutable std::mutex mutex_;
    bool initialized_ = false;
    
    size_t modelTypeToIndex(ModelType type) const {
        return static_cast<size_t>(type);
    }
};

// ============================================================================
// Async Inference Pipeline (Lock-Free for Real-Time Audio)
// ============================================================================

class AsyncInferencePipeline {
public:
    AsyncInferencePipeline(MultiModelManager& manager);
    ~AsyncInferencePipeline();
    
    // Start/stop background thread
    void start();
    void stop();
    
    // Submit inference request (non-blocking, audio-thread safe)
    void submitRequest(const std::vector<float>& audioFeatures);
    
    // Check for results (non-blocking, audio-thread safe)
    bool hasResult() const;
    MultiModelManager::InferenceResult getResult();
    
    // Callback for when inference completes
    using ResultCallback = std::function<void(const MultiModelManager::InferenceResult&)>;
    void setResultCallback(ResultCallback callback);

private:
    MultiModelManager& manager_;
    
    // Lock-free SPSC queues for audio thread communication
    struct Request {
        std::vector<float> features;
        std::atomic<bool> valid{false};
    };
    
    struct Result {
        MultiModelManager::InferenceResult data;
        std::atomic<bool> valid{false};
    };
    
    static constexpr size_t QUEUE_SIZE = 4;
    std::array<Request, QUEUE_SIZE> requestQueue_;
    std::array<Result, QUEUE_SIZE> resultQueue_;
    std::atomic<size_t> requestWriteIdx_{0};
    std::atomic<size_t> requestReadIdx_{0};
    std::atomic<size_t> resultWriteIdx_{0};
    std::atomic<size_t> resultReadIdx_{0};
    
    std::unique_ptr<juce::Thread> inferenceThread_;
    std::atomic<bool> running_{false};
    
    ResultCallback resultCallback_;
    
    void inferenceThreadRun();
};

// ============================================================================
// Feature Extractor (128-dimensional mel-spectrogram features)
// ============================================================================

class FeatureExtractor {
public:
    FeatureExtractor(double sampleRate = 44100.0, size_t fftSize = 2048);
    ~FeatureExtractor() = default;
    
    void prepare(double sampleRate, int samplesPerBlock);
    void reset();
    
    // Extract features from audio buffer
    std::vector<float> extractFeatures(const float* audioData, size_t numSamples);
    
    // Get feature dimensions
    static constexpr size_t NUM_MEL_BINS = 128;
    static constexpr size_t FEATURE_SIZE = 128;

private:
    double sampleRate_;
    size_t fftSize_;
    size_t hopSize_;
    
    // Mel filterbank
    std::vector<std::vector<float>> melFilterbank_;
    
    // Circular buffer for overlapping windows
    std::vector<float> circularBuffer_;
    size_t bufferWritePos_ = 0;
    
    // FFT working arrays
    std::vector<float> fftInput_;
    std::vector<float> fftOutput_;
    std::vector<float> windowFunction_;
    
    void computeMelFilterbank();
    void applyWindow(float* data, size_t size);
    std::vector<float> computeMelSpectrogram(const float* audioData, size_t numSamples);
};

} // namespace ML
} // namespace Kelly
