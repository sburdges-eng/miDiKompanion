#include "RTNeuralMultiModel.h"
#include <cmath>
#include <algorithm>
#include <fstream>
#include <sstream>

namespace Kelly {
namespace ML {

// ============================================================================
// RuntimeModelWrapper Implementation
// ============================================================================

bool RuntimeModelWrapper::loadFromJson(const juce::File& jsonFile) {
    if (!jsonFile.existsAsFile()) {
        juce::Logger::writeToLog("Model file not found: " + jsonFile.getFullPathName());
        return false;
    }
    
    juce::FileInputStream stream(jsonFile);
    if (!stream.openedOk()) {
        juce::Logger::writeToLog("Failed to open model file: " + jsonFile.getFullPathName());
        return false;
    }
    
    juce::String jsonContent = stream.readEntireStreamAsString();
    
#ifdef ENABLE_RTNEURAL
    try {
        // Parse JSON and create model
        std::istringstream iss(jsonContent.toStdString());
        
        // Create runtime model (heap allocated, any size)
        model_ = std::make_unique<RTNeural::Model<float>>();
        
        // Load from JSON stream
        // Note: RTNeural's JSON loading may vary by version
        // This uses the standard nlohmann-json based loader
        nlohmann::json modelJson;
        iss >> modelJson;
        
        // Build model from JSON specification
        if (modelJson.contains("layers")) {
            for (const auto& layerJson : modelJson["layers"]) {
                std::string layerType = layerJson["type"];
                
                if (layerType == "dense") {
                    size_t inSize = layerJson["in_size"];
                    size_t outSize = layerJson["out_size"];
                    std::string activation = layerJson.value("activation", "none");
                    
                    // Add dense layer
                    if (activation == "tanh") {
                        model_->addLayer(std::make_unique<RTNeural::Dense<float>>(inSize, outSize));
                        model_->addLayer(std::make_unique<RTNeural::TanhActivation<float>>(outSize));
                    } else if (activation == "relu") {
                        model_->addLayer(std::make_unique<RTNeural::Dense<float>>(inSize, outSize));
                        model_->addLayer(std::make_unique<RTNeural::ReLuActivation<float>>(outSize));
                    } else if (activation == "sigmoid") {
                        model_->addLayer(std::make_unique<RTNeural::Dense<float>>(inSize, outSize));
                        model_->addLayer(std::make_unique<RTNeural::SigmoidActivation<float>>(outSize));
                    } else {
                        model_->addLayer(std::make_unique<RTNeural::Dense<float>>(inSize, outSize));
                    }
                    
                    parameterCount_ += inSize * outSize + outSize;  // weights + bias
                }
                else if (layerType == "lstm") {
                    size_t inSize = layerJson["in_size"];
                    size_t outSize = layerJson["out_size"];
                    
                    model_->addLayer(std::make_unique<RTNeural::LSTMLayer<float>>(inSize, outSize));
                    
                    // LSTM has 4 gates, each with input and hidden weights
                    parameterCount_ += 4 * (inSize * outSize + outSize * outSize + outSize);
                }
                else if (layerType == "gru") {
                    size_t inSize = layerJson["in_size"];
                    size_t outSize = layerJson["out_size"];
                    
                    model_->addLayer(std::make_unique<RTNeural::GRULayer<float>>(inSize, outSize));
                    
                    // GRU has 3 gates
                    parameterCount_ += 3 * (inSize * outSize + outSize * outSize + outSize);
                }
            }
            
            // Load weights if present
            if (modelJson.contains("weights")) {
                // RTNeural weight loading varies by version
                // model_->setWeights(modelJson["weights"]);
            }
        }
        
        memoryUsage_ = parameterCount_ * sizeof(float);
        loaded_ = true;
        
        juce::Logger::writeToLog("Loaded model: " + config_.name + 
                                 " (" + juce::String(parameterCount_) + " params, " +
                                 juce::String(memoryUsage_ / 1024) + " KB)");
        return true;
    }
    catch (const std::exception& e) {
        juce::Logger::writeToLog("Failed to parse model JSON: " + juce::String(e.what()));
        return false;
    }
#else
    // Fallback: create simple linear approximation
    size_t totalSize = config_.inputSize;
    for (size_t hidden : config_.hiddenSizes) {
        parameterCount_ += totalSize * hidden + hidden;
        totalSize = hidden;
    }
    parameterCount_ += totalSize * config_.outputSize + config_.outputSize;
    memoryUsage_ = parameterCount_ * sizeof(float);
    
    // Initialize random fallback weights
    fallbackWeights_.clear();
    fallbackBiases_.clear();
    
    juce::Logger::writeToLog("Loaded model (fallback mode): " + config_.name);
    loaded_ = true;
    return true;
#endif
}

bool RuntimeModelWrapper::loadFromMemory(const void* data, size_t size) {
    juce::String jsonContent = juce::String::createStringFromData(data, static_cast<int>(size));
    
    // Create temp file and load
    juce::File tempFile = juce::File::getSpecialLocation(juce::File::tempDirectory)
                          .getChildFile("kelly_model_temp.json");
    tempFile.replaceWithText(jsonContent);
    
    bool result = loadFromJson(tempFile);
    tempFile.deleteFile();
    
    return result;
}

std::vector<float> RuntimeModelWrapper::forward(const std::vector<float>& input) {
    std::vector<float> output(config_.outputSize, 0.0f);
    
    if (!loaded_ || !config_.enabled) {
        return output;
    }
    
    if (input.size() != config_.inputSize) {
        juce::Logger::writeToLog("Input size mismatch: expected " + 
                                 juce::String(config_.inputSize) + 
                                 ", got " + juce::String(input.size()));
        return output;
    }
    
#ifdef ENABLE_RTNEURAL
    if (model_) {
        // Run inference
        const float* inputPtr = input.data();
        float* outputPtr = output.data();
        
        model_->forward(inputPtr);
        
        // Copy output
        for (size_t i = 0; i < config_.outputSize; ++i) {
            output[i] = model_->getOutputs()[i];
        }
    }
#else
    // Fallback: simple heuristic based on model type
    switch (config_.type) {
        case ModelType::EmotionRecognizer:
            // Valence in first 32, arousal in last 32
            for (size_t i = 0; i < 32 && i < output.size(); ++i) {
                output[i] = input[i % input.size()] * 0.3f;
                if (i + 32 < output.size()) {
                    output[i + 32] = input[(i + 64) % input.size()] * 0.5f;
                }
            }
            break;
            
        case ModelType::MelodyTransformer:
            // Note probabilities based on emotion
            for (size_t i = 0; i < output.size(); ++i) {
                float note = static_cast<float>(i % 12) / 12.0f;
                float emotionInfluence = (i < input.size()) ? input[i] : 0.0f;
                output[i] = std::tanh(note * 0.5f + emotionInfluence * 0.3f);
            }
            break;
            
        case ModelType::HarmonyPredictor:
            // Chord probabilities
            for (size_t i = 0; i < output.size(); ++i) {
                output[i] = (i < input.size()) ? std::tanh(input[i] * 0.4f) : 0.0f;
            }
            break;
            
        case ModelType::DynamicsEngine:
            // Velocity, timing, expression
            for (size_t i = 0; i < output.size(); ++i) {
                output[i] = 0.5f + (i < input.size() ? input[i] * 0.3f : 0.0f);
            }
            break;
            
        case ModelType::GroovePredictor:
            // Groove parameters
            for (size_t i = 0; i < output.size(); ++i) {
                output[i] = (i < input.size()) ? input[i] * 0.6f : 0.0f;
            }
            break;
    }
#endif
    
    return output;
}

// ============================================================================
// MultiModelManager Implementation
// ============================================================================

MultiModelManager::MultiModelManager() {
    configs_ = getDefaultModelConfigs();
}

MultiModelManager::~MultiModelManager() {
    unloadAll();
}

bool MultiModelManager::initialize(const juce::File& modelsDirectory) {
    std::lock_guard<std::mutex> lock(mutex_);
    
    if (!modelsDirectory.isDirectory()) {
        juce::Logger::writeToLog("Models directory not found: " + modelsDirectory.getFullPathName());
        // Continue anyway - will use fallback mode
    }
    
    bool anyLoaded = false;
    
    for (size_t i = 0; i < configs_.size(); ++i) {
        models_[i] = std::make_unique<RuntimeModelWrapper>(configs_[i]);
        
        juce::File modelFile = modelsDirectory.getChildFile(configs_[i].jsonPath);
        if (modelFile.existsAsFile()) {
            if (models_[i]->loadFromJson(modelFile)) {
                anyLoaded = true;
            }
        } else {
            // Load with fallback mode
            models_[i]->loadFromJson(juce::File());  // Will use fallback
            juce::Logger::writeToLog("Model file not found, using fallback: " + configs_[i].name);
        }
    }
    
    initialized_ = true;
    
    juce::Logger::writeToLog("MultiModelManager initialized: " + 
                             juce::String(getLoadedModelCount()) + "/" + 
                             juce::String(configs_.size()) + " models loaded");
    juce::Logger::writeToLog("Total parameters: " + juce::String(getTotalParameterCount()));
    juce::Logger::writeToLog("Total memory: " + juce::String(getTotalMemoryUsage() / 1024) + " KB");
    
    return initialized_;
}

bool MultiModelManager::initialize(const std::vector<ModelConfig>& configs) {
    std::lock_guard<std::mutex> lock(mutex_);
    
    configs_ = configs;
    
    for (size_t i = 0; i < configs_.size() && i < models_.size(); ++i) {
        models_[i] = std::make_unique<RuntimeModelWrapper>(configs_[i]);
    }
    
    initialized_ = true;
    return true;
}

bool MultiModelManager::loadModel(ModelType type, const juce::File& jsonFile) {
    std::lock_guard<std::mutex> lock(mutex_);
    
    size_t idx = modelTypeToIndex(type);
    if (idx >= models_.size() || !models_[idx]) {
        return false;
    }
    
    return models_[idx]->loadFromJson(jsonFile);
}

bool MultiModelManager::unloadModel(ModelType type) {
    std::lock_guard<std::mutex> lock(mutex_);
    
    size_t idx = modelTypeToIndex(type);
    if (idx >= models_.size()) {
        return false;
    }
    
    models_[idx].reset();
    return true;
}

void MultiModelManager::unloadAll() {
    std::lock_guard<std::mutex> lock(mutex_);
    
    for (auto& model : models_) {
        model.reset();
    }
    
    initialized_ = false;
}

void MultiModelManager::setModelEnabled(ModelType type, bool enabled) {
    std::lock_guard<std::mutex> lock(mutex_);
    
    size_t idx = modelTypeToIndex(type);
    if (idx < models_.size() && models_[idx]) {
        models_[idx]->setEnabled(enabled);
    }
}

bool MultiModelManager::isModelEnabled(ModelType type) const {
    size_t idx = modelTypeToIndex(type);
    if (idx < models_.size() && models_[idx]) {
        return models_[idx]->isEnabled();
    }
    return false;
}

bool MultiModelManager::isModelLoaded(ModelType type) const {
    size_t idx = modelTypeToIndex(type);
    if (idx < models_.size() && models_[idx]) {
        return models_[idx]->isLoaded();
    }
    return false;
}

std::vector<float> MultiModelManager::infer(ModelType type, const std::vector<float>& input) {
    std::lock_guard<std::mutex> lock(mutex_);
    
    size_t idx = modelTypeToIndex(type);
    if (idx >= models_.size() || !models_[idx]) {
        return std::vector<float>();
    }
    
    return models_[idx]->forward(input);
}

MultiModelManager::InferenceResult MultiModelManager::runFullPipeline(const std::vector<float>& audioFeatures) {
    std::lock_guard<std::mutex> lock(mutex_);
    
    InferenceResult result;
    
    // 1. Extract emotion from audio features
    if (models_[0] && models_[0]->isEnabled()) {
        result.emotionEmbedding = models_[0]->forward(audioFeatures);
    } else {
        result.emotionEmbedding.resize(64, 0.0f);
    }
    
    // 2. Generate melody suggestions from emotion
    if (models_[1] && models_[1]->isEnabled()) {
        result.melodyProbabilities = models_[1]->forward(result.emotionEmbedding);
    } else {
        result.melodyProbabilities.resize(128, 0.0f);
    }
    
    // 3. Predict harmony from emotion + context
    if (models_[2] && models_[2]->isEnabled()) {
        // Combine emotion with audio features for context
        std::vector<float> harmonyInput(128);
        for (size_t i = 0; i < 64; ++i) {
            harmonyInput[i] = result.emotionEmbedding[i];
            harmonyInput[i + 64] = (i < audioFeatures.size()) ? audioFeatures[i] : 0.0f;
        }
        result.harmonyPrediction = models_[2]->forward(harmonyInput);
    } else {
        result.harmonyPrediction.resize(64, 0.0f);
    }
    
    // 4. Predict dynamics from compact context
    if (models_[3] && models_[3]->isEnabled()) {
        std::vector<float> dynamicsInput(32);
        for (size_t i = 0; i < 32; ++i) {
            dynamicsInput[i] = result.emotionEmbedding[i];
        }
        result.dynamicsOutput = models_[3]->forward(dynamicsInput);
    } else {
        result.dynamicsOutput.resize(16, 0.5f);  // Default mid-velocity
    }
    
    // 5. Predict groove from emotion
    if (models_[4] && models_[4]->isEnabled()) {
        result.grooveParameters = models_[4]->forward(result.emotionEmbedding);
    } else {
        result.grooveParameters.resize(32, 0.0f);
    }
    
    return result;
}

size_t MultiModelManager::getTotalParameterCount() const {
    size_t total = 0;
    for (const auto& model : models_) {
        if (model) {
            total += model->getParameterCount();
        }
    }
    return total;
}

size_t MultiModelManager::getTotalMemoryUsage() const {
    size_t total = 0;
    for (const auto& model : models_) {
        if (model) {
            total += model->getMemoryUsageBytes();
        }
    }
    return total;
}

size_t MultiModelManager::getLoadedModelCount() const {
    size_t count = 0;
    for (const auto& model : models_) {
        if (model && model->isLoaded()) {
            ++count;
        }
    }
    return count;
}

// ============================================================================
// AsyncInferencePipeline Implementation
// ============================================================================

class InferenceThread : public juce::Thread {
public:
    InferenceThread(AsyncInferencePipeline& pipeline)
        : juce::Thread("Kelly ML Inference"), pipeline_(pipeline) {}
    
    void run() override {
        pipeline_.inferenceThreadRun();
    }
    
private:
    AsyncInferencePipeline& pipeline_;
};

AsyncInferencePipeline::AsyncInferencePipeline(MultiModelManager& manager)
    : manager_(manager) {}

AsyncInferencePipeline::~AsyncInferencePipeline() {
    stop();
}

void AsyncInferencePipeline::start() {
    if (running_) return;
    
    running_ = true;
    inferenceThread_ = std::make_unique<InferenceThread>(*this);
    inferenceThread_->startThread();
}

void AsyncInferencePipeline::stop() {
    running_ = false;
    
    if (inferenceThread_) {
        inferenceThread_->stopThread(1000);
        inferenceThread_.reset();
    }
}

void AsyncInferencePipeline::submitRequest(const std::vector<float>& audioFeatures) {
    // Lock-free write to request queue
    size_t writeIdx = requestWriteIdx_.load(std::memory_order_relaxed);
    size_t nextIdx = (writeIdx + 1) % QUEUE_SIZE;
    
    // Check if queue is full
    if (nextIdx == requestReadIdx_.load(std::memory_order_acquire)) {
        return;  // Drop request if queue is full
    }
    
    requestQueue_[writeIdx].features = audioFeatures;
    requestQueue_[writeIdx].valid.store(true, std::memory_order_release);
    requestWriteIdx_.store(nextIdx, std::memory_order_release);
}

bool AsyncInferencePipeline::hasResult() const {
    size_t readIdx = resultReadIdx_.load(std::memory_order_relaxed);
    return resultQueue_[readIdx].valid.load(std::memory_order_acquire);
}

MultiModelManager::InferenceResult AsyncInferencePipeline::getResult() {
    size_t readIdx = resultReadIdx_.load(std::memory_order_relaxed);
    
    if (!resultQueue_[readIdx].valid.load(std::memory_order_acquire)) {
        return {};  // No result available
    }
    
    MultiModelManager::InferenceResult result = resultQueue_[readIdx].data;
    resultQueue_[readIdx].valid.store(false, std::memory_order_release);
    
    size_t nextIdx = (readIdx + 1) % QUEUE_SIZE;
    resultReadIdx_.store(nextIdx, std::memory_order_release);
    
    return result;
}

void AsyncInferencePipeline::setResultCallback(ResultCallback callback) {
    resultCallback_ = std::move(callback);
}

void AsyncInferencePipeline::inferenceThreadRun() {
    while (running_) {
        // Check for new requests
        size_t readIdx = requestReadIdx_.load(std::memory_order_relaxed);
        
        if (requestQueue_[readIdx].valid.load(std::memory_order_acquire)) {
            // Process request
            std::vector<float> features = requestQueue_[readIdx].features;
            requestQueue_[readIdx].valid.store(false, std::memory_order_release);
            
            size_t nextReadIdx = (readIdx + 1) % QUEUE_SIZE;
            requestReadIdx_.store(nextReadIdx, std::memory_order_release);
            
            // Run inference
            auto result = manager_.runFullPipeline(features);
            
            // Store result
            size_t writeIdx = resultWriteIdx_.load(std::memory_order_relaxed);
            resultQueue_[writeIdx].data = result;
            resultQueue_[writeIdx].valid.store(true, std::memory_order_release);
            
            size_t nextWriteIdx = (writeIdx + 1) % QUEUE_SIZE;
            resultWriteIdx_.store(nextWriteIdx, std::memory_order_release);
            
            // Call callback if set
            if (resultCallback_) {
                resultCallback_(result);
            }
        } else {
            // No work, sleep briefly
            juce::Thread::sleep(1);
        }
    }
}

// ============================================================================
// FeatureExtractor Implementation
// ============================================================================

FeatureExtractor::FeatureExtractor(double sampleRate, size_t fftSize)
    : sampleRate_(sampleRate)
    , fftSize_(fftSize)
    , hopSize_(fftSize / 4) {
    
    // Initialize buffers
    circularBuffer_.resize(fftSize_, 0.0f);
    fftInput_.resize(fftSize_, 0.0f);
    fftOutput_.resize(fftSize_, 0.0f);
    
    // Create Hann window
    windowFunction_.resize(fftSize_);
    for (size_t i = 0; i < fftSize_; ++i) {
        windowFunction_[i] = 0.5f * (1.0f - std::cos(2.0f * M_PI * i / (fftSize_ - 1)));
    }
    
    computeMelFilterbank();
}

void FeatureExtractor::prepare(double sampleRate, int /*samplesPerBlock*/) {
    sampleRate_ = sampleRate;
    reset();
    computeMelFilterbank();
}

void FeatureExtractor::reset() {
    std::fill(circularBuffer_.begin(), circularBuffer_.end(), 0.0f);
    bufferWritePos_ = 0;
}

void FeatureExtractor::computeMelFilterbank() {
    melFilterbank_.clear();
    melFilterbank_.resize(NUM_MEL_BINS);
    
    // Mel frequency range
    float minMel = 2595.0f * std::log10(1.0f + 20.0f / 700.0f);
    float maxMel = 2595.0f * std::log10(1.0f + (sampleRate_ / 2.0f) / 700.0f);
    
    // Create mel points
    std::vector<float> melPoints(NUM_MEL_BINS + 2);
    for (size_t i = 0; i < melPoints.size(); ++i) {
        float mel = minMel + (maxMel - minMel) * i / (melPoints.size() - 1);
        melPoints[i] = 700.0f * (std::pow(10.0f, mel / 2595.0f) - 1.0f);
    }
    
    // Convert to FFT bins
    std::vector<size_t> fftBins(melPoints.size());
    for (size_t i = 0; i < melPoints.size(); ++i) {
        fftBins[i] = static_cast<size_t>((fftSize_ + 1) * melPoints[i] / sampleRate_);
    }
    
    // Create triangular filters
    for (size_t m = 0; m < NUM_MEL_BINS; ++m) {
        melFilterbank_[m].resize(fftSize_ / 2 + 1, 0.0f);
        
        for (size_t k = fftBins[m]; k < fftBins[m + 1]; ++k) {
            if (k < melFilterbank_[m].size()) {
                melFilterbank_[m][k] = static_cast<float>(k - fftBins[m]) / 
                                       static_cast<float>(fftBins[m + 1] - fftBins[m]);
            }
        }
        
        for (size_t k = fftBins[m + 1]; k < fftBins[m + 2]; ++k) {
            if (k < melFilterbank_[m].size()) {
                melFilterbank_[m][k] = static_cast<float>(fftBins[m + 2] - k) / 
                                       static_cast<float>(fftBins[m + 2] - fftBins[m + 1]);
            }
        }
    }
}

void FeatureExtractor::applyWindow(float* data, size_t size) {
    for (size_t i = 0; i < size && i < windowFunction_.size(); ++i) {
        data[i] *= windowFunction_[i];
    }
}

std::vector<float> FeatureExtractor::computeMelSpectrogram(const float* audioData, size_t numSamples) {
    std::vector<float> melSpec(NUM_MEL_BINS, 0.0f);
    
    // Copy to FFT input buffer
    size_t copySize = std::min(numSamples, fftSize_);
    std::copy(audioData, audioData + copySize, fftInput_.begin());
    
    // Zero-pad if necessary
    if (copySize < fftSize_) {
        std::fill(fftInput_.begin() + copySize, fftInput_.end(), 0.0f);
    }
    
    // Apply window
    applyWindow(fftInput_.data(), fftSize_);
    
    // Simple DFT (for real production, use JUCE's FFT or FFTW)
    std::vector<float> magnitudes(fftSize_ / 2 + 1, 0.0f);
    for (size_t k = 0; k < magnitudes.size(); ++k) {
        float real = 0.0f, imag = 0.0f;
        for (size_t n = 0; n < fftSize_; ++n) {
            float angle = -2.0f * M_PI * k * n / fftSize_;
            real += fftInput_[n] * std::cos(angle);
            imag += fftInput_[n] * std::sin(angle);
        }
        magnitudes[k] = std::sqrt(real * real + imag * imag);
    }
    
    // Apply mel filterbank
    for (size_t m = 0; m < NUM_MEL_BINS; ++m) {
        float sum = 0.0f;
        for (size_t k = 0; k < magnitudes.size() && k < melFilterbank_[m].size(); ++k) {
            sum += magnitudes[k] * melFilterbank_[m][k];
        }
        // Log compression
        melSpec[m] = std::log(sum + 1e-10f);
    }
    
    return melSpec;
}

std::vector<float> FeatureExtractor::extractFeatures(const float* audioData, size_t numSamples) {
    // Add to circular buffer
    for (size_t i = 0; i < numSamples; ++i) {
        circularBuffer_[bufferWritePos_] = audioData[i];
        bufferWritePos_ = (bufferWritePos_ + 1) % circularBuffer_.size();
    }
    
    // Compute mel spectrogram from buffer
    std::vector<float> linearBuffer(fftSize_);
    for (size_t i = 0; i < fftSize_; ++i) {
        size_t idx = (bufferWritePos_ + i) % circularBuffer_.size();
        linearBuffer[i] = circularBuffer_[idx];
    }
    
    return computeMelSpectrogram(linearBuffer.data(), fftSize_);
}

} // namespace ML
} // namespace Kelly
